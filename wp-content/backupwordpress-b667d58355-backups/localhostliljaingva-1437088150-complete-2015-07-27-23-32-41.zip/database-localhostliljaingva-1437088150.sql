# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_commentmeta`
#

DROP TABLE IF EXISTS `wpLi_commentmeta`;


#
# Table structure of table `wpLi_commentmeta`
#

CREATE TABLE `wpLi_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_commentmeta (0 records)
#

#
# End of data contents of table wpLi_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_comments`
#

DROP TABLE IF EXISTS `wpLi_comments`;


#
# Table structure of table `wpLi_comments`
#

CREATE TABLE `wpLi_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_comments (1 records)
#
 
INSERT INTO `wpLi_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-07-10 17:16:32', '2015-07-10 17:16:32', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wpLi_comments
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_links`
#

DROP TABLE IF EXISTS `wpLi_links`;


#
# Table structure of table `wpLi_links`
#

CREATE TABLE `wpLi_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_links (0 records)
#

#
# End of data contents of table wpLi_links
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_options`
#

DROP TABLE IF EXISTS `wpLi_options`;


#
# Table structure of table `wpLi_options`
#

CREATE TABLE `wpLi_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=314 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_options (141 records)
#
 
INSERT INTO `wpLi_options` VALUES (1, 'siteurl', 'http://localhost/liljaingva', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (2, 'home', 'http://localhost/liljaingva', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (3, 'blogname', 'Lilja Ingva - ÍAK Einkaþjálfari', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (4, 'blogdescription', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (5, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (6, 'admin_email', 'steingrimur@740.is', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (7, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (8, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (9, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (10, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (11, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (12, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (13, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (14, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (15, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (16, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (17, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (18, 'default_category', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (19, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (20, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (21, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (23, 'date_format', 'd-m-Y', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (24, 'time_format', 'H:i', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (26, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (27, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (28, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (29, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (30, 'hack_file', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (31, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (32, 'moderation_keys', '', 'no') ; 
INSERT INTO `wpLi_options` VALUES (33, 'active_plugins', 'a:1:{i:0;s:35:"backupwordpress/backupwordpress.php";}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `wpLi_options` VALUES (41, 'template', 'liljaingva-theme', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (42, 'stylesheet', 'liljaingva-theme', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wpLi_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (49, 'db_version', '31536', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (52, 'blog_public', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (54, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (80, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wpLi_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (85, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (88, 'initial_db_version', '31535', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (89, 'wpLi_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (90, '_transient_random_seed', '9f62cc4c4b363aaeedabb963ef0855c8', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (91, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (92, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (93, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (94, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (95, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (96, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (98, 'cron', 'a:7:{i:1438060593;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1438069320;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1438073723;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1438103839;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1438124400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"7a3d3c0a2bc3decec2c0a68ef25aa23c";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:10:"1437088150";}s:8:"interval";i:86400;}}}i:1438484400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"5fc97bf18118d9765d16120a15b1f250";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:10:"1437088151";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (107, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1438026603;s:7:"checked";a:4:{s:16:"liljaingva-theme";s:3:"1.0";s:13:"twentyfifteen";s:3:"1.2";s:14:"twentyfourteen";s:3:"1.4";s:14:"twentythirteen";s:3:"1.5";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (132, '_transient_twentyfifteen_categories', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (133, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (134, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (135, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (137, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (140, 'current_theme', 'Webpage for liljaingva.com', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (141, 'theme_mods_liljaingva-theme', 'a:1:{i:0;b:0;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (142, 'theme_switched', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (143, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1436549353;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (176, 'recently_activated', 'a:1:{s:19:"akismet/akismet.php";i:1437088087;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (182, 'hmbkp_schedule_1437088150', 'a:7:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1437174000;s:11:"max_backups";i:7;s:5:"email";a:1:{s:5:"email";s:0:"";}s:14:"duration_total";i:27;s:16:"backup_run_count";i:5;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (183, 'hmbkp_schedule_1437088151', 'a:6:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1437274800;s:11:"max_backups";i:3;s:14:"duration_total";i:6;s:16:"backup_run_count";i:2;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (184, 'hmbkp_plugin_version', '3.2.6', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (226, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (238, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (240, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.2.3.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.2.3.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.2.3-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.2.3-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.2.3";s:7:"version";s:5:"4.2.3";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1438026591;s:15:"version_checked";s:5:"4.2.3";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (242, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (243, '_site_transient_timeout_available_translations', '1437852977', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (244, '_site_transient_available_translations', 'a:59:{s:2:"ar";a:8:{s:8:"language";s:2:"ar";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-26 06:57:37";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/ar.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:2;s:3:"ara";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:2:"az";a:8:{s:8:"language";s:2:"az";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:11:"Azerbaijani";s:11:"native_name";s:16:"Azərbaycan dili";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/az.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:2;s:3:"aze";}s:7:"strings";a:1:{s:8:"continue";s:5:"Davam";}}s:5:"bg_BG";a:8:{s:8:"language";s:5:"bg_BG";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-27 06:36:25";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/bg_BG.zip";s:3:"iso";a:2:{i:1;s:2:"bg";i:2;s:3:"bul";}s:7:"strings";a:1:{s:8:"continue";s:22:"Продължение";}}s:5:"bs_BA";a:8:{s:8:"language";s:5:"bs_BA";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-08 17:43:43";s:12:"english_name";s:7:"Bosnian";s:11:"native_name";s:8:"Bosanski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/bs_BA.zip";s:3:"iso";a:2:{i:1;s:2:"bs";i:2;s:3:"bos";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:2:"ca";a:8:{s:8:"language";s:2:"ca";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/ca.zip";s:3:"iso";a:2:{i:1;s:2:"ca";i:2;s:3:"cat";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"cy";a:8:{s:8:"language";s:2:"cy";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-08 11:08:34";s:12:"english_name";s:5:"Welsh";s:11:"native_name";s:7:"Cymraeg";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/cy.zip";s:3:"iso";a:2:{i:1;s:2:"cy";i:2;s:3:"cym";}s:7:"strings";a:1:{s:8:"continue";s:6:"Parhau";}}s:5:"da_DK";a:8:{s:8:"language";s:5:"da_DK";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-06-03 00:26:43";s:12:"english_name";s:6:"Danish";s:11:"native_name";s:5:"Dansk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/da_DK.zip";s:3:"iso";a:2:{i:1;s:2:"da";i:2;s:3:"dan";}s:7:"strings";a:1:{s:8:"continue";s:12:"Forts&#230;t";}}s:5:"de_CH";a:8:{s:8:"language";s:5:"de_CH";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:20:"German (Switzerland)";s:11:"native_name";s:17:"Deutsch (Schweiz)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/de_CH.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:5:"de_DE";a:8:{s:8:"language";s:5:"de_DE";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-24 13:10:37";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/de_DE.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:12:"de_DE_formal";a:8:{s:8:"language";s:12:"de_DE_formal";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-24 13:33:41";s:12:"english_name";s:15:"German (Formal)";s:11:"native_name";s:13:"Deutsch (Sie)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/4.2.3/de_DE_formal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:2:"el";a:8:{s:8:"language";s:2:"el";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-24 12:08:43";s:12:"english_name";s:5:"Greek";s:11:"native_name";s:16:"Ελληνικά";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/el.zip";s:3:"iso";a:2:{i:1;s:2:"el";i:2;s:3:"ell";}s:7:"strings";a:1:{s:8:"continue";s:16:"Συνέχεια";}}s:5:"en_CA";a:8:{s:8:"language";s:5:"en_CA";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:16:"English (Canada)";s:11:"native_name";s:16:"English (Canada)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/en_CA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_GB";a:8:{s:8:"language";s:5:"en_GB";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/en_GB.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_AU";a:8:{s:8:"language";s:5:"en_AU";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:19:"English (Australia)";s:11:"native_name";s:19:"English (Australia)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/en_AU.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"eo";a:8:{s:8:"language";s:2:"eo";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:9:"Esperanto";s:11:"native_name";s:9:"Esperanto";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/eo.zip";s:3:"iso";a:2:{i:1;s:2:"eo";i:2;s:3:"epo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Daŭrigi";}}s:5:"es_MX";a:8:{s:8:"language";s:5:"es_MX";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/es_MX.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_ES";a:8:{s:8:"language";s:5:"es_ES";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/es_ES.zip";s:3:"iso";a:1:{i:1;s:2:"es";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_PE";a:8:{s:8:"language";s:5:"es_PE";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-04-25 13:39:01";s:12:"english_name";s:14:"Spanish (Peru)";s:11:"native_name";s:17:"Español de Perú";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/es_PE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CL";a:8:{s:8:"language";s:5:"es_CL";s:7:"version";s:3:"4.0";s:7:"updated";s:19:"2014-09-04 19:47:01";s:12:"english_name";s:15:"Spanish (Chile)";s:11:"native_name";s:17:"Español de Chile";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.0/es_CL.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"et";a:8:{s:8:"language";s:2:"et";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-05 20:09:08";s:12:"english_name";s:8:"Estonian";s:11:"native_name";s:5:"Eesti";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/et.zip";s:3:"iso";a:2:{i:1;s:2:"et";i:2;s:3:"est";}s:7:"strings";a:1:{s:8:"continue";s:6:"Jätka";}}s:2:"eu";a:8:{s:8:"language";s:2:"eu";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:6:"Basque";s:11:"native_name";s:7:"Euskara";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/eu.zip";s:3:"iso";a:2:{i:1;s:2:"eu";i:2;s:3:"eus";}s:7:"strings";a:1:{s:8:"continue";s:8:"Jarraitu";}}s:5:"fa_IR";a:8:{s:8:"language";s:5:"fa_IR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/fa_IR.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:2:"fi";a:8:{s:8:"language";s:2:"fi";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-15 10:49:37";s:12:"english_name";s:7:"Finnish";s:11:"native_name";s:5:"Suomi";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/fi.zip";s:3:"iso";a:2:{i:1;s:2:"fi";i:2;s:3:"fin";}s:7:"strings";a:1:{s:8:"continue";s:5:"Jatka";}}s:5:"fr_FR";a:8:{s:8:"language";s:5:"fr_FR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-10 14:16:27";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/fr_FR.zip";s:3:"iso";a:1:{i:1;s:2:"fr";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:2:"gd";a:8:{s:8:"language";s:2:"gd";s:7:"version";s:3:"4.0";s:7:"updated";s:19:"2014-09-05 17:37:43";s:12:"english_name";s:15:"Scottish Gaelic";s:11:"native_name";s:9:"Gàidhlig";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.0/gd.zip";s:3:"iso";a:3:{i:1;s:2:"gd";i:2;s:3:"gla";i:3;s:3:"gla";}s:7:"strings";a:1:{s:8:"continue";s:15:"Lean air adhart";}}s:5:"gl_ES";a:8:{s:8:"language";s:5:"gl_ES";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:8:"Galician";s:11:"native_name";s:6:"Galego";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/gl_ES.zip";s:3:"iso";a:2:{i:1;s:2:"gl";i:2;s:3:"glg";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:3:"haz";a:8:{s:8:"language";s:3:"haz";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-26 15:20:27";s:12:"english_name";s:8:"Hazaragi";s:11:"native_name";s:15:"هزاره گی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.1.6/haz.zip";s:3:"iso";a:1:{i:2;s:3:"haz";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"he_IL";a:8:{s:8:"language";s:5:"he_IL";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-12 08:05:04";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/he_IL.zip";s:3:"iso";a:1:{i:1;s:2:"he";}s:7:"strings";a:1:{s:8:"continue";s:12:"להמשיך";}}s:2:"hr";a:8:{s:8:"language";s:2:"hr";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-07 17:26:35";s:12:"english_name";s:8:"Croatian";s:11:"native_name";s:8:"Hrvatski";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/hr.zip";s:3:"iso";a:2:{i:1;s:2:"hr";i:2;s:3:"hrv";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:5:"hu_HU";a:8:{s:8:"language";s:5:"hu_HU";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 11:42:14";s:12:"english_name";s:9:"Hungarian";s:11:"native_name";s:6:"Magyar";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/hu_HU.zip";s:3:"iso";a:2:{i:1;s:2:"hu";i:2;s:3:"hun";}s:7:"strings";a:1:{s:8:"continue";s:7:"Tovább";}}s:5:"id_ID";a:8:{s:8:"language";s:5:"id_ID";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/id_ID.zip";s:3:"iso";a:2:{i:1;s:2:"id";i:2;s:3:"ind";}s:7:"strings";a:1:{s:8:"continue";s:9:"Lanjutkan";}}s:5:"is_IS";a:8:{s:8:"language";s:5:"is_IS";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:9:"Icelandic";s:11:"native_name";s:9:"Íslenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/is_IS.zip";s:3:"iso";a:2:{i:1;s:2:"is";i:2;s:3:"isl";}s:7:"strings";a:1:{s:8:"continue";s:6:"Áfram";}}s:5:"it_IT";a:8:{s:8:"language";s:5:"it_IT";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/it_IT.zip";s:3:"iso";a:2:{i:1;s:2:"it";i:2;s:3:"ita";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"ja";a:8:{s:8:"language";s:2:"ja";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/ja.zip";s:3:"iso";a:1:{i:1;s:2:"ja";}s:7:"strings";a:1:{s:8:"continue";s:9:"続ける";}}s:5:"ko_KR";a:8:{s:8:"language";s:5:"ko_KR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 22:21:58";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/ko_KR.zip";s:3:"iso";a:2:{i:1;s:2:"ko";i:2;s:3:"kor";}s:7:"strings";a:1:{s:8:"continue";s:6:"계속";}}s:5:"lt_LT";a:8:{s:8:"language";s:5:"lt_LT";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-04-23 15:23:08";s:12:"english_name";s:10:"Lithuanian";s:11:"native_name";s:15:"Lietuvių kalba";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/lt_LT.zip";s:3:"iso";a:2:{i:1;s:2:"lt";i:2;s:3:"lit";}s:7:"strings";a:1:{s:8:"continue";s:6:"Tęsti";}}s:5:"my_MM";a:8:{s:8:"language";s:5:"my_MM";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-26 15:57:42";s:12:"english_name";s:17:"Myanmar (Burmese)";s:11:"native_name";s:15:"ဗမာစာ";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.6/my_MM.zip";s:3:"iso";a:2:{i:1;s:2:"my";i:2;s:3:"mya";}s:7:"strings";a:1:{s:8:"continue";s:54:"ဆက်လက်လုပ်ေဆာင်ပါ။";}}s:5:"nb_NO";a:8:{s:8:"language";s:5:"nb_NO";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 22:03:44";s:12:"english_name";s:19:"Norwegian (Bokmål)";s:11:"native_name";s:13:"Norsk bokmål";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/nb_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nb";i:2;s:3:"nob";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsett";}}s:5:"nl_NL";a:8:{s:8:"language";s:5:"nl_NL";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-16 14:25:19";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/nl_NL.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nn_NO";a:8:{s:8:"language";s:5:"nn_NO";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-06-08 07:10:14";s:12:"english_name";s:19:"Norwegian (Nynorsk)";s:11:"native_name";s:13:"Norsk nynorsk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/nn_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nn";i:2;s:3:"nno";}s:7:"strings";a:1:{s:8:"continue";s:9:"Hald fram";}}s:3:"oci";a:8:{s:8:"language";s:3:"oci";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-06-10 17:07:58";s:12:"english_name";s:7:"Occitan";s:11:"native_name";s:7:"Occitan";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.2.2/oci.zip";s:3:"iso";a:2:{i:1;s:2:"oc";i:2;s:3:"oci";}s:7:"strings";a:1:{s:8:"continue";s:9:"Contunhar";}}s:5:"pl_PL";a:8:{s:8:"language";s:5:"pl_PL";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-09 10:15:05";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/pl_PL.zip";s:3:"iso";a:2:{i:1;s:2:"pl";i:2;s:3:"pol";}s:7:"strings";a:1:{s:8:"continue";s:9:"Kontynuuj";}}s:2:"ps";a:8:{s:8:"language";s:2:"ps";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-29 22:19:48";s:12:"english_name";s:6:"Pashto";s:11:"native_name";s:8:"پښتو";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.6/ps.zip";s:3:"iso";a:1:{i:1;s:2:"ps";}s:7:"strings";a:1:{s:8:"continue";s:8:"دوام";}}s:5:"pt_PT";a:8:{s:8:"language";s:5:"pt_PT";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-22 10:25:51";s:12:"english_name";s:21:"Portuguese (Portugal)";s:11:"native_name";s:10:"Português";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/pt_PT.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_BR";a:8:{s:8:"language";s:5:"pt_BR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/pt_BR.zip";s:3:"iso";a:2:{i:1;s:2:"pt";i:2;s:3:"por";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"ro_RO";a:8:{s:8:"language";s:5:"ro_RO";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-08 14:53:48";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/ro_RO.zip";s:3:"iso";a:2:{i:1;s:2:"ro";i:2;s:3:"ron";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuă";}}s:5:"ru_RU";a:8:{s:8:"language";s:5:"ru_RU";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 15:41:00";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/ru_RU.zip";s:3:"iso";a:2:{i:1;s:2:"ru";i:2;s:3:"rus";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продолжить";}}s:5:"sk_SK";a:8:{s:8:"language";s:5:"sk_SK";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-26 09:29:23";s:12:"english_name";s:6:"Slovak";s:11:"native_name";s:11:"Slovenčina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/sk_SK.zip";s:3:"iso";a:2:{i:1;s:2:"sk";i:2;s:3:"slk";}s:7:"strings";a:1:{s:8:"continue";s:12:"Pokračovať";}}s:5:"sl_SI";a:8:{s:8:"language";s:5:"sl_SI";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-26 16:25:46";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.6/sl_SI.zip";s:3:"iso";a:2:{i:1;s:2:"sl";i:2;s:3:"slv";}s:7:"strings";a:1:{s:8:"continue";s:10:"Nadaljujte";}}s:2:"sq";a:8:{s:8:"language";s:2:"sq";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-29 08:27:12";s:12:"english_name";s:8:"Albanian";s:11:"native_name";s:5:"Shqip";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/sq.zip";s:3:"iso";a:2:{i:1;s:2:"sq";i:2;s:3:"sqi";}s:7:"strings";a:1:{s:8:"continue";s:6:"Vazhdo";}}s:5:"sr_RS";a:8:{s:8:"language";s:5:"sr_RS";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Serbian";s:11:"native_name";s:23:"Српски језик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/sr_RS.zip";s:3:"iso";a:2:{i:1;s:2:"sr";i:2;s:3:"srp";}s:7:"strings";a:1:{s:8:"continue";s:14:"Настави";}}s:5:"sv_SE";a:8:{s:8:"language";s:5:"sv_SE";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-12 00:55:52";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/sv_SE.zip";s:3:"iso";a:2:{i:1;s:2:"sv";i:2;s:3:"swe";}s:7:"strings";a:1:{s:8:"continue";s:9:"Fortsätt";}}s:2:"th";a:8:{s:8:"language";s:2:"th";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:4:"Thai";s:11:"native_name";s:9:"ไทย";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/th.zip";s:3:"iso";a:2:{i:1;s:2:"th";i:2;s:3:"tha";}s:7:"strings";a:1:{s:8:"continue";s:15:"ต่อไป";}}s:2:"tl";a:8:{s:8:"language";s:2:"tl";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-06 10:10:09";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/tl.zip";s:3:"iso";a:2:{i:1;s:2:"tl";i:2;s:3:"tgl";}s:7:"strings";a:1:{s:8:"continue";s:10:"Magpatuloy";}}s:5:"tr_TR";a:8:{s:8:"language";s:5:"tr_TR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-24 13:30:08";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/tr_TR.zip";s:3:"iso";a:2:{i:1;s:2:"tr";i:2;s:3:"tur";}s:7:"strings";a:1:{s:8:"continue";s:5:"Devam";}}s:5:"ug_CN";a:8:{s:8:"language";s:5:"ug_CN";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-26 16:45:38";s:12:"english_name";s:6:"Uighur";s:11:"native_name";s:9:"Uyƣurqə";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.6/ug_CN.zip";s:3:"iso";a:2:{i:1;s:2:"ug";i:2;s:3:"uig";}s:7:"strings";a:1:{s:8:"continue";s:26:"داۋاملاشتۇرۇش";}}s:2:"uk";a:8:{s:8:"language";s:2:"uk";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-05 10:51:50";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/uk.zip";s:3:"iso";a:2:{i:1;s:2:"uk";i:2;s:3:"ukr";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продовжити";}}s:5:"zh_TW";a:8:{s:8:"language";s:5:"zh_TW";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 13:52:20";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/zh_TW.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}s:5:"zh_CN";a:8:{s:8:"language";s:5:"zh_CN";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:15:"Chinese (China)";s:11:"native_name";s:12:"简体中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/zh_CN.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"继续";}}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (245, 'WPLANG', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (251, 'rewrite_rules', 'a:67:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (286, '_site_transient_timeout_theme_roots', '1438028393', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (287, '_site_transient_theme_roots', 'a:4:{s:16:"liljaingva-theme";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (290, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1438026603;s:8:"response";a:1:{s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"3.2.7";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.3.2.7.zip";}}s:12:"translations";a:0:{}s:9:"no_update";a:2:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.1.3";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.1.3.zip";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (291, '_site_transient_timeout_browser_ad17c1ed7df82fa5162f7a32bfcc80ed', '1438632195', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (292, '_site_transient_browser_ad17c1ed7df82fa5162f7a32bfcc80ed', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"44.0.2403.107";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (293, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1438070600', 'no') ; 
INSERT INTO `wpLi_options` VALUES (294, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:26:"https://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 19:30:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:39:"http://wordpress.org/?v=4.3-beta4-33448";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 4.2.3 Security and Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2015/07/wordpress-4-2-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2015/07/wordpress-4-2-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 11:21:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3807";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:380:"WordPress 4.2.3 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was initially reported by Jon Cave and [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Gary Pendergast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2708:"<p>WordPress 4.2.3 is now available. This is a<strong> security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was initially reported by <a href="https://profiles.wordpress.org/duck_">Jon Cave</a> and fixed by <a href="http://www.miqrogroove.com/">Robert Chapin</a>, both of the WordPress security team, and later reported by <a href="http://klikki.fi/">Jouko Pynnönen</a>.</p>
<p>We also fixed an issue where it was possible for a user with Subscriber permissions to create a draft through Quick Draft. Reported by Netanel Rubin from <a href="https://www.checkpoint.com/">Check Point Software Technologies</a>.</p>
<p>Our thanks to those who have practiced <a href="https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.2.3 also contains fixes for 20 bugs from 4.2. For more information, see the <a href="https://codex.wordpress.org/Version_4.2.3">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/4.2?rev=33382&amp;stop_rev=32430">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 4.2.3</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.3.</p>
<p>Thanks to everyone who contributed to 4.2.3:</p>
<p><a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/chriscct7">Chris Christoff</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/iseulde">Ella Iseulde Van Dorpe</a>, <a href="https://profiles.wordpress.org/gabrielperezs">Gabriel Pérez</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/mdawaffe">Mike Adams</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/magicroundabout">Ross Wintle</a>, and <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-2-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jul 2015 21:55:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3796";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:337:"WordPress 4.3 Beta 4 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Konstantin Obenland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2212:"<p>WordPress 4.3 Beta 4 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="https://wordpress.org/wordpress-4.3-beta4.zip">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, check out the <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/">Beta 1</a>, <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/">Beta 2</a>, and <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/">Beta 3</a> blog posts. Some of the changes in Beta 4 include:</p>
<ul>
<li><span class="s1">Fixed several bugs and broken flows in the </span><span class="s1"><strong>publish box </strong></span><span class="s1">in the edit screen.</span></li>
<li>Addressed a number of edge cases for word count in the <strong>editor</strong>.</li>
<li><span class="s1"><strong>Site icons</strong> </span><span class="s1">can now be previewed within the customizer. The feature has been removed from general settings.</span></li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href="https://core.trac.wordpress.org/log/trunk?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33369&amp;stop_rev=33289">more than 60 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="https://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3">everything we’ve fixed</a>.</p>
<p><em>Few Tickets Remain</em><br />
<em>Edge Cases Disappearing</em><br />
<em>You Must Test Today</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jul 2015 21:49:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3787";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:337:"WordPress 4.3 Beta 3 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Konstantin Obenland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2529:"<p>WordPress 4.3 Beta 3 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="https://wordpress.org/wordpress-4.3-beta3.zip">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, check out the <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/">Beta 1</a> and <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/">Beta 2</a> blog posts. Some of the changes in Beta 3 include:</p>
<ul>
<li>Performance improvements for <strong>Menus in the Customizer</strong>, as well as bug fixes and visual enhancements.</li>
<li>Added <strong>Site Icon</strong> to the Customizer. The feature is now complete and requires lots of testing. Please help us ensure the site icon feature works well in both Settings and the Customizer.</li>
<li>The improvements to <strong>Passwords</strong> have been added to the installation flow. When installing and setting up WordPress, a strong password will be suggested to site administrators. Please test and let us know if you encounter issues.</li>
<li>Improved <strong>accessibility of comments and media list tables</strong>. If you use a screen reader, please let us know if you encounter any issues.</li>
<li>Lots and lots of code documentation improvements.</li>
<li><strong>Various other bug fixes</strong>. We&#8217;ve made <a href="https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33286&amp;stop_rev=33141&amp;limit=150">more than 140 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="https://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3">everything we’ve fixed</a>.</p>
<p><em>Want to test new things?</em><br />
<em>Wonder how four three shapes up?</em><br />
<em>Answer: beta three</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Jul 2015 22:04:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3769";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:337:"WordPress 4.3 Beta 2 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Konstantin Obenland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2876:"<p>WordPress 4.3 Beta 2 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="https://wordpress.org/wordpress-4.3-beta2.zip">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/">check out the Beta 1 blog post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Fixed an issue in beta 1 where an alert appeared when saving or publishing a new post/page for the first time.</li>
<li><strong><strong>Customizer</strong></strong> improvements including enhanced accessibility, smoother menu creation and location assignment, and the ability to handle nameless menus. Please help us test menus in the Customizer to fix any remaining edge cases!</li>
<li>More robust<strong> list tables</strong> with full content support on small screens and a fallback for the primary column for custom list tables. We&#8217;d love to know how these list tables, such as All Posts and Comments, work for you now on small screen devices.</li>
<li>The <strong>Site Icon</strong> feature has been improved so that cropping is skipped if the image is the exact size (512px square) and the media modal now suggests a minimum icon size. Please let us know how the flow feels and if you encounter any glitches!</li>
<li>The <strong>toolbar</strong> now has a direct link to the customizer, along with quick access to themes, widgets, and menus in the dashboard.</li>
<li>We enabled <strong>utf8mb4 for MySQL</strong> extension users, which was previously unintentionally limited to MySQLi users. Please let us know if you run into any issues.</li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href="https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33138&amp;stop_rev=33046">almost 100 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="https://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;milestone=4.3&amp;group=component&amp;order=priority">everything we’ve fixed</a>.</p>
<p><em>Edges polished up</em><br />
<em>Features meliorated</em><br />
<em>Beta Two: go test!</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordCamps Update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/news/2015/07/wordcamps-update/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/07/wordcamps-update/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Jul 2015 16:13:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"Events";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3758";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:311:"Last week saw the halfway point for 2015, yay! This seems like a good time to update you on WordCamp happenings in the first half of this year. There have been 39 WordCamps in 2015 so far, with events organized in 17 different countries and on 5 continents. More than 14,000 people have registered for [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Andrea Middleton";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:9419:"<p>Last week saw the halfway point for 2015, yay! This seems like a good time to update you on WordCamp happenings in the first half of this year.</p>
<p>There have been <a href="https://central.wordcamp.org/schedule/past-wordcamps/">39 WordCamps in 2015</a> so far, with events organized in 17 different countries and on 5 continents. More than 14,000 people have registered for WordCamp tickets so far this year, isn&#8217;t that amazing?</p>
<p><a href="https://europe.wordcamp.org/2015/">WordCamp Europe</a> was held in Seville, Spain just a few weeks ago, with close to 1,000 registered participants and over 500 live stream participants. You can watch  <a href="http://wordpress.tv/2015/07/04/matt-mullenweg-keynote-qanda-wordcamp-europe-2015/">Matt Mullenweg’s keynote Q&amp;A</a> session from WordCamp Europe right now on WordPress.tv.</p>
<p>WordPress.tv has published 537 videos so far in 2015 from WordCamps around the world. Some of the more popular 2015 WordCamp talks on WordPress.tv include <a href="http://wordpress.tv/2015/03/13/tammie-lister-theme-dont-be-my-everything/">Tammie Lister: Theme, Don’t Be My Everything </a>from WordCamp Maui, <a href="http://wordpress.tv/2015/04/17/jenny-munn-seo-for-2015-whats-in-whats-out-and-how-to-be-in-it-to-win-it-for-good/">Jenny Munn: SEO for 2015 – What’s In, What’s Out and How to Be In It to Win It (For Good)</a> from WordCamp Atlanta, <a href="http://wordpress.tv/2015/02/27/fabrice-ducarme-les-constructeurs-de-page-pour-wordpress/">Fabrice Ducarme: Les Constructeurs de Page pour WordPress</a> from WordCamp Paris, <a href="http://wordpress.tv/2015/06/02/ben-furfie-how-to-value-price-websites/">Ben Furfie: How to Value Price Websites</a> from WordCamp London, and <a href="http://wordpress.tv/2015/06/09/morten-rand-hendriksen-building-themes-from-scratch-using-underscores-_s/">Morten Rand-Hendriksen: Building Themes From Scratch Using Underscores (_S)</a> from WordCamp Seattle. Check them out!</p>
<h3>Lots of great WordCamps are still to come</h3>
<p><a href="http://ma.tt/2015/06/wordcamp-us-survey/">WordCamp US</a> is currently in pre-planning, in the process of deciding on a host city. The following cities have proposed themselves as a great place to host the first WordCamp US: Chattanooga, Chicago, Detroit, Orlando, Philadelphia, and Phoenix. It&#8217;s possible the first WordCamp US will be held in 2016 so we can organize the best first WordCamp US imaginable.</p>
<p>At this time, there are 28 <a href="https://central.wordcamp.org/schedule/">WordCamps</a>, in 9 different countries, that have announced their dates for the rest of 2015. Twelve of these have tickets on sale:</p>
<ul>
<li><a href="https://columbus.wordcamp.org/2015/">WordCamp Columbus</a>, Columbus, Ohio: July 17-18</li>
<li><a href="https://scranton.wordcamp.org/2015/">WordCamp Scranton</a>, Scranton, Pennsylvania: July 18</li>
<li><a href="https://boston.wordcamp.org/2015/">WordCamp Boston</a>, Boston, Massachussetts: July 18-19</li>
<li><a href="https://milwaukee.wordcamp.org/2015/">WordCamp Milwaukee</a>, Milwaukee, Wisconsin: July 24-26</li>
<li><a href="https://asheville.wordcamp.org/2015/">WordCamp Asheville</a>, Asheville, North Carolina: July 24-26</li>
<li><a href="https://kansai.wordcamp.org/2015/">WordCamp Kansai</a>, Kansai, Japan: July 25-26</li>
<li><a href="https://fayetteville.wordcamp.org/2015/">WordCamp Fayetteville</a>, Fayetteville, Arkansas: July 31-August 2</li>
<li><a href="https://brighton.buddycamp.org/2015/">BuddyCamp Brighton</a>,  Brighton, UK: August 8</li>
<li><a href="https://vancouver.wordcamp.org/2015/">WordCamp Vancouver, BC,</a> Vancouver, BC, Canada: August 15-16</li>
<li><a href="https://russia.wordcamp.org/2015/">WordCamp Russia</a>, Moscow, Russia: August 15</li>
<li><a href="https://norrkoping.wordcamp.org/2015/">WordCamp Norrköping</a>, Norrköping, Sweden: August 28-29</li>
<li><a href="https://croatia.wordcamp.org/2015/">WordCamp Croatia</a>, Rijeka, Croatia: September 5-6</li>
<li><a href="https://krakow.wordcamp.org/2015/">WordCamp Krakow,</a>  Krakow, Poland: September 12-13</li>
<li><a href="https://nyc.wordcamp.org/2015/">WordCamp NYC</a>, New York City, New York: October 30-November 1</li>
</ul>
<p>The other 16 events don’t have tickets on sale yet, but they’ve set their dates! Subscribe to the sites to find out when registration opens:</p>
<ul>
<li><a href="https://pune.wordcamp.org/2015/">WordCamp Pune</a>, Pune, India: September 6</li>
<li><a href="https://capetown.wordcamp.org/2015/">WordCamp Cape Town</a>, Cape Town, South Africa: September 10-11</li>
<li><a href="https://baltimore.wordcamp.org/2015/">WordCamp Baltimore</a>, Baltimore, Maryland: September 12</li>
<li><a href="https://slc.wordcamp.org/2015/">WordCamp Salt Lake City</a>, Salt Lake City, Utah: September 12</li>
<li><a href="https://lithuania.wordcamp.org/2015/">WordCamp Lithuania</a>, Vilnius, Lithuania: September 19</li>
<li><a href="https://vegas.wordcamp.org/2015">WordCamp Vegas</a>, Las Vegas, Nevada: September 19-20</li>
<li><a href="https://switzerland.wordcamp.org/2015/">WordCamp Switzerland</a>, Zurich, Switzerland: September 19-20</li>
<li><a href="https://tampa.wordcamp.org/2015/">WordCamp Tampa</a>, Tampa, Florida: September 25-27</li>
<li><a href="https://rhodeisland.wordcamp.org/2015/">WordCamp Rhode Island</a>,  Providence, Rhode Island: September 25-26</li>
<li><a href="https://la.wordcamp.org/2015/">WordCamp Los Angeles</a>, Los Angeles, California: September 26-27</li>
<li><a href="https://denmark.wordcamp.org/2015/">WordCamp Denmark,</a>  Copenhagen, Denmark: October 3-4</li>
<li><a href="https://toronto.wordcamp.org/2015">WordCamp Toronto</a>, Toronto, Ontario, Canada: October 3-4</li>
<li><a href="https://hamptonroads.wordcamp.org/2015/">WordCamp Hampton Roads, </a>  Virginia Beach, VA, USA: October 17</li>
<li><a href="https://annarbor.wordcamp.org/2015">WordCamp Ann Arbor</a>, Ann Arbor, Michigan: October 24</li>
<li><a href="https://portland.wordcamp.org/2015/">WordCamp Portland</a>,  Portland, OR: October 24-25</li>
</ul>
<p>On top of all those exciting community events, there are 26 WordCamps in pre-planning as they look for the right event space.  If you have a great idea for a free or cheap WordCamp venue in any of the below locations, get in touch with the organizers through the WordCamp sites:</p>
<ul>
<li><a href="https://dfw.wordcamp.org/2015/">WordCamp DFW</a>:  Dallas/Fort Worth, Texas</li>
<li><a href="https://riodejaneiro.wordcamp.org/2015/">WordCamp Rio</a>: Rio de Janeiro, Brazil</li>
<li><a href="https://saratoga.wordcamp.org/2015/">WordCamp Saratoga</a>:  Saratoga Springs, New York</li>
<li><a href="https://sofia.wordcamp.org/2015">WordCamp Sofia</a>:  Sofia, Bulgaria</li>
<li><a href="https://austin.wordcamp.org/2015/">WordCamp Austin</a>:  Austin, TX</li>
<li><a href="https://ottawa.wordcamp.org/2015/">WordCamp Ottawa</a>:  Ottawa, Canada</li>
<li><a href="https://charleston.wordcamp.org/2015/">WordCamp Charleston</a>:  Charleston, South Carolina</li>
<li><a href="https://chicago.wordcamp.org/2015/">WordCamp Chicago</a>:  Chicago, Illinois</li>
<li><a href="https://albuquerque.wordcamp.org/2015/">WordCamp Albuquerque</a>:  Albuquerque, New Mexico</li>
<li><a href="https://prague.wordcamp.org/2015/">WordCamp Prague</a>:  Prague, Czech Republic</li>
<li><a href="https://seoul.wordcamp.org/2014/">WordCamp Seoul: </a>Seoul, South Korea</li>
<li><a href="https://louisville.wordcamp.org/2014/">WordCamp Louisville</a>: Louisville, Kentucky</li>
<li><a href="https://omaha.wordcamp.org/2015/">WordCamp Omaha</a>:  Omaha, Nebraska</li>
<li><a href="https://grandrapids.wordcamp.org/2015/">WordCamp Grand Rapids</a>:  Grand Rapids, Michigan</li>
<li><a href="https://easttroy.wordcamp.org/2015/">WordCamp East Troy</a>:  East Troy, Wisconsin</li>
<li><a href="https://palmademallorca.wordcamp.org/2015">WordCamp Mallorca</a>: Palma de Mallorca, Spain</li>
<li><a href="https://edinburgh.wordcamp.org/2015/">WordCamp Edinburgh</a>:  Edinburgh, United Kingdom</li>
<li><a href="https://orlando.wordcamp.org/2015/">WordCamp Orlando</a>:  Orlando, Florida</li>
<li><a href="https://mexico.wordcamp.org/2015/">WordCamp Mexico City</a>:  Mexico City, Mexico</li>
<li><a href="https://netherlands.wordcamp.org/2015/">WordCamp Netherlands</a>:  Utrecht, Netherlands</li>
<li><a href="https://phoenix.wordcamp.org/2016/">WordCamp Phoenix</a>:  Phoenix, Arizona</li>
<li><a href="https://saopaulo.wordcamp.org/2015/">WordCamp São Paulo</a>:  São Paulo, Brazil</li>
<li><a href="https://manchester.wordcamp.org/2015/">WordCamp Manchester</a>:  Manchester, United Kingdom</li>
<li><a href="https://tokyo.wordcamp.org/2015/">WordCamp Tokyo</a>:  Tokyo, Japan</li>
<li><a href="https://lima.wordcamp.org/2015/">WordCamp Lima</a>:  Lima, Peru</li>
<li><a href="https://seattle.wordcamp.org/2015-beginner/">WordCamp Seattle: Beginner</a>: Seattle, WA</li>
</ul>
<p>Don’t see your city on the list, but yearning for a local WordCamp? WordCamps are organized by local volunteers from the WordPress community, and we have a whole team of people to support new organizers setting up a first-time WordCamp. If you want to bring WordCamp to town, check out how you can <a href="https://central.wordcamp.org/become-an-organizer/">become a WordCamp organizer</a>!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/news/2015/07/wordcamps-update/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Jul 2015 01:30:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3738";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"WordPress 4.3 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Konstantin Obenland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4352:"<p>WordPress 4.3 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.3-beta1.zip">download the beta here</a> (zip).</p>
<p>4.3 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Menus</strong> can now be managed with the <strong>Customizer</strong>, which allows you to live preview changes you’re making without changing your site for visitors until you’re ready. We&#8217;re especially interested to know if this helps streamline the process of setting up your site (<a href="https://core.trac.wordpress.org/ticket/32576">#32576</a>).</li>
<li>Take control of another piece of your site with the <strong>Site Icon</strong> feature. You can now manage your site’s favicon and app icon from the admin area (<a href="https://core.trac.wordpress.org/ticket/16434">#16434</a>).</li>
<li>We put a lot of work into <strong>Better Passwords</strong> throughout WordPress. Now, WordPress will limit the life time of password resets, no longer send passwords via email, and generate and suggest secure passwords for you. Try it out and let us know what you think! (<a href="https://core.trac.wordpress.org/ticket/32589">#32589</a>)</li>
<li>We’ve also added <strong>Editor Improvements</strong>. Certain text patterns are automatically transformed as you type, including <code>*</code> and <code>-</code> transforming into unordered lists, <code>1.</code> and <code>1)</code> for ordered lists, <code>&gt;</code> for blockquotes and two to six number signs (<code>#</code>) for headings (<a href="https://core.trac.wordpress.org/ticket/31441">#31441</a>).</li>
<li>We’ve improved the <strong>list view</strong> across the admin dashboard. Now, when you view your posts and pages <strong>on small screen devices</strong>, columns are not truncated and can be toggled into view (<a href="https://core.trac.wordpress.org/ticket/32395">#32395</a>).</li>
</ul>
<p><strong>Developers</strong>: There have been a few of changes for you to test as well, including:</p>
<ul>
<li><strong>Taxonomy Roadmap:</strong> Terms shared across multiple taxonomies will <a href="https://make.wordpress.org/core/2015/06/09/eliminating-shared-taxonomy-terms-in-wordpress-4-3/">now be split</a> into separate terms on update to 4.3. Please let us know if you hit any snags (<a href="https://core.trac.wordpress.org/ticket/30261">#30261</a>).</li>
<li>Added <code>singular.php</code> to the template hierarchy as a fallback for <code>single.php</code> and <code>page.php</code>. (<a href="https://core.trac.wordpress.org/ticket/22314">#22314</a>).</li>
<li>The old Distraction Free Writing code was removed (<a href="https://core.trac.wordpress.org/ticket/30949">#30949</a>).</li>
<li>List tables now can (and often should) have a primary column defined. We’re working on a fallback for existing custom list tables but right now they likely have some breakage in the aforementioned responsive view (<a href="https://core.trac.wordpress.org/ticket/25408">#25408</a>).</li>
</ul>
<p>If you want a more in-depth view of what changes have made it into 4.3, <a href="https://make.wordpress.org/core/tag/4-3/">check out all 4.3-tagged posts</a> on the main development blog.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3">everything we’ve fixed</a> so far.</p>
<p>Happy testing!</p>
<p><em>Site icons for all</em><br />
<em>Live preview menu changes</em><br />
<em>Four three beta now</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 4.2.2 Security and Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2015/05/wordpress-4-2-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2015/05/wordpress-4-2-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 May 2015 02:24:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3718";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 4.2.2 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. Version 4.2.2 addresses two security issues: The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Samuel Sidler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3213:"<p>WordPress 4.2.2 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>Version 4.2.2 addresses two security issues:</p>
<ul>
<li>The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site scripting attack. All affected themes and plugins hosted on <a href="https://wordpress.org/">WordPress.org</a> (including the Twenty Fifteen default theme) have been updated today by the WordPress security team to address this issue by removing this nonessential file. To help protect other Genericons usage, WordPress 4.2.2 proactively scans the wp-content directory for this HTML file and removes it. Reported by Robert Abela of <a href="http://netsparker.com">Netsparker</a>.</li>
<li>WordPress versions 4.2 and earlier are affected by a <a href="https://wordpress.org/news/2015/04/wordpress-4-2-1/">critical cross-site scripting vulnerability</a>, which could enable anonymous users to compromise a site. WordPress 4.2.2 includes a comprehensive fix for this issue. Reported separately by Rice Adu and Tong Shi from Baidu[X-team].</li>
</ul>
<p>The release also includes hardening for a potential cross-site scripting vulnerability when using the visual editor. This issue was reported by Mahadev Subedi.</p>
<p>Our thanks to those who have practiced <a href="https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.2.2 also contains fixes for 13 bugs from 4.2. For more information, see the <a href="https://codex.wordpress.org/Version_4.2.2">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/4.2?rev=32418&amp;stop_rev=32324">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 4.2.2</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.2.</p>
<p>Thanks to everyone who contributed to 4.2.2:</p>
<p><a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/iseulde">Ella Iseulde Van Dorpe</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/hnle">Hinaloe</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/mdawaffe">Mike Adams</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/taka2">taka2</a>, and <a href="https://profiles.wordpress.org/willstedt">willstedt</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/05/wordpress-4-2-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 4.2.1 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2015/04/wordpress-4-2-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2015/04/wordpress-4-2-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 27 Apr 2015 18:34:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3706";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:366:"WordPress 4.2.1 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. A few hours ago, the WordPress team was made aware of a cross-site scripting vulnerability, which could enable commenters to compromise a site. The vulnerability was discovered by Jouko Pynnönen. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Gary Pendergast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1010:"<p>WordPress 4.2.1 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>A few hours ago, the WordPress team was made aware of a cross-site scripting vulnerability, which could enable commenters to compromise a site. The vulnerability was discovered by <a href="http://klikki.fi/">Jouko Pynnönen</a>.</p>
<p>WordPress 4.2.1 has begun to roll out as an automatic background update, for sites that <a href="https://wordpress.org/plugins/background-update-tester/">support</a> those.</p>
<p>For more information, see the <a href="https://codex.wordpress.org/Version_4.2.1">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/4.2?rev=32311&amp;stop_rev=32300">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 4.2.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now&#8221;.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/04/wordpress-4-2-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WordPress 4.2 “Powell”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"https://wordpress.org/news/2015/04/powell/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2015/04/powell/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Apr 2015 18:35:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:3:"4.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3642";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:343:"Version 4.2 of WordPress, named &#8220;Powell&#8221; in honor of jazz pianist Bud Powell, is available for download or update in your WordPress dashboard. New features in 4.2 help you communicate and share, globally. An easier way to share content Clip it, edit it, publish it. Get familiar with the new and improved Press This. From [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:29655:"<p>Version 4.2 of WordPress, named &#8220;Powell&#8221; in honor of jazz pianist <a href="https://en.wikipedia.org/wiki/Bud_Powell">Bud Powell</a>, is available for <a href="https://wordpress.org/download/">download</a> or update in your WordPress dashboard. New features in 4.2 help you communicate and share, globally.</p>
<div id="v-e9kH4FzP-1" class="video-player"><embed id="v-e9kH4FzP-1-video" src="https://v0.wordpress.com/player.swf?v=1.04&amp;guid=e9kH4FzP&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" title="Introducing WordPress 4.2 &quot;Powell&quot;" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<hr />
<h2 style="text-align: center">An easier way to share content</h2>
<p><img class="alignnone size-full wp-image-3677" src="https://wordpress.org/news/files/2015/04/4.2-press-this-2.jpg" alt="Press This" width="1000" height="832" />Clip it, edit it, publish it. Get familiar with the new and improved Press This. From the Tools menu, add Press This to your browser bookmark bar or your mobile device home screen. Once installed you can share your content with lightning speed. Sharing your favorite videos, images, and content has never been this fast or this easy.</p>
<hr />
<h2 style="text-align: center">Extended character support</h2>
<p><img class="alignnone size-full wp-image-3676" src="https://wordpress.org/news/files/2015/04/4.2-characters.png" alt="Character support for emoji, special characters" width="1000" height="832" />Writing in WordPress, whatever your language, just got better. WordPress 4.2 supports a host of new characters out-of-the-box, including native Chinese, Japanese, and Korean characters, musical and mathematical symbols, and hieroglyphs.</p>
<p>Don’t use any of those characters? You can still have fun — emoji are now available in WordPress! Get creative and decorate your content with <img src="https://s.w.org/images/core/emoji/72x72/1f499.png" alt="💙" class="wp-smiley" style="height: 1em; max-height: 1em;" />, <img src="https://s.w.org/images/core/emoji/72x72/1f438.png" alt="🐸" class="wp-smiley" style="height: 1em; max-height: 1em;" />, <img src="https://s.w.org/images/core/emoji/72x72/1f412.png" alt="🐒" class="wp-smiley" style="height: 1em; max-height: 1em;" />, <img src="https://s.w.org/images/core/emoji/72x72/1f355.png" alt="🍕" class="wp-smiley" style="height: 1em; max-height: 1em;" />, and all the many other <a href="https://codex.wordpress.org/Emoji">emoji</a>.</p>
<hr />
<div><img class="alignright size-medium wp-image-3656" src="https://wordpress.org/news/files/2015/04/4.2-theme-switcher-300x230.png" alt="Customizer theme switcher" width="288" height="221" /></p>
<h3>Switch themes in the Customizer</h3>
<p>Browse and preview your installed themes from the Customizer. Make sure the theme looks great with your content, before it debuts on your site.</p>
</div>
<div style="clear: both"></div>
<div><img class="alignright size-medium wp-image-3653" src="https://wordpress.org/news/files/2015/04/4.2-embeds-300x230.png" alt="Tumbr.com oEmbed example" width="288" height="221" /></p>
<h3>Even more embeds</h3>
<p>Paste links from Tumblr.com and Kickstarter and watch them magically appear right in the editor. With every release, your publishing and editing experience get closer together.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright size-medium wp-image-3654" src="https://wordpress.org/news/files/2015/04/4.2-plugins-300x230.png" alt="Inline plugin updates" width="288" height="221" /></p>
<h3>Streamlined plugin updates</h3>
<p>Goodbye boring loading screen, hello smooth and simple plugin updates. Click <em>Update Now</em> and watch the magic happen.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Under the Hood</h2>
<h5>utf8mb4 support</h5>
<p>Database character encoding has changed from utf8 to utf8mb4, which adds support for a whole range of new 4-byte characters.</p>
<h5>JavaScript accessibility</h5>
<p>You can now send audible notifications to screen readers in JavaScript with <code>wp.a11y.speak()</code>. Pass it a string, and an update will be sent to a dedicated ARIA live notifications area.</p>
<h5>Shared term splitting</h5>
<p>Terms shared across multiple taxonomies will be split when one of them is updated. Find out more in the <a href="https://developer.wordpress.org/plugins/taxonomy/working-with-split-terms-in-wp-4-2/">Plugin Developer Handbook</a>.</p>
<h5>Complex query ordering</h5>
<p><code>WP_Query</code>, <code>WP_Comment_Query</code>, and <code>WP_User_Query</code> now support complex ordering with named meta query clauses.</p>
<hr />
<h2 style="text-align: center">The Team</h2>
<p><a class="alignleft" href="https://profiles.wordpress.org/drewapicture"><img src="https://www.gravatar.com/avatar/95c934fa2c3362794bf62ff8c59ada08?d=mm&amp;s=150&amp;r=G" alt="Drew Jaynes" width="90" height="90" /></a>This release was led by <a href="http://werdswords.com">Drew Jaynes</a>, with the help of these fine individuals. There are 283 contributors with props in this release, a new high. Pull up some Bud Powell on your music service of choice, and check out some of their profiles:</p>
<a href="https://profiles.wordpress.org/mercime">@mercime</a>, <a href="https://profiles.wordpress.org/a5hleyrich">A5hleyRich</a>, <a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/abhishekfdd">abhishekfdd</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/mrahmadawais">Ahmad Awais</a>, <a href="https://profiles.wordpress.org/alexkingorg">Alex King</a>, <a href="https://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="https://profiles.wordpress.org/deconf">Alin Marcu</a>, <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/awbauer">Andrew Bauer</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/ankitgadertcampcom">Ankit Gade</a>, <a href="https://profiles.wordpress.org/ankit-k-gupta">Ankit K Gupta</a>, <a href="https://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="https://profiles.wordpress.org/aramzs">Aram Zucker-Scharff</a>, <a href="https://profiles.wordpress.org/arminbraun">ArminBraun</a>, <a href="https://profiles.wordpress.org/ashfame">Ashfame</a>, <a href="https://profiles.wordpress.org/filosofo">Austin Matzko</a>, <a href="https://profiles.wordpress.org/avryl">avryl</a>, <a href="https://profiles.wordpress.org/barrykooij">Barry Kooij</a>, <a href="https://profiles.wordpress.org/beaulebens">Beau Lebens</a>, <a href="https://profiles.wordpress.org/bendoh">Ben Doherty (Oomph, Inc)</a>, <a href="https://profiles.wordpress.org/bananastalktome">Billy Schneider</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone B. Gorges</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/krogsgard">Brian Krogsgard</a>, <a href="https://profiles.wordpress.org/bswatson">Brian Watson</a>, <a href="https://profiles.wordpress.org/calevans">CalEvans</a>, <a href="https://profiles.wordpress.org/carolinegeven">carolinegeven</a>, <a href="https://profiles.wordpress.org/caseypatrickdriscoll">Casey Driscoll</a>, <a href="https://profiles.wordpress.org/caspie">Caspie</a>, <a href="https://profiles.wordpress.org/cdog">Catalin Dogaru</a>, <a href="https://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="https://profiles.wordpress.org/chipx86">chipx86</a>, <a href="https://profiles.wordpress.org/chrico">ChriCo</a>, <a href="https://profiles.wordpress.org/cbaldelomar">Chris Baldelomar</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chriscct7">chriscct7</a>, <a href="https://profiles.wordpress.org/cfoellmann">Christian Foellmann</a>, <a href="https://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="https://profiles.wordpress.org/clifgriffin">Clifton Griffin</a>, <a href="https://profiles.wordpress.org/codix">Code Master</a>, <a href="https://profiles.wordpress.org/corphi">Corphi</a>, <a href="https://profiles.wordpress.org/couturefreak">Courtney Ivey</a>, <a href="https://profiles.wordpress.org/craig-ralston">Craig Ralston</a>, <a href="https://profiles.wordpress.org/cweiske">cweiske</a>, <a href="https://profiles.wordpress.org/extendwings">Daisuke Takahashi</a>, <a href="https://profiles.wordpress.org/timersys">Damian</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/dkotter">Darin Kotter</a>, <a href="https://profiles.wordpress.org/nerrad">Darren Ethier (nerrad)</a>, <a href="https://profiles.wordpress.org/dllh">Daryl L. L. Houston (dllh)</a>, <a href="https://profiles.wordpress.org/dmchale">Dave McHale</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/folletto">Davide \'Folletto\' Casali</a>, <a href="https://profiles.wordpress.org/davideugenepratt">davideugenepratt</a>, <a href="https://profiles.wordpress.org/davidhamiltron">davidhamiltron</a>, <a href="https://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="https://profiles.wordpress.org/valendesigns">Derek Herman</a>, <a href="https://profiles.wordpress.org/dsmart">Derek Smart</a>, <a href="https://profiles.wordpress.org/designsimply">designsimply</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/dipeshkakadiya">dipesh.kakadiya</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/doublesharp">doublesharp</a>, <a href="https://profiles.wordpress.org/dzerycz">DzeryCZ</a>, <a href="https://profiles.wordpress.org/kucrut">Dzikri Aziz</a>, <a href="https://profiles.wordpress.org/emazovetskiy">e.mazovetskiy</a>, <a href="https://profiles.wordpress.org/oso96_2000">Eduardo Reveles</a>, <a href="https://profiles.wordpress.org/cais">Edward Caissie</a>, <a href="https://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="https://profiles.wordpress.org/iseulde">Ella Iseulde Van Dorpe</a>, <a href="https://profiles.wordpress.org/elliottcarlson">elliottcarlson</a>, <a href="https://profiles.wordpress.org/enej">enej</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="https://profiles.wordpress.org/ebinnion">Eric Binnion</a>, <a href="https://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="https://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="https://profiles.wordpress.org/fab1en">Fabien Quatravaux</a>, <a href="https://profiles.wordpress.org/fhwebcs">fhwebcs</a>, <a href="https://profiles.wordpress.org/floriansimeth">Florian Simeth</a>, <a href="https://profiles.wordpress.org/bueltge">Frank Bueltge</a>, <a href="https://profiles.wordpress.org/frankpw">Frank P. Walentynowicz</a>, <a href="https://profiles.wordpress.org/f-j-kaiser">Franz Josef Kaiser</a>, <a href="https://profiles.wordpress.org/gabrielperezs">gabrielperezs</a>, <a href="https://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/geertdd">Geert De Deckere</a>, <a href="https://profiles.wordpress.org/genkisan">genkisan</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="https://profiles.wordpress.org/webord">Gustavo Bordoni</a>, <a href="https://profiles.wordpress.org/hakre">hakre</a>, <a href="https://profiles.wordpress.org/harishchaudhari">Harish Chaudhari</a>, <a href="https://profiles.wordpress.org/hauvong">hauvong</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="https://profiles.wordpress.org/herbmillerjr">herbmillerjr</a>, <a href="https://profiles.wordpress.org/hew">Hew</a>, <a href="https://profiles.wordpress.org/hnle">Hinaloe</a>, <a href="https://profiles.wordpress.org/horike">horike</a>, <a href="https://profiles.wordpress.org/hlashbrooke">Hugh Lashbrooke</a>, <a href="https://profiles.wordpress.org/hugobaeta">Hugo Baeta</a>, <a href="https://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="https://profiles.wordpress.org/ianmjones">ianmjones</a>, <a href="https://profiles.wordpress.org/idealien">idealien</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="https://profiles.wordpress.org/jamescollins">James Collins</a>, <a href="https://profiles.wordpress.org/janhenckens">janhenckens</a>, <a href="https://profiles.wordpress.org/jfarthing84">Jeff Farthing</a>, <a href="https://profiles.wordpress.org/cheffheid">Jeffrey de Wit</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jipmoors">jipmoors</a>, <a href="https://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joemcgill">Joe McGill</a>, <a href="https://profiles.wordpress.org/yo-l1982">Joel Bernerman</a>, <a href="https://profiles.wordpress.org/joen">Joen Asmussen</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johneckman">John Eckman</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/jlevandowski">John Levandowski</a>, <a href="https://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="https://profiles.wordpress.org/joostdekeijzer">joost de keijzer</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/jcastaneda">Jose Castaneda</a>, <a href="https://profiles.wordpress.org/joshlevinson">Josh Levinson</a>, <a href="https://profiles.wordpress.org/jphase">jphase</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="https://profiles.wordpress.org/jtsternberg">Justin Sternberg</a>, <a href="https://profiles.wordpress.org/justincwatt">Justin Watt</a>, <a href="https://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="https://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kevdotbadger">Kevin Ruscoe</a>, <a href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="https://profiles.wordpress.org/ixkaito">Kite</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/mindrun">Leonard</a>, <a href="https://profiles.wordpress.org/leopeo">Leonardo Giacone</a>, <a href="https://profiles.wordpress.org/lgladdy">Liam Gladdy</a>, <a href="https://profiles.wordpress.org/maimairel">maimairel</a>, <a href="https://profiles.wordpress.org/mako09">Mako</a>, <a href="https://profiles.wordpress.org/funkatronic">Manny Fleurmond</a>, <a href="https://profiles.wordpress.org/marcelomazza">marcelomazza</a>, <a href="https://profiles.wordpress.org/marcochiesi">Marco Chiesi</a>, <a href="https://profiles.wordpress.org/mkaz">Marcus Kazmierczak</a>, <a href="https://profiles.wordpress.org/tyxla">Marin Atanasov</a>, <a href="https://profiles.wordpress.org/nofearinc">Mario Peshev</a>, <a href="https://profiles.wordpress.org/clorith">Marius (Clorith)</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/senff">Mark Senff</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/mgibbs189">Matt Gibbs</a>, <a href="https://profiles.wordpress.org/sivel">Matt Martz</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="https://profiles.wordpress.org/mzak">Matt Zak</a>, <a href="https://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="https://profiles.wordpress.org/mattheweppelsheimer">Matthew Eppelsheimer</a>, <a href="https://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="https://profiles.wordpress.org/mehulkaklotar">mehulkaklotar</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/meloniq">meloniq</a>, <a href="https://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="https://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="https://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="https://profiles.wordpress.org/michalzuber">michalzuber</a>, <a href="https://profiles.wordpress.org/mdgl">Mike Glendinning</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/thaicloud">Mike Jordan</a>, <a href="https://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="https://profiles.wordpress.org/mikengarrett">MikeNGarrett</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="https://profiles.wordpress.org/mmn-o">mmn-o</a>, <a href="https://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="https://profiles.wordpress.org/momdad">MomDad</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/morpheu5">Morpheu5</a>, <a href="https://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="https://profiles.wordpress.org/nathan_dawson">nathan_dawson</a>, <a href="https://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nicnicnicdevos">nicnicnicdevos</a>, <a href="https://profiles.wordpress.org/nikv">Nikhil Vimal</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/ninnypants">ninnypants</a>, <a href="https://profiles.wordpress.org/nitkr">nitkr</a>, <a href="https://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="https://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="https://profiles.wordpress.org/pareshradadiya-1">Paresh Radadiya</a>, <a href="https://profiles.wordpress.org/pathawks">Pat Hawks</a>, <a href="https://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="https://profiles.wordpress.org/paulschreiber">Paul Schreiber</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/sirbrillig">Payton Swick</a>, <a href="https://profiles.wordpress.org/petemall">Pete Mall</a>, <a href="https://profiles.wordpress.org/gungeekatx">Pete Nelson</a>, <a href="https://profiles.wordpress.org/peterwilsoncc">Peter Wilson</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/podpirate">podpirate</a>, <a href="https://profiles.wordpress.org/postpostmodern">postpostmodern</a>, <a href="https://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="https://profiles.wordpress.org/prasoon2211">prasoon2211</a>, <a href="https://profiles.wordpress.org/cyman">Primoz Cigler</a>, <a href="https://profiles.wordpress.org/r-a-y">r-a-y</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/rahulbhangale">rahulbhangale</a>, <a href="https://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="https://profiles.wordpress.org/lamosty">Rastislav Lamos</a>, <a href="https://profiles.wordpress.org/ravindra-pal-singh">Ravindra Pal Singh</a>, <a href="https://profiles.wordpress.org/rianrietveld">Rian Rietveld</a>, <a href="https://profiles.wordpress.org/ritteshpatel">Ritesh Patel</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="https://profiles.wordpress.org/magicroundabout">Ross Wintle</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmarks">Ryan Marks</a>, <a href="https://profiles.wordpress.org/welcher">Ryan Welcher</a>, <a href="https://profiles.wordpress.org/sagarjadhav">Sagar Jadhav</a>, <a href="https://profiles.wordpress.org/solarissmoke">Samir Shah</a>, <a href="https://profiles.wordpress.org/samo9789">samo9789</a>, <a href="https://profiles.wordpress.org/samuelsidler">Samuel Sidler</a>, <a href="https://profiles.wordpress.org/sgrant">Scott Grant</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/scottgonzalez">scott.gonzalez</a>, <a href="https://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/sergejmueller">Sergej Muller</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/sevenspark">sevenspark</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="https://profiles.wordpress.org/sippis">sippis</a>, <a href="https://profiles.wordpress.org/slobodanmanic">Slobodan Manic</a>, <a href="https://profiles.wordpress.org/stephdau">Stephane Daury</a>, <a href="https://profiles.wordpress.org/sillybean">Stephanie Leary</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stevegrunwell">Steve Grunwell</a>, <a href="https://profiles.wordpress.org/stevehickeydesign">stevehickeydesign</a>, <a href="https://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="https://profiles.wordpress.org/taka2">taka2</a>, <a href="https://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="https://profiles.wordpress.org/hissy">Takuro Hishikawa</a>, <a href="https://profiles.wordpress.org/themiked">theMikeD</a>, <a href="https://profiles.wordpress.org/thomaswm">thomaswm</a>, <a href="https://profiles.wordpress.org/ipm-frommen">Thorsten Frommen</a>, <a href="https://profiles.wordpress.org/tillkruess">Till</a>, <a href="https://profiles.wordpress.org/timothyblynjacobs">Timothy Jacobs</a>, <a href="https://profiles.wordpress.org/tiqbiz">tiqbiz</a>, <a href="https://profiles.wordpress.org/tmatsuur">tmatsuur</a>, <a href="https://profiles.wordpress.org/tmeister">tmeister</a>, <a href="https://profiles.wordpress.org/tschutter">Tobias Schutter</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tomdxw">tomdxw</a>, <a href="https://profiles.wordpress.org/travisnorthcutt">Travis Northcutt</a>, <a href="https://profiles.wordpress.org/trishasalas">trishasalas</a>, <a href="https://profiles.wordpress.org/tywayne">Ty Carlson</a>, <a href="https://profiles.wordpress.org/uamv">UaMV</a>, <a href="https://profiles.wordpress.org/desaiuditd">Udit Desai</a>, <a href="https://profiles.wordpress.org/sorich87">Ulrich Sossou</a>, <a href="https://profiles.wordpress.org/veritaserum">Veritaserum</a>, <a href="https://profiles.wordpress.org/voldemortensen">voldemortensen</a>, <a href="https://profiles.wordpress.org/volodymyrc">VolodymyrC</a>, <a href="https://profiles.wordpress.org/vortfu">vortfu</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/earnjam">William Earnhardt</a>, <a href="https://profiles.wordpress.org/willstedt">willstedt</a>, and <a href="https://profiles.wordpress.org/wordpressorru">WordPressor</a>.
<p style="margin-top: 22px">Special thanks go to <a href="http://siobhanmckeown.com/">Siobhan McKeown</a> for producing the release video and <a href="http://camikaos.com/">Cami Kaos</a> for the voice-over.</p>
<p>Finally, thanks to all of the contributors who provided subtitles for the release video, which at last count had been translated into 30 languages!</p>
<p><a href="https://profiles.wordpress.org/adrianpop">Adrian Pop</a>, <a href="https://profiles.wordpress.org/deconf">Alin Marcu</a>, <a href="https://profiles.wordpress.org/bagerathan">Bagerathan Sivarajah</a>, <a href="https://profiles.wordpress.org/besnik">Besnik</a>, <a href="https://profiles.wordpress.org/bjornjohansen">Bjørn Johansen</a>, Chantal Coolsma, <a href="https://profiles.wordpress.org/cubells">cubells</a>, Daisuke Takahashi, <a href="https://profiles.wordpress.org/dianakc">Diana K. Cury</a>, <a href="https://profiles.wordpress.org/djzone">DjZoNe</a>, <a href="https://profiles.wordpress.org/dyrer">dyrer</a>, <a href="https://profiles.wordpress.org/semblance">Elzette Roelofse</a>, <a href="https://profiles.wordpress.org/wordpress-tr">Emre Erkan</a>, <a href="https://profiles.wordpress.org/fxbenard">fxbenard</a>, <a href="https://profiles.wordpress.org/tacoverdo">TacoVerdo</a>, <a href="https://profiles.wordpress.org/gabriel-reguly">Gabriel Reguly</a>, <a href="https://profiles.wordpress.org/miss_jwo">Jenny Wong</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/hgmb">Håvard Grimelid</a>, <a href="https://profiles.wordpress.org/intoxstudio">Joachim Jensen</a>, <a href="https://profiles.wordpress.org/jimmyxu">Jimmy Xu</a>, <a href="https://profiles.wordpress.org/nukaga">Junko Nukaga</a>, <a href="https://profiles.wordpress.org/pokeraitis">Justina</a>, <a href="https://profiles.wordpress.org/kenan3008/">Kenan Dervisevic</a>, <a href="https://profiles.wordpress.org/kosvrouvas">Kostas Vrouvas</a>, <a href="https://profiles.wordpress.org/eclare">Krzysztof Trynkiewicz</a>, <a href="https://profiles.wordpress.org/goblindegook">Luís Rodrigues</a>, <a href="https://profiles.wordpress.org/luisrull">Luis Rull</a>, <a href="https://profiles.wordpress.org/culturemark">Mark Thomas Gazel </a>, <a href="https://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="https://profiles.wordpress.org/matthee">matthee</a>, <a href="https://profiles.wordpress.org/damst">Mattias Tengblad</a>, Matúš Záhradník, Mayuko Moriyama, <a href="https://profiles.wordpress.org/michalvittek">Michal Vittek</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="https://profiles.wordpress.org/mrshemek">MrShemek</a>, <a href="https://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/peterhoob">Peter Holme Obrestad</a>, <a href="https://profiles.wordpress.org/petya">Petya Raykovska</a>, Przemysław Mirota, <a href="https://profiles.wordpress.org/qraczek">qraczek</a>, <a href="https://profiles.wordpress.org/bi0xid">Rafa Poveda</a>, <a href="https://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="https://profiles.wordpress.org/rasheed">Rasheed Bydousi</a>, <a href="https://profiles.wordpress.org/gwgan">Rhoslyn Prys</a>, <a href="https://profiles.wordpress.org/robee">Robert Axelsen</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/siobhyb">Siobhan Bamber</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/tohave">ک To Have داشتن</a>, <a href="https://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="https://profiles.wordpress.org/egalego">Victor J. Quesada</a>, <a href="https://profiles.wordpress.org/wolly">Wolly</a>, <a href="https://profiles.wordpress.org/xavivars">Xavi Ivars</a>, <a href="https://profiles.wordpress.org/xibe">Xavier Borderie</a></p>
<p>If you want to follow along or help out, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.3!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:47:"https://wordpress.org/news/2015/04/powell/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 4.1.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2015/04/wordpress-4-1-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2015/04/wordpress-4-1-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Apr 2015 13:44:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3628";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:383:"WordPress 4.1.2 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.1.1 and earlier are affected by a critical cross-site scripting vulnerability, which could enable anonymous users to compromise a site. This was reported by Cedric Van Bockhaven and fixed by [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Gary Pendergast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3913:"<p>WordPress 4.1.2 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>WordPress versions 4.1.1 and earlier are affected by a critical cross-site scripting vulnerability, which could enable anonymous users to compromise a site. This was reported by <a href="https://cedricvb.be">Cedric Van Bockhaven</a> and fixed by <a href="http://pento.net/">Gary Pendergast</a>, <a href="http://blogwaffe.com/">Mike Adams</a>, and <a href="http://nacin.com/">Andrew Nacin</a> of the WordPress security team.</p>
<p>We also fixed three other security issues:</p>
<ul>
<li>In WordPress 4.1 and higher, files with invalid or unsafe names could be uploaded. Discovered by <a href="http://HSASec.de">Michael Kapfer and Sebastian Kraemer of HSASec</a>.</li>
<li>In WordPress 3.9 and higher, a very limited cross-site scripting vulnerability could be used as part of a social engineering attack. Discovered by <a href="http://zoczus.blogspot.com/">Jakub Zoczek</a>.</li>
<li>Some plugins were vulnerable to an SQL injection vulnerability. Discovered by Ben Bidner of the WordPress security team.</li>
</ul>
<p>We also made four hardening changes, discovered by <a href="http://codesymphony.co/">J.D. Grimes</a>, Divyesh Prajapati, <a href="http://www.allancollins.net/">Allan Collins</a>, <a href="https://sucuri.net/">Marc-Alexandre Montpas</a> and <a href="https://profiles.wordpress.org/jblz">Jeff Bowen</a>.</p>
<p>We appreciated the <a href="https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/">responsible disclosure</a> of these issues directly to our security team. For more information, see the <a href="https://codex.wordpress.org/Version_4.1.2">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/4.1?rev=32234&amp;stop_rev=32144">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 4.1.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221; Sites that support automatic background updates are already beginning to update to WordPress 4.1.2.</p>
<p>Thanks to everyone who contributed to 4.1.2: <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/vortfu">Ben Bidner</a>, <a href="https://profiles.wordpress.org/boonbgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/DrewAPicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, and <a href="https://profiles.wordpress.org/mdawaffe">Mike Adams</a>.</p>
<p>A number of plugins also released security fixes yesterday. Keep everything updated to stay secure. If you’re a plugin author, please read <a href="https://make.wordpress.org/plugins/2015/04/20/fixing-add_query_arg-and-remove_query_arg-usage/">this post</a> to confirm that your plugin is not affected by the same issue. Thank you to all of the plugin authors who worked closely with our security team to ensure a coordinated response.</p>
<p><em>Already testing WordPress 4.2? The third release candidate is now available (<a href="https://wordpress.org/wordpress-4.2-RC3.zip">zip</a>) and it contains these fixes. For more on 4.2, see <a href="https://wordpress.org/news/2015/04/wordpress-4-2-release-candidate/">the RC 1 announcement post</a>.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/04/wordpress-4-1-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:32:"https://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Mon, 27 Jul 2015 20:03:19 GMT";s:12:"content-type";s:34:"application/rss+xml; charset=UTF-8";s:10:"connection";s:5:"close";s:25:"strict-transport-security";s:11:"max-age=360";s:10:"x-pingback";s:37:"https://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 23 Jul 2015 19:30:36 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wpLi_options` VALUES (295, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1438070600', 'no') ; 
INSERT INTO `wpLi_options` VALUES (296, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1438027400', 'no') ; 
INSERT INTO `wpLi_options` VALUES (297, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', '1438070603', 'no') ; 
INSERT INTO `wpLi_options` VALUES (298, '_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: MPAA Smoking Gun";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45270";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2015/07/mpaa-smoking-gun/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:319:"<p>Sometimes truth is worse than what you would imagine: <a href="https://www.techdirt.com/articles/20150724/15501631756/smoking-gun-mpaa-emails-reveal-plan-to-run-anti-google-smear-campaign-via-today-show-wsj.shtml">Smoking Gun: MPAA Emails Reveal Plan To Run Anti-Google Smear Campaign Via Today Show And WSJ</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 27 Jul 2015 15:34:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:119:"WPTavern: Plugin Developers Demand a Better Security Release Process After WordPress 4.2.3 Breaks Thousands of Websites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47146";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:129:"http://wptavern.com/plugin-developers-demand-a-better-security-release-process-after-wordpress-4-2-3-breaks-thousands-of-websites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6880:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/security.jpg"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/security.jpg?resize=1024%2C487" alt="photo credit: Ravages - cc" class="size-full wp-image-27206" /></a>photo credit: <a href="https://www.flickr.com/photos/ravages/6731739485/">Ravages</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p><a href="http://wptavern.com/wordpress-4-2-3-is-a-critical-security-release-fixes-an-xss-vulnerability" target="_blank"> WordPress 4.2.3</a>, a critical security release, was automatically pushed out to users yesterday to fix an XSS vulnerability. Shortly afterwards, the <a href="https://wordpress.org/search/4.2.3?forums=1" target="_blank">WordPress.org support forums</a> were flooded with reports of websites broken by the update.</p>
<p>Roughly eight hours later Robert Chapin (@<a href="https://profiles.wordpress.org/miqrogroove/" target="_blank">miqrogroove</a>) published a post to the Make.WordPress.org/Core blog, detailing <a href="https://make.wordpress.org/core/2015/07/23/changes-to-the-shortcode-api/" target="_blank">changes to the Shortcode API</a> that were included in the release. According to Chapin, these changes were necessary as part of the security fix:</p>
<blockquote><p>Due to the nature of the fix – as is often the case with security fixes – we were unable to alert plugin authors ahead of time, however we did make efforts to scan the plugin directory for plugins that may have been affected.</p>
<p>With this change, every effort has been made to preserve all of the core features of the Shortcode API. That said, there are some new limitations that affect some rare uses of shortcodes.</p></blockquote>
<p>The security team had no reasonable way of accounting for every single edge case, but the negative impact of these changes were far more wide-reaching than they had anticipated. This particular use case likely wasn&#8217;t covered in their testing. Unfortunately, plugin developers found out about the breaking changes only after the security release had already left a slew of broken websites in its wake.</p>
<p>&#8220;I fully understand this is an issue, but isn’t this a weird way of updating &#8211; almost all our clients are calling / e-mailing us at the moment as their sites seem to be broken,&#8221; one developer <a href="https://make.wordpress.org/core/2015/07/23/changes-to-the-shortcode-api/#comment-26449" target="_blank">commented</a> on the Shortcode API post. &#8220;Normally it would be better to announce such huge impact changes to the plugin and theme developers. This means I need to fully reschedule my agenda, which already is full during holiday season.&#8221;</p></blockquote>
<p>Comments on the WordPress.org post are full of developers scrambling to find a way to fix client websites. Many were disappointed that the total secrecy of the security team, which is necessary in situations like this, was not immediately followed up with a public post on the important changes to the Shortcode API. Meanwhile, the email inboxes of agencies and plugin developers are filling up with urgent messages from outraged clients.</p>
<p>Developers want better communication from the those who are managing security releases. <a href="https://twitter.com/helzer" target="_blank">Amir Helzer</a>, author of <a href="https://wordpress.org/plugins/types/" target="_blank">Types</a> and <a href="http://wp-types.com/home/views-create-elegant-displays-for-your-content/" target="_blank">Views</a>, two plugins majorly affected by the release, <a href="https://make.wordpress.org/core/2015/07/23/changes-to-the-shortcode-api/#comment-26447" target="_blank">sums up the thoughts of many other commenters</a> on the Make/WordPress.org/Core post:</p>
<blockquote><p>We are updating the Views plugin today, so that we resolve all shortcodes before passing to WordPress to process content.</p>
<p>This is a straightforward change, which takes us one day to complete.</p>
<p>Would have been great to receive a heads-up about an upcoming change in WordPress, so we could do this change on time.</p>
<p>We received a huge amount of support requests due to this, but this isn’t the issue. We can deal with a wave a support issues. This time it wasn’t “our fault”, but sometimes it is.</p>
<p>What worries us, as mentioned above, is seeing our clients (folks who build WordPress sites for a living), losing their faith in the system. They feel like the system sees them as little ants and not as humans. People don’t like seeing their problems being dismissed.</p>
<p>Many of them run hundreds of sites. They cannot afford to stop everything and fix content on so many sites. Especially not if they are currently away for their family vacation.</p>
<p>What others have asked here, and I would like to ask, too, is to setup a mechanism that allows WordPress core developers to privately communicate such upcoming issues with plugins developers.</p>
<p>We are your partners.</p>
<p>Without WordPress (secure, stable and reliable), we would not exist.</p>
<p>Without great themes and plugins, WordPress would not power 24% of the Web.</p>
<p>WordPress core members already volunteer a lot of their time. I’m not asking for anyone to volunteer more time. Need help? Ask us. There is a huge community of developers who rely on WordPress. We would be happy to get involved and set up whatever is needed.</p></blockquote>
<p>User confidence in WordPress&#8217; automatic background updates took a dent with the 4.2.3 release. Waking up to broken websites causes users to second guess automatic updates after being assured that maintenance and security releases would not include breaking changes.</p>
<p>When users get burned by automatic updates, in the end it doesn&#8217;t matter which party is at fault &#8211; whether it&#8217;s the core team or a theme or plugin. They simply expect updates to work and not break anything. Even in instances where a poorly coded extension may be at fault, the average user has no way of determining whether or not their active plugins follow WordPress best practices.</p>
<p>The aftermath of the most recent security release is one reason why many developers and users are still wary of automatic updates. Amir Helzer represents many other plugin developers who are eager to find better ways to work together with the core team to provide a better update experience for users. This is especially important for releases like this one where the Shortcode API changes directly affected users&#8217; content. Hezler&#8217;s comment reaffirms the fact that development agencies, plugin developers, and core developers are all partners on the same team. It&#8217;s time to find better ways of working together to provide the best update experience possible for WordPress users.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 25 Jul 2015 02:46:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: FooPlugin’s Digital License Key Management Plugin is Now Open Source for Developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47117";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"http://wptavern.com/fooplugins-digital-license-key-management-plugin-is-now-open-source-for-developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5296:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/open-source.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/open-source.jpg?resize=1024%2C514" alt="photo credit: 16th st - (license)" class="size-full wp-image-45884" /></a>photo credit: <a href="http://www.flickr.com/photos/79777096@N00/6866996865">16th st</a> &#8211; <a href="https://creativecommons.org/licenses/by-nd/2.0/">(license)</a>
<p>Three years ago, <a href="http://fooplugins.com/" target="_blank">FooPlugins</a> built <a href="https://bitbucket.org/fooplugins/foolicensing" target="_blank">FooLicensing</a>, a digital license key management tool that enabled them to manage customers of their <a href="https://easydigitaldownloads.com/" target="_blank">EDD</a>-powered commercial plugins store. Although EDD already offered a license creation and management extension, FooPlugins required more features than it had at that time and opted to build their own.</p>
<p>As of today, FooLicensing is now open source and free for anyone to use, along with the associated EDD connector plugin.</p>
<p>&#8220;We love the community and wanted to give back,&#8221; FooPlugins co-founder Adam Warner said.</p>
<p>&#8220;We know FooLicensing could be so much more but we just don&#8217;t have the time to dedicate to it alone. We are a small team and because of that we find ourselves with dozens of projects that could be so much more if only we had more time and people.&#8221;</p>
<p>Open sourcing a project can change its trajectory if there&#8217;s enough interest and developers willing to contribute to improve it. Warner isn&#8217;t counting on that, however, and simply hopes other developers will find it useful.</p>
<p>&#8220;It&#8217;s a bit of a leap of faith, but if it helps someone else get involved to help create an even more robust system, then great,&#8221; he said. &#8220;Bonus if it helps someone build additional extensions to help others.&#8221;</p>
<p>FooLicensing&#8217;s main features include:</p>
<ul>
<li>View and manage the validated domains for your EDD license level</li>
<li>One click EDD license upgrade/add to cart</li>
<li>One click EDD license renewal (with associated discount) /add to cart</li>
</ul>
<p>A logged-in user who has entered a license key will see all the relevant account information detailing status, activations, expirations, etc.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/foolicensing-user-admin.png"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/foolicensing-user-admin.png?resize=580%2C332" alt="foolicensing-user-admin" class="aligncenter size-full wp-image-47135" /></a></p>
<p>Administrators who are using the plugin together with its <a href="https://bitbucket.org/fooplugins/edd-foolicensing" target="_blank">EDD Connector</a> will see a menu with various license creation and management tools.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/foolicensing-admin-view.png"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/foolicensing-admin-view.png?resize=160%2C264" alt="foolicensing-admin-view" class="aligncenter size-full wp-image-47137" /></a></p>
<p>The <a href="https://bitbucket.org/fooplugins/edd-foolicensing" target="_blank">EDD Connector</a>, also now open source, enables the following:</p>
<ul>
<li>Add new licenses to attach to an EDD product</li>
<li>A searchable list of all license keys that have been created and assigned, complete with attached domains</li>
<li>A list of licenses that have been renewed</li>
<li>Testing for license validation and update checks in the API Sandbox</li>
<li>A management area for various messages (domain attach, detach) and for license renewal discount amount and emails</li>
</ul>
<h3>Foo Licensing is Extensible for Other Platforms</h3>
<p>FooLicensing was built from the beginning to be extensible for use with other platforms beyond EDD. The team at FooPlugins had plans to expand their library of connectors but didn&#8217;t have the time to execute them.</p>
<p>&#8220;Our goal for FooLicensing was to build additional integrations for other eCommerce plugins and digital sales platforms but it quickly took a back seat as our <a href="https://fooplugins.com/plugins/foobox/" target="_blank">FooBox</a> and other plugins like <a href="https://fooplugins.com/plugins/foogallery/" target="_blank">FooGallery</a> gained popularity,&#8221; Warner said.</p>
<p>&#8220;Documentation is non-existent at this point, but we welcome you to step through the code and consider getting involved with the core plugin or with extensions for other eCommerce platforms.&#8221;</p>
<p>Warner said the team is considering a full-fledged site dedicated to FooLicensing if enough developers become interested and would consider the possibility of a marketplace to host any extension built. FooPlugins does not currently have plans to create additional extensions in house.</p>
<p>&#8220;We&#8217;ll see what the future holds, but for now we need to move forward with some other things rather than holding this tight to our chests,&#8221; Warner said. &#8220;Open sourcing the plugins just fits in with what we believe is the right thing to do to make the web (and the WP community) a better place.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Jul 2015 20:17:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Post Status: Thesis, Automattic, and WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://poststatus.com/?p=13692";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://poststatus.com/thesis-automattic-and-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:70425:"<p>Chris Pearson and Matt Mullenweg have hardly communicated with one another in the last five years, but they are ideological enemies. They are both wealthy individuals (though of different magnitudes) thanks to their online endeavors, with very strong personalities and unshakable beliefs on business and software. This is a story of their dispute, their idealism, and the implications it will have on the WordPress project.</p>
<p><a href="http://ma.tt/">Matt Mullenweg</a> co-founded WordPress, founded <a href="https://automattic.com">Automattic</a>, and is one of the most successful entrepreneurs of his generation. He runs a billion dollar &#8220;unicorn&#8221; startup centered on a culture of embracing open source technology and has achieved incredible success embracing principles counterintuitive to either Silicon Valley or big corporate culture. He&#8217;s paving a new path for how to create a valuable software company while religiously defending and promoting open source software.</p>
<p><a href="http://www.pearsonified.com/">Chris Pearson</a> founded <a href="http://diythemes.com/">DIYthemes</a> and helped pioneer the early WordPress commercial theme industry. He has run his business successfully for over seven years, despite unique hurdles that result from a very public dispute with Mullenweg in 2010. He vehemently defends his work as his own non-derivative achievement and rejects the religiosity and cult mentality that he believes exists in the WordPress ecosystem. He views WordPress as a huge chunk of the web, available to be monetized &#8212; which he has done so to the tune of millions of dollars &#8212; but he does not believe he must adopt Matt Mullenweg&#8217;s principles in order to meet customer demand, run his own business, and protect his own inventions.</p>
<p>By all normal definitions, Mullenweg and Pearson have done incredibly well for themselves. However, from a pure size perspective and principles aside, Mullenweg is the big nation army and Pearson is the small revolutionary militia. Mullenweg views Pearson as a threat to everything he stands for and has worked to accomplish, and Pearson views Mullenweg as an overbearing figure with no true authority over his decisions.</p>
<p>Mullenweg has the motivation, resources, and ability to squash Pearson &#8212; and indeed most thought he&#8217;d done so already. While he has far fewer resources, Pearson has some tools available to protect his business or to potentially even disrupt the entire WordPress ecosystem as we know it today.</p>
<p>During their first conflict in 2010, and in the resurgent one going on now, Mullenweg and Pearson have both at times made mistakes, acted childishly, or been in the wrong. Both also have merit in various aspects of their positions. Neither conflict, so publicly debated, reflects well on the WordPress ecosystem as a whole &#8212; even though I believe it is right that each conflict is best observed under a public eye, as the results can affect so many other businesses and potentially even WordPress itself.</p>
<p>With this post, I aim to outline the entire conflict; to describe the implications past, present and future; to highlight non-WordPress comparisons for precedent and potential implications; and to share my own thoughts on who is in the right and who is in the wrong, as viewed for the good of the global WordPress community.</p>
<h2>A history of conflict</h2>
<p>The commercial theme movement started in 2007 and took off in 2008. Thesis was one of the pioneers of commercial WordPress themes. The theme industry was young and evolving rapidly, and many sellers hardly considered or understood licensing issues at all.</p>
<p>Many of the sources for this period are from Siobhan McKeown&#8217;s excellent account in the book, <a href="https://github.com/WordPress/book"><em>Milestones: The Story of WordPress</em></a> (which I&#8217;ll refer to as <em>Milestones</em>).</p>
<h3>Themes as derivative works of WordPress</h3>
<p>WordPress is licensed by the GNU General Public License (GPL), version 2 or later. The GPL ensures certain freedoms that protect both WordPress and those that utilize it. The &#8220;four freedoms&#8221; that are the heart of the GPL are as follows:</p>
<blockquote>
<ul>
<li>The freedom to run the program as you wish, for any purpose (freedom 0).</li>
<li>The freedom to study how the program works, and change it so it does your computing as you wish (freedom 1). Access to the source code is a precondition for this.</li>
<li>The freedom to redistribute copies so you can help your neighbor (freedom 2).</li>
<li>The freedom to distribute copies of your modified versions to others (freedom 3). By doing this you can give the whole community a chance to benefit from your changes. Access to the source code is a precondition for this.</li>
</ul>
</blockquote>
<p>As WordPress co-founder Mike Little phrased it in the Post Status Slack, &#8220;The GPL is meant to be restrictive for developers and permissive for users.&#8221; The <a href="https://gnu.org/philosophy/philosophy.html">GNU philosophy page</a> and subsequent articles are a good resource for understanding the nature of the license.</p>
<p>The GPL is a <a href="https://en.wikipedia.org/wiki/Copyleft">Copyleft</a> license, which creates the &#8220;stipulation that the same rights be preserved in derivative works down the line.&#8221; In an immature theme market, licensing was given relatively little notice, and many theme authors provided their themes with no license or proprietary licenses.</p>
<p>Matt Mullenweg, to many, would be considered <a href="https://en.wikipedia.org/wiki/Benevolent_dictator_for_life">BDFL</a>, or Benevolent Dictator for Life, of WordPress. It&#8217;s a common term for folks that lead open source projects and have final say on project decisions. In his role as WordPress BDFL, he now has a reputation &#8212; at least within certain circles of folks that pay close attention &#8212; for making large, impactful decisions with little description of why he has done so.</p>
<p>In late 2008, more than 200 free WordPress themes were removed from the WordPress.org theme repository. While many of the themes were removed due to spammy links, some were pulled due to GPL violations within the themes or within the theme upsells that were linked from the theme listings.</p>
<p>The move, which was made without announcement, shocked many theme providers that felt they were unfairly included in the group of removed themes. The situation created a spark and initiated a serious debate about theme licensing.</p>
<p>Authors were concerned that GPL licensed themes would mean that their themes would be bought and freely distributed, removing their ability to make money from their works. A few, such as Brian Gardner with his Revolution theme, <a href="http://www.blogherald.com/2008/10/01/brian-gardners-revolution-theme-goes-open-source/">changed their licensing</a> as a result of conversations with Mullenweg and Toni Schneider, Automattic&#8217;s CEO at the time. In Brian&#8217;s case, he made his theme free and offered paid support services.</p>
<p>Eventually though, most authors &#8220;selling&#8221; themes started actually selling support, access to download, and updates for their themes. This model was both GPL compatible, as well as workable for authors to get paid.</p>
<p>In mid-2009, Matt Mullenweg also posted <a href="https://wordpress.org/news/2009/07/themes-are-gpl-too/">on the official</a> WordPress blog that he was introducing a new <a href="https://wordpress.org/themes/commercial/">commercial theme listing page</a> on WordPress.org, and he shared an opinion he requested from the Software Freedom Law Center (SFLC), where they determined that the two themes packaged with WordPress were derivative works.</p>
<p>The SFLC opinion did leave room for a &#8220;split license&#8221; where the WordPress and PHP code must inherit the GPL, and the CSS, Javascript, and images could be under a proprietary license:</p>
<blockquote><p>In conclusion, the WordPress themes supplied contain elements that are derivative of WordPress’s copyrighted code. These themes, being collections of distinct works (images, CSS files, PHP files), need not be GPL-licensed as a whole. Rather, the PHP files are subject to the requirements of the GPL while the images and CSS are not. Third-party developers of such themes may apply restrictive copyrights to these elements if they wish.</p>
<p>Finally, we note that it might be possible to design a valid WordPress theme that avoids the factors that subject it to WordPress’s copyright, but such a theme would have to forgo almost all the WordPress functionality that makes the software useful.</p></blockquote>
<p>&#8220;Split license&#8221; is the colloquial term the community has assigned to this statement, but in fact the actual splitting of which parts are GPL and which parts are not matters, so it may not do the reality of the situation justice. Perhaps it should be termed &#8220;PHPGPL&#8221; or &#8220;Non-Assets GPL&#8221;.</p>
<p>A number of prominent theme sellers were unhappy with Mullenweg&#8217;s insistence that their themes maintain a 100% GPL license, but they were not willing to shake the boat over it. At this point, themes were becoming big businesses and making new millionaires (or close to it) of some of these shop owners. This settled the issue for nearly all theme sellers, and most moved to either 100% GPL or a PHPGPL license, and the doomsday scenarios never came; the theme industry continues to thrive.</p>
<h3>Thesis holds out</h3>
<p>But not everyone agreed to go either 100% GPL or PHPGPL license. Chris Pearson kept his Thesis theme under a proprietary license.</p>
<p>Thesis was one of the most popular and flexible themes in the world, and Pearson <a href="https://github.com/WordPress/book/blob/925d7dc6293b1662a7e6839a2703e8a858c730ad/Content/Part%205/39-thesis.md">boasted on Andrew Warner&#8217;s Mixergy podcast</a> of revenues of $1.2 million+ over the 12-18 month period prior to the interview. Mullenweg and Pearson criticized one another publicly, and Warner invited them both to Mixergy where they debated the merits of GPL licensing.</p>
<p>By most accounts, Mullenweg had the better argument on the Mixergy episode, and also came off as a calmer and more collected personality &#8212; in contrast to Pearson&#8217;s often heated, and sometimes very strange, statements.</p>
<p>The debate continued between Mullenweg, Pearson, and a variety of WordPress community members and their blogs. Mullenweg was extremely aggressive, to the extent that he <a href="https://twitter.com/photomatt/status/18548422506">offered to buy</a> alternative commercial themes for users of Thesis that agreed to switch. Mullenweg tells me that many took him up on his offer, but it was, &#8220;less than a thousand.&#8221; In my opinion, this was a step too far by Mullenweg, though for him the issue was already personal.</p>
<p>Pearson held his ground over the following days until an admission by one of his own team members of wholesale copying of code in Thesis from WordPress code, which violates the WordPress copyright.</p>
<p>At this point, Pearson finally capitulated and announced that Thesis would be a split license GPL compatible theme, and the debate died down. Pearson put his head down and started working on Thesis 2.</p>
<p>He released Thesis 2 in late 2012, and by this time the debate was cool &#8212; the community had moved on to other drama (yes, even more GPL drama) &#8212; and the release of Thesis 2 was largely ignored outside of DIYthemes&#8217; audience, which was quite large but also largely isolated from the WordPress &#8220;community&#8221; that cares about stuff like licensing.</p>
<p>Therefore, not many people paid attention to the new Thesis or the licensing it contained. Mullenweg, however, was still paying attention.</p>
<h2>The battle over thesis.com</h2>
<p>If you consider the word <em>thesis</em>, what do you think of?</p>
<p>If you are a regular person walking down the street, you probably think of the general concept for stating a theory, or perhaps you think of the long papers that university students write as part of their programs.</p>
<p>If you are in the WordPress world, you may also consider the Thesis WordPress theme by DIYthemes.</p>
<p>Good, single word domain names are hard to come by. Thesis.com, if you visit it now, redirects to the <a href="http://themeshaper.com">ThemeShaper blog</a>. ThemeShaper is owned and operated by Automattic, and frequently posts articles about WordPress themes.</p>
<p>ThemeShaper is not a dedicated commercial property, but it does link to Automattic&#8217;s primary website, and Automattic does make and sell WordPress themes.</p>
<h3>Automattic buys thesis.com</h3>
<p>Automattic hasn&#8217;t always owned <a href="http://thesis.com">thesis.com</a>. Matt Mullenweg met a third party owner of the domain at a conference &#8212; a guy named Larry &#8212; and inquired about the domain by email in January of 2014. Chris Pearson had already attempted to purchase the domain from Larry, and did not agree to pay the $150,000 that Larry requested.</p>
<p><a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php">According to Pearson&#8217;s accounts</a>, he and Larry had a few exchanges that stalled with Pearson unwilling to bid beyond $37,500 for the domain, and Larry sticking to $150,000. With a $100,000 offer on the table from Mullenweg, Larry gave Pearson an opportunity to buy the domain for $115,000, which he didn&#8217;t do &#8212; in part because he thought it too expensive, but also because he suspected Larry didn&#8217;t really have the offer from Mullenweg.</p>
<p>As we now know, Larry did have the offer and Automattic became the owner of the thesis.com domain name.</p>
<p>Pearson didn&#8217;t know that Mullenweg actually bought the domain until November of 2014, when he was notified by a friend that Mullenweg&#8217;s WordCamp San Francisco State of the Word Q&amp;A session included a section where Mullenweg noted that he owned the domain (more on that later).</p>
<h3>Pearson attempts to force domain transfer</h3>
<p>On April 9th, 2015, Pearson and his lawyers filed a UDRP (Uniform Domain-Name Dispute Resolution Policy) complaint, which is a formal method for resolving domain disputes, recognized by ICANN. UDRP isn&#8217;t a formal government court, but serves as arbitration for domains due to the recognition by ICANN.</p>
<p>There are many, many examples of UDRP complaints in regard to trademark infringement. There are a <a href="https://www.icann.org/resources/pages/policy-2012-02-25-en?routing_type=path">number of criteria</a> that come into play that guide the UDRP panel&#8217;s decision making process.</p>
<p>The three basic tenets that must be met are as follows:</p>
<blockquote><p>(i) your domain name is identical or confusingly similar to a trademark or service mark in which the complainant has rights; and</p>
<p>(ii) you have no rights or legitimate interests in respect of the domain name; and</p>
<p>(iii) your domain name has been registered and is being used in bad faith.</p></blockquote>
<p>The panel reviews the initial complaint (in this case, by Pearson) and gives the respondent (Automattic) an opportunity to respond. All correspondence is in writing and not in person. The panel has two weeks after everything has been submitted to reach a decision.</p>
<p>In this case, which <a href="http://www.adrforum.com/domaindecisions/1613723.htm">is available publicly</a>, the panel denied Pearson&#8217;s complaint.</p>
<p>Pearson&#8217;s complaint cited that he fulfilled each of the three criteria:</p>
<ul>
<li>By noting his trademark of the word &#8220;thesis&#8221;.</li>
<li>By noting that Automattic was using the domain with a commercial interest (by redirecting it to ThemeShaper).</li>
<li>By noting the bad faith clause by citing that Automattic, &#8220;purchased the disputed domain name to confuse and redirect customers and potential customers to Respondent’s competing webpage.&#8221;</li>
</ul>
<p>In the response, Automattic did not contest Pearson&#8217;s trademark on the word <em>thesis</em>. However, Automattic also noted that the word is very generic, and also that ThemeShaper was not a commercial part of Automattic, but a &#8220;blogging site.&#8221;</p>
<p>For the bad faith argument, Automattic claimed that the redirect to ThemeShaper furthers their, &#8220;purpose in providing a blogging site,&#8221; and highlights that the intention for the domain is not as a commercial entity or one to be confused with Pearson&#8217;s trademark.</p>
<h3>Automattic wins dispute</h3>
<p>Automattic won the dispute against Pearson. As noted, the panel had two weeks to deliver the decision, and Automattic proposed a settlement with Pearson before the decision was handed down.</p>
<p>Pearson was considering the settlement when the decision came a day before the two week deadline, which is apparently not a common occurrence. Had the decision not come early, Pearson may have saved himself some trouble, especially in regard to eliminating the <a href="http://ttabvue.uspto.gov/ttabvue/v?qs=85115266">trademark cancellation requests</a> by Automattic on <em>thesis</em> and related terms.</p>
<p>In Pearson&#8217;s blog post, <a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php">The Truth about Thesis.com</a>, he notes the general terms of the proposed settlement:</p>
<blockquote><p>Automattic’s attorneys drafted the original settlement, which included the following terms:</p>
<ul>
<li>Automattic would keep thesis.com</li>
<li>Automattic would withdraw the federal trademark cancellation request</li>
<li>I would withdraw the UDRP</li>
<li>Both parties would mutually release one another (agree not to sue over this issue in the future)</li>
</ul>
<p>Nothing in the original settlement addressed the trademark infringement, and since this was the reason I took action in the first place, I added a requirement that Automattic no longer infringe upon my mark (which would mean they stop forwarding the domain).</p>
<p>At this point in the proceedings, I agreed to the settlement.</p></blockquote>
<p>However, since the decision came early, the settlement was never binding. It&#8217;s also worth noting that Mullenweg commented to me that Pearson&#8217;s stated terms are actually not the terms of the settlement:</p>
<blockquote><p>In the settlement Automattic offered Chris we agreed not to infringe his trademarks (which is the law, regardless of what the settlement said). He never asked us to change the redirect of thesis.com in the settlement, and if he asked after, we would have said no. There were no restrictions on thesis.com in the settlement.</p></blockquote>
<p>He also said, &#8220;I wish he had reached out before litigating,&#8221; and noted that it would have &#8220;definitely&#8221; changed the outcome of the entire situation. Whether it truly would have is neither here nor there.</p>
<h3>Possibility for appeal</h3>
<p>The UDRP doesn&#8217;t have an official appeals process. Instead, they are willing to not make the changes that a ruling states, if indeed a domain transfer or other action is ordered, if the affected party files a suit in court within ten days of the ruling.</p>
<p>In this case, Pearson did not file in a court within the given timeline, and since the ruling did not require a change in domain ownership, there is no further recourse with the UDRP. However, there is no time limit if Pearson wishes to file in court &#8212; but that is the only path remaining if he truly wants to go after the domain.</p>
<h3>Legitimacy of the trademark dispute</h3>
<p>Trademark law has a long history. Trademarks follow a categorical system, meaning words and terms must be trademarked within a particular category to be applied to.</p>
<p>Pearson has three trademarks for the Thesis and DIYthemes brands, all under <a href="http://www.oppedahl.com/trademarks/tmclasses.htm">international trademark class</a> 42, for computer, scientific, and legal purposes:</p>
<ul>
<li>THESIS</li>
<li>THESIS THEME</li>
<li>DIYTHEMES</li>
</ul>
<p>The applications were filed in 2010 and registered in 2011. On June 16th, 2015, Automattic filed <a href="http://ttabvue.uspto.gov/ttabvue/v?qs=85115266">cancellation requests</a> for all three trademarks, which were instituted June 25th. Pearson has 40 days from the date the application was instituted (which would be August 4th) to file a response to the cancellation requests. His answers, &#8220;must contain admissions or denials of the allegations in the petition for cancellation, and may include available defenses and counterclaims.&#8221; It is his burden as the defendant to establish his defense, and, &#8220;Failure to file a timely answer may result in entry of default judgment and the cancellation of the registration.&#8221;</p>
<p>Basically, Automattic is holding his feet to the fire to defend the trademarks, which their counsel feels should not apply for two primary reasons, as listed in their <a href="http://ttabvue.uspto.gov/ttabvue/v?pno=92061714&pty=CAN&eno=1">formal filing</a>.</p>
<ul>
<li>The trademarks were registered in Pearson&#8217;s own name, but are used by DIYthemes, and Automattic claims that, &#8220;The Pearson Applications were improperly filed in the name of an individual, who did not have the requisite intent-to-use the marks as of the filing date, and the underlying applications are void ab initio.&#8221; Their claim notes that US Code section <a href="https://www.law.cornell.edu/uscode/text/15/1051">1051(b)</a> offers this justification.</li>
<li>Furthermore, section <a href="https://www.law.cornell.edu/uscode/text/15/1052">1052(e)(1)</a> requires that a trademark not be &#8220;merely descriptive,&#8221; as Automattic claims his trademarks are.</li>
</ul>
<p>If upheld, the trademarks will be deregistered by the US Patent Office, further limiting Pearson&#8217;s options to defend his claims to the thesis.com domain name in a formal court suit.</p>
<p>I don&#8217;t know how good of a case Automattic has, but purely on the surface it looks pretty good. I spent time reviewing the application and the US Code and the arguments appear fairly sound &#8212; especially the argument that Pearson applied for the trademarks as an individual and utilizes them as DIYthemes, despite DIYthemes already having been registered as an LLC.</p>
<h3>Automattic&#8217;s justification for the domain</h3>
<p>During the <a href="https://videopress.com/v/WmCl2kwS">WordCamp San Francisco Q&amp;A</a>, Mullenweg noted the existence of the redirect of the domain name with a sense of pride, and a bit of a side-eyed smirk. In response to a question about relationships with commercial theme sellers and marketplaces, he states:</p>
<blockquote><p>With the premium theme and plugin folks? &#8230; We have had some ups and downs, particularly with marketplaces that didn&#8217;t follow the GPL, for example, or violated WordPress&#8217;s license &#8212; themes that violated WordPress&#8217;s license. Um, you can go to thesis.com to learn more about that. Type it in, seriously.</p></blockquote>
<p>I was at this Q&amp;A in person, and don&#8217;t remember him saying this, as it was so buried in a much larger conversation, and I was simultaneously writing a wrap-up post about the State of the Word. However, once the UDRP ruling surfaced publicly, a number of WordPress community members recalled Matt&#8217;s statement and it brought a new dimension to the ruling and Mullenweg&#8217;s motivation for the domain.</p>
<p>While Automattic bought the domain, Matt Mullenweg was clearly the driving force behind the decision. When <a href="http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks">WP Tavern prompted Automattic</a> for a comment on their motivation for purchasing the domain, they responded with the following:</p>
<blockquote><p>We’re happy the panel ruled in our favor. We think Thesis.com is a cool, generic .com that could be used for a variety of things. Just because you have a small WordPress theme doesn’t mean you have a right to seize generic English word .com domains.</p></blockquote>
<p>We can accept Automattic&#8217;s case that they had a general interest in a generic .com domain, but in reality we know better. Mullenweg was clearly presented with an opportunity by this Larry character that checked all of the right boxes for him.</p>
<p>He could get a domain he obviously knew Pearson would want, and deny him.</p>
<p>It has a side benefit that it <em>is</em> a high quality generic domain that will likely maintain or increase its value. And he probably thought it was funny.</p>
<p>I doubt Mullenweg even knew what kind of trademarks Pearson held, but despite Pearson holding the trademarks, it seems Automattic&#8217;s attorneys now have the upper hand, and it is highly unlikely Pearson will ever own the domain now.</p>
<p>Mullenweg <a href="http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks#comment-70849">commented</a> on his refusal to give up the domain to Pearson on WP Tavern:</p>
<blockquote><p>I’m not going to give a domain worth several hundred thousand dollars to the worst actor in the entire WP ecosystem, someone who keeps repeatedly violating the GPL and now has gone beyond that into patents. Why reward that? I wouldn’t sell it if he offered a million dollars.</p>
<p>There are so many people doing amazing things in the WP community, and 100% GPL! I can and have supported them almost every opportunity I can, and one of the things I’m most proud of in the world is how many fantastic open source businesses have been built on top of WordPress.</p>
<p>And it’s just the beginning — if you remembered in 2010 Chris said that going GPL would destroy businesses and sticking to the principles of our license would destroy investment in WordPress — we all know how that’s worked out since then.</p></blockquote>
<p>Such a statement, combined with the WCSF video, highlights that the issue is about far more than the domain and its investment potential &#8212; a 10x return in less than a year would make for an excellent investment, in the near impossible situation Pearson would offer that.</p>
<p>No, the move was quite clearly a personal one &#8212; if also convenient &#8212; for Mullenweg, and that&#8217;s why terms like &#8220;bully&#8221;, &#8220;petty&#8221;, and &#8220;spiteful&#8221; have been used by many WordPress community members surprised by his actions. They expected more. They expected better, even when directed toward someone as controversial as Chris Pearson.</p>
<h2>Pearson&#8217;s patent</h2>
<p>While a tantalizing story, the battle over thesis.com is not <em>the</em> story here. It has simply been the spark to reignite old disputes with new fervor with potentially much bigger consequences than the 2010 affair ever reached.</p>
<p>One of two additional large components of this story is an active patent application by Pearson that was submitted in 2012 and published in 2014. Keep in mind &#8212; and Chris Pearson reiterated this to me many times &#8212; it is an application for a patent, not a published patent.</p>
<h3>A patent on Thesis 2, or all web templates?</h3>
<p>The main patent is titled, <a href="https://patents.google.com/patent/US20140095982A1/en?q=thesis&q=diythemes"><em>Systems, Servers, and Methods for Managing Websites</em></a>. Chris Pearson is listed as the inventor and DIYthemes the assignee.</p>
<p>The patent never mentions WordPress or WordPress themes, however both in the abstract and in the text, it does have many similarities to what one may expect as a description of a general template mechanism for a website, versus a specific description of the Thesis 2 technology.</p>
<p>Here is the abstract in full (and here is the <a href="https://poststatus.com/wp-content/uploads/2015/07/US20140095982-thesis-patent-app.pdf">full patent application PDF</a>, including art):</p>
<blockquote><p>Systems, servers, and methods for managing websites. Some embodiments provide methods which include, according to a user selection of a website skin, activating the selected skin. The skin comprises at least one structural box further comprising structural code for the website. The method also includes receiving a request (for instance a call to a hook) to serve the website. Further, the method includes, responsive to the request, outputting (by echoing PHP code if desired) the structural code with style related code applied thereto according to a reference between the box and a style package (which comprises the stylistic code). The outputting can occur in an order associated with the boxes. In some situations, another skin can be activated. Moreover, a change (or, perhaps, an edit) can be made to another skin and displayed without affecting the website. Moreover, another skin can be selected and associated with the website.</p></blockquote>
<p>I discussed the patent at length with Chris Pearson, and while much of that conversation is off the record, I can share what I believe his motivations are with the patent application, and what I think the potential implications for this new chapter of Pearson versus Mullenweg are.</p>
<h3>Discovery and publicity of the patent</h3>
<p>This patent and another that&#8217;s since been rescinded were discovered by Automattic&#8217;s lawyers during the UDRP proceedings. There is debate as to how members of the WordPress community discovered the patents&#8217; existence &#8212; Jeff Chandler of WP Tavern and Carl Hancock of Gravity Forms were two of the first to discuss it publicly &#8212; but there is speculation from Chris Pearson and others that the community discovery of these patents was leaked by Mullenweg himself in order to deflect the attention at the time away from the domain issue and onto the patents and their potential implications.</p>
<p>I honestly don&#8217;t care how they came up, though Pearson&#8217;s questioning of Jeff Chandler&#8217;s journalistic integrity were uncalled for. It is anyone&#8217;s right and ability to tip someone off to legitimate news &#8212; and these patent applications are legitimate news &#8212; and I don&#8217;t believe for a second that Chandler has played puppet to his boss&#8217;s wishes. He has dutifully and to the best of his ability written about whatever news matters to the community, and I respect him for it.</p>
<p>Nevertheless, this patent does potentially have significantly more newsworthiness, depending on if it is approved and how it is defended by Pearson if it is approved.</p>
<h3>Patent law and litigation</h3>
<p>Patents often get a bad reputation, and their role in the software world is quite murky. I apologize in advance for this long sidebar on the wild world of patents.</p>
<h4>Patent trolls</h4>
<p>Most folks have heard of &#8220;patent trolls&#8221; that prey on companies using vague or overly generic patents, demanding big payouts.</p>
<p>Patent law is weird, and the lawsuits that result are infamously unpredictable and cause a scenario ripe for abuse. For example, filing patent lawsuits in one district over another can have enormous impact, like <a href="http://www.nytimes.com/2006/09/24/business/24ward.html?pagewanted=all&_r=0">the case of Marshall, Texas</a>, which is a hotbed for patent trolls:</p>
<blockquote><p>Patent litigation is a growing business across the country; Marshall is just the most visible example. Among the weightier issues behind the mushrooming of its patent docket is whether the elements that have made it expand — hungry plaintiffs’ lawyers, speedy judges and plaintiff-friendly juries — are encouraging an excess of expensive litigation that is actually stifling innovation.</p>
<p>Some say yes. “A lot of the cases being filed in Marshall are by patent holding companies, or patent trolls, as they’re called, whose primary and only assets are patents,” Mr. Tyler said.</p></blockquote>
<p>Companies that deal in patents but do not utilize the patented technology are <a href="https://www.patentfreedom.com/about-npes/background/">called non-practicing entities (NPEs)</a>.</p>
<p>One of the concerns with Pearson&#8217;s patent would be if it were approved and he sold it to an NPE. It&#8217;s not uncommon for NPEs to acquire patents with the express purpose to enforce them:</p>
<blockquote><p>Finally, of course, some entities buy patents with the express purpose of licensing them aggressively. For instance, about 25% of “parent” NPEs tracked by PatentFreedom are enforcing only patents that they had acquired. Another 60% are asserting patents originally assigned to them, and the remaining 15% are asserting a blend of originally assigned and acquired patents. However, if we add in the more than 2,100 subsidiaries and affiliates of these entities and treat them all as standalone entities, we find that 19% of them are originally assignees, and 69% are acquirers, and 12% are blends.</p>
<p>Regardless of the important variations in their origin and behavior, NPEs present a fundamentally different challenge than operating company patent assertions.</p></blockquote>
<h4>Software patents unpredictability and &#8220;obviousness&#8221;</h4>
<p>The concept of software patents <em>at all</em> has been in dispute for a long time. Thousands have been awarded, but there are a handful of past court rulings that seem to <a href="https://www.law.cornell.edu/uscode/text/35/part-II/chapter-10">govern the US Patent and Trademark office&#8217;s interpretations</a> for making decisions when reviewing software patents.</p>
<p><a href="http://www.ipwatchdog.com/2014/02/01/when-is-an-invention-obvious/id=47709/">Obviousness</a> is a key term in the patent world. Patent applicants aim to create &#8220;meaningful&#8221; patents, but &#8220;at a minimum you must have claims that embody patent eligible subject matter, demonstrate a useful invention, cover a novel invention and which are non-obvious in light of the prior art. Obviousness is typically the real hurdle to patentability, and unfortunately the law of obviousness can be quite subjective and difficult to understand. At times obviousness determinations almost seems arbitrary.&#8221;</p>
<p>&#8220;Art&#8221; is the outlay of the invention by the applicant, and the invention&#8217;s ability to be patented depends on &#8220;prior art&#8221; not deeming the invention as obvious. Establishing non-obviousness for software has a contentious history. If it can be shown that, &#8220;any combination of prior art references that when put together would be the invention in question,&#8221; then the applicant is in trouble.</p>
<p>But there is a great deal of potential for subjectivity from thousands of patent examiners:</p>
<blockquote><p>Still, ever since the Supreme Court’s decision in KSR [<a href="http://www.ipwatchdog.com/2012/04/29/ksr-the-5th-anniversary-one-supremely-obvious-mess/id=24456/">reference</a>] there has been a great deal of subjectivity in the application of the law of obviousness, which is apparent if you look at the patents that issue, patents that are finally rejected and ultimately abandoned, and the patents the Federal Circuit ultimately finds to include obvious patent claims. There is little to no predictability at the edges.</p></blockquote>
<h4>The Alice case</h4>
<p>In my research, the <em>Alice case</em> came up many times as a pivotal case for helping to define the legitamacy of software patents. Martin Goetz is the holder of the first ever software patent, and has <a href="http://www.ipwatchdog.com/2015/02/06/alice-v-cls-bank-is-a-victory-for-software-patents/id=54489/">an excellent write-up on the importance of the Alice case</a>.</p>
<blockquote><p>I have been asked for my opinion based my long history in the software industry and from my perspective as someone that has followed that controversial question “Is Software patentable”? That question first began to be publicly debated when I received the first software patent in 1968 for an invention on a new way of sorting data on a computer. Shortly thereafter a publication printed a page one headline “First Patent is Issued for Software, Full Implications Are Not Yet Known.”</p>
<p>Forty five years later a variation of that question was again before the Supreme Court when it agreed to hear the appeal of the Alice v. CLS Bank case.</p></blockquote>
<p>Goetz argues that the Alice case is a victory for software patents on both sides: that it helps true inventions gain patents (he and others assign a high standard to define &#8220;invention&#8221;), and it also helps prevent abuse of overly vague or non-inventive &#8220;obvious&#8221; patents to be denied:</p>
<blockquote><p>The Alice v CLS Bank Supreme Court decision in June 2014 was a great victory for those that believe that inventors that use a digital computer to innovate can get a patent on their invention. It is also a victory for those people and organizations that recognize how the patent System has been abused for many years by trolls and others where there was no invention. Since the Supreme Court decision in June, thousands of patents that should never have been issued are now being deemed invalid by the US Courts and by the Patent Office.</p></blockquote>
<h4>Obviousness and invention for Pearson&#8217;s patent</h4>
<p>This long and boring description of patents is necessary because Pearson&#8217;s patent application is still just an application, and it can be challenged, both by the patent reviewer, but also by third parties.</p>
<p>As patent obviousness is &#8220;so unevenly applied,&#8221; there is some risk in not challenging Pearson&#8217;s patent, if a third party like Automattic (or a myriad of other web template providers) is worried about the potential implications of the patent. Although, the Alice case does seem &#8212; in my very amateur opinion &#8212; to offer better guidance to reject the patent based on a lack of true invention.</p>
<h3>Pearson&#8217;s reasoning for a patent, and its likelihood for success</h3>
<p>Patents are not cheap to apply for. The patent application Pearson submitted is 34 pages of art diagrams and text describing the inventiveness of Thesis 2, though Thesis 2 is not specifically named.</p>
<p>I asked Pearson why he applied for the patent, which he did not want to share the specifics of his position due to the open nature of the application. I&#8217;ve racked my brain to try and determine the potential causes as well.</p>
<p>There are only a couple of decent outcomes for Pearson with this patent application. The most likely, and not good outcome for him, is that he is denied the patent; and in this case he would have spent a great deal of money for nothing.</p>
<p>In the event he does get the patent &#8212; or perhaps even before it is fully reviewed for approval &#8212; he could face a challenge from Automattic or other parties that may be concerned his invention&#8217;s description could apply more broadly than Thesis 2.</p>
<p>If he gets the patent, and he survives a challenge, I see three ways he could theoretically use it:</p>
<ul>
<li>He can do nothing.</li>
<li>He can sell it to the highest bidding NPE, which would be a dreadful outcome for any web entities that sell templates.</li>
<li>He can keep it in his back pocket, in case someone threatens his business or his software license, wherein he can initiate a lawsuit.</li>
</ul>
<p>Honestly, the whole patent route seems odd. I don&#8217;t love the idea of this patent being approved, because the application does seem overly broad toward all web templates to me, from the title to the meat of the application&#8217;s art. However, there are loads of patents in the world for incredibly silly things that have never really impacted a lot of folks&#8217; life; it&#8217;s just that it doesn&#8217;t mean a silly patent <em>couldn&#8217;t</em> become a problem. The Electronic Frontier Foundation has <a href="https://www.eff.org/patent">mountains of evidence</a> of patent holders causing havoc.</p>
<p>I&#8217;m not much of a gambler, but if I had to gamble on this I&#8217;d put my money on this patent never being approved, and definitely never truly impacting the web or WordPress industry at scale.</p>
<p>I don&#8217;t think Pearson is a bad guy for wanting to patent his work. When I requested comment about the patents, he told me, &#8220;If I were ever to consider selling my business, things like trademarks and patents show up on the balance sheet and add to the bottom line,&#8221; but that he views them as, &#8220;one of many expensive, ridiculous options for bolstering one&#8217;s business,&#8221; versus a way to celebrate and protect his achievements as I previously characterized his intentions.</p>
<h2>The GPL</h2>
<p>Most agree that the GPL has not been well tested in court, though a <a href="https://en.wikipedia.org/wiki/Software_license">software license</a> is a &#8220;legal instrument.&#8221; There is often confusion over whether a license is a contract or not.</p>
<h3>License versus contract</h3>
<p>One of my favorite <a href="http://softwarelawyer.blogspot.com/2008/01/jacobsen-v-katzer.html">things I&#8217;ve read on this</a> is by former Adobe Associate General Counsel Robert Pierce:</p>
<blockquote><p>A license is not a contract. This much I know.</p>
<p>Rather, a license is a permission granted by one party to another allowing use of a property without fear of lawsuit brought by the granting party. A license does not include a return promise (i.e., consideration) from the licensee. So, as we all learned in law school, a license cannot be a contract under law. This is not to say that a license cannot be an element of a contract under which two parties trade promises, one of such promises being a license. This is commonly known as a &#8220;license agreement.&#8221; But a bald license, a one-way promise, is enforceable outside of contract law. It is something apart. It exists and is enforceable under property law doctrine.</p>
<p>What makes things difficult is that the scope of a license&#8217;s grant, and the conditions and restrictions on the license (or all of them together) can make what is intended to be a one-way license look a lot like a contract. The precise wording used becomes critical.</p></blockquote>
<p>The distinction can be significant because, &#8220;contracts are enforceable by contract law, whereas licenses are enforced under copyright law,&#8221; though even this rule depends on the jurisdiction where the matter is being discussed. His larger point is that a license is a one-way street, whereas a contract is agreed upon by both sides.</p>
<h3>Spirit of the GPL</h3>
<p>There is little debate that a &#8220;Split GPL&#8221; or &#8220;PHP GPL&#8221; license is perfectly GPL compatible, though Mullenweg doesn&#8217;t consider that the &#8220;<a href="https://github.com/WordPress/book/blob/e55a93f1056ffac8466944086b2c5104becab9c4/Content/Part%206/42-spirit-of-the-gpl.md">spirit of the GPL</a>,&#8221; and companies like Envato&#8217;s ThemeForest and others have felt the consequences of not adopting 100% GPL licenses.</p>
<p>From <em>Milestones</em>:</p>
<blockquote><p>While not everyone liked the fact that the WordPress project would only support 100% GPL products, most people had accepted it. Many, however, were taken by surprise, by a sudden flare-up around not just the legalities of the GPL, but the “spirit” of the license. In a 2008 interview, Jeff Chandler asks Matt about the spirit of the GPL. Matt says that the spirit of the GPL is about user empowerment, about the four freedoms: to use, distribute, modify, and distribute modifications of the software. Software distributed with these four freedoms is in the spirit of the GPL. WordPress was created and distributed in this spirit, giving users full freedom with regard to the software.</p>
<p>The Software Freedom Law Center&#8217;s opinion &#8212; with regards to WordPress themes, however &#8212; gives developers a loophole, one that helps them achieve GPL compliance, but denies the same freedoms as WordPress. PHP in themes must be GPL, but the CSS, images, and JavaScript do not have to be GPL. This is how Thesis released with a split license &#8212; the PHP was GPL, while the rest of the code and files were proprietary. This split license ensures that the theme is GPL compliant yet it isn&#8217;t released under the same spirit as the GPL&#8217;s driving user-freedom ethos.</p>
<p>The loophole may have kept theme sellers in line with the GPL, but WordPress.org didn&#8217;t support that approach. In a 2010 interview, Matt says “in the philosophy there are no loopholes: you’re either following the principles of it or you’re not, regardless of what the specific license of the language is.&#8221; Theme sellers that sell their themes with a 100% GPL license are supported by WordPress. Those that aren’t don’t get any support or promotion on WordPress.org or on official resources. This is also one of the WordCamp guidelines, introduced in 2010; that WordCamps should promote WordPress’ philosophies. If a speaker, volunteer, or organizer is distributing a WordPress product it needs to be 100% GPL, i.e., the CSS, JavaScript, and other assets need to be GPL, just like the PHP.</p></blockquote>
<p>Mullenweg believes that Thesis 2 is not only not in the spirit of the GPL, but flagrantly operates in total violation of it, as Thesis 2 carries a 100% proprietary license. Considering the implications for folks that make stuff compatible with the GPL, it&#8217;s little surprise that Mullenweg has taken the stance and actions he has toward Pearson.</p>
<h3>Thesis 2 carries a proprietary license</h3>
<p>Chris Pearson&#8217;s <a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507962">comment on his blog post</a> describes that the theme has always been a proprietary license, and he describes why it is okay to be such:</p>
<blockquote><p>In October 2012, I released an all-new version of Thesis that carried the same name as the original (which had a split-GPL license), but that’s where the similarities stopped.</p>
<p>The new Thesis is not a Theme—it is an operating system for templates and design. This system runs Skins and Boxes, which are similar to Themes and Plugins, but with a boatload of built-in efficiencies that Themes and Plugins cannot provide.</p></blockquote>
<p>It is worth noting the final paragraph of the SFLC&#8217;s opinion that Mullenweg has cited numerous times as justification against proprietary licenses <em>does</em> have a provision for avoiding WordPress&#8217;s copyright:</p>
<blockquote><p>Finally, we note that it might be possible to design a valid WordPress theme that avoids the factors that subject it to WordPress’s copyright, but such a theme would have to forgo almost all the WordPress functionality that makes the software useful.</p></blockquote>
<p>That&#8217;s exactly what Pearson believes Thesis 2 is. But the GPL has rarely been tested in a proper court, and never from a WordPress perspective. The SFLC&#8217;s opinion is just that, for now, whether Mullenweg likes it or not.</p>
<h3>The GPL in court</h3>
<p>The Free Software Foundation maintains the copyright on the text of the GPL itself, and between the FSF and the SFLC, a <a href="https://en.wikipedia.org/wiki/GNU_General_Public_License#Legal_status">small number of lawsuits</a> have occurred, and a German court upheld the GPL as a &#8220;valid, legally binding&#8221; license, but most of these tests have occurred outside of the United States. From what I can tell, cases involving the GPL have largely settled outside of court when based in the United States, or were argued on whether the GPL was legally applied, like in the case of <a href="https://en.wikipedia.org/wiki/SCO_Group,_Inc._v._International_Business_Machines_Corp.#The_GPL_issue">SCO vs IBM</a>, rather than whether the GPL was legally binding itself.</p>
<p>In another case, <a href="https://en.wikipedia.org/wiki/Wallace_v._International_Business_Machines_Corp.">Wallace vs FSF</a>, Daniel Wallace compared the GPL to price fixing, as it required software to be free. The FSF won the case, as the judge cited, &#8220;The GPL encourages, rather than discourages, free competition and the distribution of computer operating systems, the benefits of which directly pass to consumers. These benefits include lower prices, better access and more innovation.&#8221;</p>
<p>A much <a href="http://www.infoworld.com/article/2893695/open-source-software/vmware-heading-to-court-over-gpl-violations.html">newer case involving VMware</a> again tests the GPL. The Software Freedom Conservancy, &#8220;claims VMware is using the Linux kernel without respecting the terms of its copyright license, the GPL.&#8221; This case may offer a better precedent for WordPress and its derivative works, as it is centered on &#8220;module loading&#8221; in VMware, &#8220;with an insulating layer to allow its kernel to use unmodified Linux drivers.&#8221; The case gets murkier than that, as it may not have been as isolated as it was attempted, but the result could be decent precedent for similarly loading WordPress themes and plugins, in my opinion.</p>
<h3>Limited guidance</h3>
<p>Few lawyers want to be the first to test something in court. It&#8217;s easier to make a case when there are many cases before you to provide guidance. With the GPL, there is what&#8217;s called &#8220;limited guidance,&#8221; meaning that it&#8217;s untested, and therefore the outcome of a GPL case in the US could be very difficult to predict.</p>
<p>If a lawsuit does occur, it could prove costly to all parties involved, and I think it&#8217;s clear that Pearson and Mullenweg both wish that litigation was not happening, though both of them maintain a bit of a &#8220;you started it&#8221; attitude.</p>
<p>Without a formal court proceeding, which could last years, it&#8217;s going to be near impossible for Matt Mullenweg to fully prevent non-GPL compatible licenses to exist for WordPress themes and plugins. His best method to prevent it is to do what he&#8217;s done so far: make an example of bad offenders and cause anyone thinking of using a non-GPL compatible license to reconsider.</p>
<h2>Are all WordPress themes derivative works?</h2>
<p>A key question to whether themes and plugins must be GPL compatible licensed is whether the theme or plugin is a derivative of WordPress itself. If it is derivative, then it is under the umbrella of the GPL&#8217;s Copyleft nature.</p>
<p>Folks disagree a good bit on how themes and plugins should be considered as derivative works, though most either agree with Mullenweg&#8217;s strict &#8220;spirit of the GPL&#8221; view, or at least have molded to avoid being an outcast.</p>
<p>The strongest argument I&#8217;ve seen in favor of all themes being derivative of WordPress &#8212; no matter how much or little they rely on WordPress functionality &#8212; is from WordPress lead developer Mark Jaquith:</p>
<blockquote><p>There is a tendency to think that there are two things: WordPress, and the active theme. But they do not run separately. They run as one cohesive unit. They don’t even run in a sequential order. WordPress starts up, WordPress tells the theme to run its functions and register its hooks and filters, then WordPress runs some queries, then WordPress calls the appropriate theme PHP file, and then the theme hooks into the queried WordPress data and uses WordPress functions to display it, and then WordPress shuts down and finishes the request. On that simple view, it looks like a multi-layered sandwich. But the integration is even more amalgamated than the sandwich analogy suggests.</p>
<p>Here is one important takeaway: <em>themes interact with WordPress (and WordPress with themes) the exact same way that WordPress interacts with itself</em>. Give that a second read, and then we’ll digest.</p>
<p>The same core WordPress functions that themes use are used by WordPress itself. The same action/filter hook system that themes use is used by WordPress itself. Themes can thus disable core WordPress functionality, or modify WordPress core data. Not just take WordPress’ ultimate output and change it, but actually reach into the internals of WordPress and change those values before WordPress is finished working with them. If you were thinking that theme code is a separate work because it is contained in a separate file, also consider that many core WordPress files work the same way. They define functions, they use the WordPress hook system to insert themselves at various places in the code, they perform various functions on their own but also interact with the rest of WordPress, etc. No one would argue that these core files don’t have to be licensed under the GPL — but they operate in the same way that themes do!</p>
<p>It isn’t correct to think of WordPress and a theme as separate entities. As far as the code is concerned, they form one functional unit. The theme code doesn’t sit “on top of” WordPress. It is within it, in multiple different places, with multiple interdependencies. This forms a web of shared data structures and code all contained within a shared memory space. If you followed the code execution for Thesis as it jumped between WordPress core code and Thesis-specific code, you’d get a headache, because you’d be jumping back and forth literally hundreds of times. But that is an artificial distinction that you’d only be aware of based on which file contained a particular function. To the PHP parser, it is all one and the same. There isn’t WordPress core code and theme code. There is merely the resulting product, which parses as one code entity.</p></blockquote>
<p>Jaquith&#8217;s argument that the theme and WordPress execute together to form a joint &#8220;modified work&#8221; is the key phrase, I believe. As he states, and I tend to agree, it does not matter that the files are separate or that they can be distributed independently; together, when executed, they are so intertwined that they become a single work.</p>
<p>That said, the theme is clearly dependent on WordPress itself, which is another common justification that themes are derivative. Explaining this concept is simple: WordPress can be distributed without any theme but those that ship with it by default. But a distributed theme, like Thesis, must be <em>installed and activated using WordPress&#8217;s own schema for loading a template</em>, and cannot operate independently of WordPress.</p>
<h3>What about the WordPress REST API?</h3>
<p>Thus far, we&#8217;ve discussed the derivative nature of WordPress themes and plugins, which require they operate within the WordPress install. It is a different matter if we consider applications that consume data or interact with WordPress as an outside application.</p>
<p>The WordPress REST API enables one to interact with or consume data from WordPress, while being wholly independent of the WordPress install. Jaquith makes a clear exception for a scenario like this (and also applies it to technologies like RSS and XML-RPC):</p>
<blockquote><p>Something that interacts with these APIs sits entirely outside of WordPress. Google Reader doesn’t become part of WordPress by accessing your feed, and MarsEdit doesn’t become part of WordPress when you use it to publish a post on your WordPress blog. These are separate applications, running separately, on separate codebases. All they are doing is communicating. Applications that interact with WordPress this way are separate works, and the author can license them in any way they have authority to do so.</p></blockquote>
<h3>The GNU&#8217;s take</h3>
<p>The GNU agrees with Jaquith&#8217;s take. They provide <a>an FAQ</a> to answer, &#8220;&#8221;What is the difference between an &#8216;aggregate&#8217; and other kinds of &#8216;modified versions&#8217;?&#8221; The emphasis provided is my own:</p>
<blockquote><p>An “aggregate” consists of a number of separate programs, distributed together on the same CD-ROM or other media. The GPL permits you to create and distribute an aggregate, even when the licenses of the other software are non-free or GPL-incompatible. The only condition is that you cannot release the aggregate under a license that prohibits users from exercising rights that each program&#8217;s individual license would grant them.</p>
<p><em>Where&#8217;s the line between two separate programs, and one program with two parts? This is a legal question, which ultimately judges will decide</em>. We believe that a proper criterion depends both on the mechanism of communication (exec, pipes, rpc, function calls within a shared address space, etc.) and the semantics of the communication (what kinds of information are interchanged).</p>
<p><em>If the modules are included in the same executable file, they are definitely combined in one program. If modules are designed to run linked together in a shared address space, that almost surely means combining them into one program</em>.</p>
<p>By contrast, pipes, sockets and command-line arguments are communication mechanisms normally used between two separate programs. So when they are used for communication, the modules normally are separate programs. But if the semantics of the communication are intimate enough, exchanging complex internal data structures, that too could be a basis to consider the two parts as combined into a larger program.</p></blockquote>
<p>The GNU argument falls very much in line with Jaquith&#8217;s, though admits itself that judges must decide whether it&#8217;s the case, in the end.</p>
<h3>The case against The GNU position on derivative works</h3>
<p>The University of Washington School of Law has a <a href="http://www.law.washington.edu/lta/swp/index.html">section of their website</a> devoted to the, &#8220;business, legal and technical consequences of choosing Open Source Software (OSS) or proprietary software.&#8221; They cover many of the topics I&#8217;ve outlined in this post so far, and <a href="http://www.law.washington.edu/lta/swp/Law/derivative.html">in the case of the GPL and derivative works</a>, they believe the GNU is overstepping with an &#8220;expansive definition&#8221; of derivative works with consequences, &#8220;counter to the goals of the proponents of Free Software.&#8221;</p>
<p>The most compelling of multiple derivative works examples they provide is that of subclasses. For example, imagine a class, <code>Some_Theme_Class</code> that extends <code>Some_Core_WordPress_Class</code>. The GPL FAQ is very hardline on the topic (and for what it&#8217;s worth, Thesis 2 does extend some WordPress core classes). Washington believes the GNU stance on inheritance is too over-reaching:</p>
<blockquote><p>Example 5: Programmer X wishes to write a class D, that is a subclass of existing class B. Class B is subject to the terms of the GPL. If X distributes D, does it have to be licensed under the terms of the GPL?</p>
<p>The answer given in the GPL FAQ is short and to the point: &#8220;Subclassing is creating a derivative work.&#8221; In our example, this makes D a work derived from B, and thereby makes D subject to the terms of the GPL upon distribution. This approach attempts to further broaden the reach of the GPL, but it again leads to counter-intuitive results.</p>
<p>Typical object oriented programming languages include a standard class hierarchy. This hierarchy provides a framework within which application developers can build their programs. The standard classes typically provide useful classes that represent user interface elements (e.g. windows, buttons, etc.), collection classes (for handling collections of data), and input-output abstractions (e.g. files and networking connections). In many object oriented languages, each class must be a subclass of exactly one superclass. And for this reason, the class hierarchies are rooted by a highly generic, standard class called Object. (The question of the superclass of Object is beyond the scope of this article.) The class Object describes only the most general properties and behaviors. For instance, in Java, the class Object only performs a handful of functions. In Java, every class is a subclass (directly or indirectly) of the Object class. Under the GPL approach, then, every program written in Java is a derived work of Object, because every program written in Java by definition consists of classes that inherit from the Object class.</p></blockquote>
<p>Whether this argument or any of the others Washington outlines would apply to WordPress themes and/or plugins would, again, need to be settled in court. But Washington does give a compelling argument.</p>
<p>They conclude with the following:</p>
<blockquote><p>In some ways, the apparent weaknesses in the GPL should come as no surprise, as the GPL was born of an era in which the central artifact of software development and distribution was the monolithic executable. In such a universe, software development proceeded principally by modifying the existing source text of programs, compiling source modules, linking the corresponding object files, and distributing the resulting executable. This model of software development and distribution has become increasingly fractured in an era characterized by highly dynamic, late binding, object- and network-based systems. The GPL, consequently, strains to cover these newly arising scenarios.</p>
<p>To effectuate the goals of the free software movement, the drafters of the GPL urge a generally expansive definition of derivative work. The great irony is, of course, that such an expansive definition would have second order consequences that are exactly counter to the goals of the proponents of Free Software. A broad definition of derivative would give code authors less freedom to create software that they can truly call their own and do with as they please. And if naive analytic approaches such as &#8220;subclassing equals derivation&#8221; reign, then proprietary vendors such as Microsoft could arguably stake claim to every program ever written in C#, because they authored the original class hierarchy. And since it seems unlikely that courts would employ different standards depending on the goals or ideological motivations of licensors, proponents of free software might want to be careful what they wish for: what&#8217;s good for the GNU might not be good for the gander.</p></blockquote>
<h3>Aggressive license agreements</h3>
<p>Both the GPL and DIYthemes&#8217; proprietary license could be appropriately identified as aggressive. The Copyleft nature of the GPL annoys many open source advocates, who would prefer a less restrictive license for developers, like the MIT or BSD licenses. The GPL is absolutely an opinionated license.</p>
<p>Pearson&#8217;s proprietary license is also aggressive, in the other direction. I&#8217;ve never purchased a WordPress-centric product that so strongly forced me to accept a license. Usually, you have to look in the source code or a page on the website for a license; DIYthemes forces you to accept the <a href="http://diythemes.com/thesis/rtfm/software-extensions-license-agreement/">terms of the proprietary license</a> before you can download the product at all.</p>
<h3>Derivative works are not a bright line</h3>
<p>The GNU attempts to offer a &#8220;bright line&#8221; distinction for derivative works. A bright line, in much of the legal analysis I&#8217;ve read, is where <em>thing x</em> is so because of <em>thing y</em>, and can be applied across the board. You can clearly see the bright line, and when it has been crossed.</p>
<p>Washington proves the point quite well that the GNU&#8217;s bright line approach to derivation is quite challengeable. But I don&#8217;t think their arguments prove that WordPress themes in particular are not derivative. I believe, from a legal perspective, it&#8217;s fuzzier than a bright line approach, and if I were Mullenweg or anyone defending GPL software, I would not be excited to take the issue to court.</p>
<p>The &#8220;spirit of the GPL&#8221; is to offer users liberal freedoms, even while restricting developers building on a GPL licensed application. And I believe there is merit in the fact that WordPress, its co-founders, its lead developers, and the vast majority of its copyright holders (contributors) wish to defend the spirit of the license, even if it&#8217;s not been tested in court.</p>
<p>Pearson is not in the majority opinion by using a proprietary license, but he is also not definitively in a position of legal wrongdoing. His desire to protect his works from user freedoms with a proprietary license may well be tested all the way to the courts, and he must be prepared to deal with that, but I don&#8217;t believe there is clear wrongdoing, legally, with his license.</p>
<h2>A tale of idealism</h2>
<p>Matt Mullenweg and Chris Pearson are two of the most idealistic people I&#8217;ve ever observed. They are near polar opposites, from their business belief systems and even their general world views.</p>
<p>One of the most depressing components of my research was something Pearson told me. I asked him why he doesn&#8217;t just get out of it all and do something else. He&#8217;s not married to the culture of WordPress bestowed on it by its leaders. He called it, the &#8220;zeitgeist of western culture,&#8221; with its openness, zen attitude, and more that he feels no need to embrace if he doesn&#8217;t want to.</p>
<p>But he admits that WordPress, &#8220;is the most used piece of software to build a website in the world. WordPress was the beneficiary of impeccable timing.&#8221; And it&#8217;s a tool for him to make his living; it&#8217;s his job, and he doesn&#8217;t see a need to be in love with every aspect of his job. This is what made me sad, because for most of us that make our living within this space, we were able to escape the &#8220;it&#8217;s just a job&#8221; mentality and be emotionally enriched by what is possible on the open web.</p>
<p>Matt could probably drop his various issues with Pearson and life would go on. The vast majority of WordPress businesses could understand the status quo and live by it, and those that don&#8217;t can keep living their lives outside of the approval of Mullenweg, and for that matter, the official WordPress project and website. But he too insists to stand up for his ideals and the web he believes in. He sees himself as a defender of the user, and his defense of the GPL is an extension of his core beliefs on software.</p>
<p>They will never agree on licensing, that much is clear. The question of what&#8217;s next is multi-layered.</p>
<h3>Will litigation continue?</h3>
<p>Undoubtedly, yes, litigation will continue. But the litigation should be viewed as three distinct parts:</p>
<ul>
<li>In regard to the thesis.com domain, it&#8217;s really a sideline issue that resulted from more deep-rooted differences in ideals that turned into a personal spat. Pearson may continue in court to try and get the domain back, but I doubt it. I don&#8217;t know if Automattic will relent on the trademark cancellation requests, but I wouldn&#8217;t be surprised if they dropped it in some form of settlement.</li>
<li>The patent issue is not over. I believe Automattic and potentially other organizations will challenge Pearson&#8217;s patent application using a variety of legal options available. The chances the patent gets approved or holds up long term are unlikely (but yes, it is possible), and I don&#8217;t believe there is a significant chance it will have longstanding implications on the WordPress project.</li>
<li>I believe the GPL will continue to be tested in court, and eventually we may have a proper precedent set to put current questions aside. I won&#8217;t pretend a guess how it will turn out, because I think it truly depends on many, many factors. I do think that if Matt Mullenweg pursues a case himself, he will be joined by a number of interested organizations, including the Free Software Foundation; or the GPL debate could be settled in court in a completely different dispute, unrelated to WordPress &#8212; but have a longstanding impact on products made for WordPress.</li>
</ul>
<h3>Is this debate bad for WordPress?</h3>
<p>The <em>way</em> this debate has occurred is bad for WordPress. Neither Matt Mullenweg nor Chris Pearson looks like a saint right now. And parts of the whole thing don&#8217;t do a whole lot to further the conversation.</p>
<p>At the root of the debate is licensing, and that debate is worth having.</p>
<p>It is important that we separate the intent and the legal interpretation of the GPL. It is also important that we separate one&#8217;s legal ability to not license distributed WordPress products as GPL compatible, versus the business and community consequences that may result from such a decision.</p>
<h2>Endmatter</h2>
<p>This post would not be possible without the Post Status <a href="https://poststatus.com/partners">Partners</a> and <a href="https://poststatus.com/profiles">Members</a> that fund the website, and my ability to write about WordPress full time. If you enjoyed this post, please consider becoming a <a href="https://poststatus.com/club">Post Status member</a> to fund more free content, plus loads of great members-only benefits, including a daily-ish newsletter that keeps you covered on the happenings of the WordPress world.</p>
<p>I would also like to thank Matt Mullenweg and Chris Pearson for the interviews they provided me in preparation of this post.</p>
<p>And I&#8217;d like to thank my lawyer, <a href="http://associatesmind.com">Keith Lee</a> (a WordPress fan and blogger himself!) for helping me think through some of the legal matters discussed &#8212; though the opinions themselves are my own.</p>
<p>Finally, I&#8217;d like to thank the folks that helped me review the post, consider my positions, and organize my thoughts. You know who you are.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Jul 2015 01:42:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"WPTavern: Who’s Using the WordPress REST API?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47039";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wptavern.com/whos-using-the-wordpress-rest-api";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4659:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg?resize=1025%2C469" alt="wp-rest-api" class="aligncenter size-full wp-image-43000" /></a></p>
<p>Ryan McCue and the <a href="https://github.com/WP-API/WP-API" target="_blank">WP REST API</a> team are <a href="https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/" target="_blank">seeking feedback</a> on the project ahead of the API merging into core. McCue invited comments on the post to find out how and where it&#8217;s currently being used, in hopes of identifying any roadblocks developers may be facing.</p>
<p>&#8220;We’d love to hear feedback from everyone using this, from JS-only developers coming to WP for the first time, through WordPress plugin and theme developers, all the way through to PHP developers not involved with WordPress,&#8221; he said.</p>
<p>Comments on the post provide a nice overview of places where the API is already in use in production all over the WordPress development community. A few examples include:</p>
<ul>
<li><a href="https://hmn.md/" target="_blank">Human Made</a> uses the API with client projects, i.e. to create a Node-powered frontend and maintain the familiar WordPress admin.</li>
<li><a href="http://reactor.apppresser.com/" target="_blank">Reactor</a> uses the API to create mobile apps that digest the API themselves.</li>
<li><a href="http://aesopstoryengine.com/" target="_blank">Aesop Interactive</a> uses the API with <a href="http://wptavern.com/lasso-frontend-editing-plugin-for-wordpress-now-available-on-github" target="_blank">Lasso</a> and also to power the <a href="http://wptavern.com/new-wp-live-search-plugin-utilizes-the-wp-rest-api" target="_blank">WP Live Search</a> plugin.</li>
<li>A large industrial real estate firm manages its properties via an internal proprietary .NET app with a public-facing site powered by WP. It uses the API to sync property data (in real time) between the internal app and the website so the real estate listings will always be current.</li>
<li><a href="https://www.joininuk.org/" target="_blank">Join In</a>, a site organizing volunteers in the UK, used the API to create <a href="https://www.joininuk.org/widget/" target="_blank">an embeddable JS widget</a>.</li>
<li><a href="https://profiles.wordpress.org/pers/" target="_blank">Per Soderlind</a> used the WP REST API as <a href="https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/#comment-26372" target="_blank">a backend for an iOS application</a> for the Norwegian Ministry of Petroleum and Energy.</li>
<li><a href="http://tri.be/about/" target="_blank">Modern Tribe</a> is building sites that use the REST API to power both Handlebars and full page React templates in themes.</li>
</ul>
<p>Those are just a small sampling of places where the API is being used to make WordPress more flexible for creating custom solutions. For many who are using the API or hoping to use it, the main hindrance is that it&#8217;s not yet in core.</p>
<p>&#8220;The biggest issue right now is that the REST API isn’t included in core,&#8221; a representative from Ashworth Creative <a href="https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/#comment-26390" target="_blank">commented</a>. &#8220;If we build plugins or a theme that needs to consume data asynchronously, we’d either have to bundle the API and have to maintain it in our repositories as a dependency, or have clients install and maintain it on their own.&#8221;</p>
<p>WordPress developer Nate Wright echoed that opinion and is eager to be able to extend it for use in his products, without having to include it as a plugin.</p>
<p>&#8220;Put it in core, so that as a plugin developer I can make use of it in my products,&#8221; he <a href="https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/#comment-26367" target="_blank">said</a>. &#8220;I built the most popular Restaurant Reservations plugin in the .org repo, and I am eager to add a robust capacity/table management component for it using the REST API and a jQuery/Underscore/Backbone stack.&#8221;</p>
<p>Early adopters have the unique opportunity to provide feedback on the REST API and help shape priorities for development. If you are using the API somewhere in the wild, make sure to <a href="https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/" target="_blank">leave your feedback on McCue&#8217;s post</a> to help the team make any necessary changes required before it&#8217;s merged into core.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 21:15:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WPTavern: WPWeekly Episode 200 – The Big Two Oh Oh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=47083&preview_id=47083";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wptavern.com/wpweekly-episode-200-the-big-two-oh-oh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3495:"<p>In this special 200th episode of WordPress Weekly, I&#8217;m joined by <a href="http://marcuscouch.com/">Marcus Couch</a>, <a href="http://strangework.com/">Brad Williams</a>, <a href="http://www.ronalfy.com/">Ronald Huereca</a>, and <a href="http://piratedunbar.com/">Ptah Dunbar</a>. Brad, Ronald, and Ptah were among the first to support WordPress Weekly. They helped get the show off the ground and provided momentum.</p>
<p>Seven years have passed since I started WordPress Weekly. In those seven years, each one of my guests have gone on to do great things with WordPress. We find out what they&#8217;re up to these days and recall memorable moments of the show. Near the beginning of the show, we held a moment of silence in Kim&#8217;s memory.</p>
<p>I had a great time hosting episode 200, but I&#8217;m sad that the <a href="http://wptavern.com/kim-parsell-affectionately-known-as-wpmom-passes-away">late Kim Parsell</a> couldn&#8217;t celebrate with us. When I started WordPress Weekly in 2008, Kim would often join me on each episode to provide a countdown before I pressed the record button.</p>
<p>She was occasionally a <a href="http://wptavern.com/wpweekly-episode-87-%E2%80%93-the-lost-episode">guest on the show</a>. After the show, she would stick around for a half hour to an hour to talk about whatever was on her mind. In many ways, the show offered her an opportunity to connect and speak to WordPress people every week. It was the closest thing to a meetup she could regularly attend.</p>
<p>Thanks to everyone who listens to the show and provides us with valuable feedback. Join us next Wednesday, as we begin the journey to episode 300.</p>
<h2>History of WordPress Weekly:</h2>
<ul>
<li>My first show on Talkshoe.com was 7 years ago on January 11th, 2008.</li>
<li>WordPress 2.3.2 was released.</li>
<li>WordPress 2.5 took the place of 2.4.</li>
<li>Episode 100 was on June 5th 2010.</li>
<li>I took a two year break after episode 117 October 28th, 2011.</li>
<li>I resumed the show on August 16th 2013 which was also my last show on Talkshoe.</li>
<li>Marcus became a co-host January 18th, 2014, on Episode 134.</li>
</ul>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="https://wordpress.org/plugins/flow-flow-social-streams/">Flow-Flow Social Streams</a> lets you display your Facebook, Twitter, and Instagram messages in a responsive grid.</p>
<p><a href="https://wordpress.org/plugins/test-gateway-for-woocommerce/">Test Payment Module for Woocommerce</a> gives you the option to test payments in WooCommerce locally without using services such as Paypal or Authorize.net.</p>
<p><a href="https://wordpress.org/plugins/easy-backup-by-supsystic/">DropBox Backup by Supsystic</a> allows you to backup to Dropbox and FTP with one click. You can also restore full or partial backups from DropBox.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, July 29th 4 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #200:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 20:30:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: Philadelphia, PA to Host WordCamp US December 4th–6th";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47068";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wptavern.com/philadelphia-pa-to-host-wordcamp-us-december-4th-6th";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1943:"<p>Matt Mullenweg <a href="http://ma.tt/2015/07/wcus-philadelphia/">announced</a> that Philadelphia, PA, will host WordCamp US December 4th–6th at the <a href="http://www.paconvention.com/Pages/default.aspx">Pennsylvania Convention</a> center. Philadelphia will also host WordCamp US in 2016, although no dates have been chosen yet.</p>
<p>According to Mullenweg, &#8220;Having it the same place two years in a row allows us to keep logistics a set variable and really focus on the rest of the event in the second year.&#8221; The 2017 and 2018 host cities will be chosen in between the first and second event. This allows the team in the host city to volunteer and gain on-the-ground experience in Philadelphia.</p>
<p>Out of six cities chosen to possibly host WordCamp US and 1,390 total voters, Tavern <a href="http://wptavern.com/which-one-of-these-six-cities-should-host-wordcamp-us">readers voted</a> to have it in Phoenix, AZ, citing <a href="http://wptavern.com/which-one-of-these-six-cities-should-host-wordcamp-us#comment-70157">its warm weather</a> during winter months. Philadelphia, home of the cheesesteak, was a close second.</p>
<p>The event is inspired by WordCamp Europe, where organizers take an entire year to <a href="http://wptavern.com/vienna-austria-to-host-wordcamp-europe-2016">plan and coordinate</a> the event. Some <a href="http://wptavern.com/which-one-of-these-six-cities-should-host-wordcamp-us#comment-70055">readers questioned</a> whether the event would be held this year considering <a href="http://wptavern.com/wordcamp-us-2015-now-accepting-applications-for-host-city">applications to be the host city </a>weren&#8217;t accepted until June.</p>
<p>With only half a year to plan and organize WordCamp US, it will be interesting to see how the first one goes. Let us know if you plan on attending the event and if you&#8217;re going to bring ear muffs as Philadelphia during that time of year is cold.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 17:31:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Matt: WordCamp US to be in Philadelphia";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45259";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:39:"http://ma.tt/2015/07/wcus-philadelphia/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1188:"<p><img class=" wp-image-45261 alignright" src="http://i1.wp.com/ma.tt/files/2015/07/wordcamp1-e1437663434378.png?resize=303%2C309" alt="WordCamp US" />There were <a href="http://ma.tt/2015/06/wordcamp-us-survey/">amazing applications</a> for teams and cities to host the inaugural WordCamp US, a concept originally floated at <a href="http://wordpress.tv/2014/10/26/matt-mullenweg-the-state-of-the-word-2014/">the State of the Word last year</a>. It was very hard to make a choice, but can now announce that the birthplace of the United States, <strong>Philadelphia, will host the first WCUS on December 4th&#8211;6th</strong>. They will also host it in 2016, but no dates have been chosen yet.</p>
<p>Having it the same place two years in a row allows us to keep logistics a set variable and really focus on the rest of the event in the second year. I also want to use it to facilitate experience transfer: We&#8217;ll choose the 2017 + 2018 host city in between the first and second event, so that team can volunteer on the ground the second year Philadelphia hosts it to learn from their experience. Hat tip: Cool graphic by <a href="http://visualrhythm.com/">Andrew Bergeron</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 16:38:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: WordPress 4.2.3 is a Critical Security Release, Fixes an XSS Vulnerability";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47045";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://wptavern.com/wordpress-4-2-3-is-a-critical-security-release-fixes-an-xss-vulnerability";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3025:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/security.jpg"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/security.jpg?resize=1024%2C514" alt="photo credit: Lock - (license)" class="size-full wp-image-40187" /></a>photo credit: <a href="http://www.flickr.com/photos/58441544@N00/2660230441">Lock</a> &#8211; <a href="https://creativecommons.org/licenses/by/2.0/">(license)</a>
<p>WordPress users in the Americas woke this morning to find update notices in their inboxes due to a critical security vulnerability. <a href="https://wordpress.org/news/2015/07/wordpress-4-2-3/" target="_blank">WordPress 4.2.3</a> was released today and automatically pushed out to sites that have auto-updates enabled.</p>
<p>Because this is a security release for all previous versions of WordPress, those who do not have automatic update enabled will need to manually update their sites immediately. Core contributor Gary Pendergast explained the severity of the bug in the release post:</p>
<blockquote><p>WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was reported by <a href="https://profiles.wordpress.org/duck_" target="_blank">Jon Cave</a> and fixed by <a href="http://www.miqrogroove.com/" target="_blank">Robert Chapin</a>, both of the WordPress security team.</p>
<p>We also fixed an issue where it was possible for a user with Subscriber permissions to create a draft through Quick Draft.</p></blockquote>
<p>Pendergast thanked all parties reporting vulnerabilities for <a href="https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/" target="_blank">responsibly disclosing them </a> to the WordPress security team.</p>
<p>This release also contains fixes for 20 bugs from 4.2, including one that might require you to update your database before being allowed back into the admin.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-update-db.jpg"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-update-db.jpg?resize=773%2C370" alt="wp-update-db" class="aligncenter size-full wp-image-47047" /></a></p>
<p>Not all WordPress users who are updating will be greeted with this message, but if you see it, don&#8217;t panic. It&#8217;s related to one of the bug fixes included in the release.</p>
<p>&#8220;It was a bug fix in 4.2.3, not backported &#8211; some versions of PHP didn&#8217;t run the utf8mb4 update correctly,&#8221; Pendergast said when asked about the required database update.</p>
<p>Unfortunately, in some instances, clicking the &#8220;Update WordPress Database&#8221; button may require multiple attempts. This is unusual but Pendergast said that improving database upgrades is high on the team&#8217;s list of priorities.</p>
<p>A list of all the files revised is available on the <a href="https://codex.wordpress.org/Version_4.2.3" target="_blank">4.2.3 release page</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 14:06:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: WordPress Custom Post Type UI Plugin Passes 1 Million Downloads";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46940";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wptavern.com/wordpress-custom-post-type-ui-plugin-passes-1-million-downloads";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5094:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/celebration.jpg"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/celebration.jpg?resize=960%2C482" alt="photo credit: Stephanie McCabe" class="size-full wp-image-47036" /></a>photo credit: <a href="https://stocksnap.io/photo/6V12NODFVM">Stephanie McCabe</a>
<p>In June of 2010, <a href="http://codex.wordpress.org/Version_3.0" target="_blank">WordPress 3.0</a> Thelonious was released with the historic merge of WordPress MU into core and the debut of the brand new Twenty Ten default theme. This pivotal release also gave developers the ability to register their own <a href="http://codex.wordpress.org/Custom_Post_Types" target="_blank">custom post types</a>. Expanding WordPress&#8217; custom content capabilities beyond simple posts and pages has been critical to the platform maintaining its dominance as <a href="http://w3techs.com/technologies/overview/content_management/all" target="_blank">the world&#8217;s most used CMS</a>.</p>
<p>Thousands of WordPress developers make a living from products that are based on custom post types. Five years ago, when the feature was still new, you had to know how to write the code to register a new post type. That&#8217;s when the folks at <a href="http://webdevstudios.com/" target="_blank">WebDevStudios</a> released <a href="https://wordpress.org/plugins/custom-post-type-ui/" target="_blank">Custom Post Type UI</a>, a plugin that offers an admin interface for creating and managing post types and their associated taxonomies.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/cptui_post_type_editor.png"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/cptui_post_type_editor.png?resize=1024%2C604" alt="cptui_post_type_editor" class="aligncenter size-full wp-image-47028" /></a></p>
<p>The company counts more than <a href="https://profiles.wordpress.org/webdevstudios/#content-plugins" target="_blank">30 plugins</a> in its collection on WordPress.org, but Custom Post Type UI is by far the most successful. Last week it passed one million downloads and maintains a 4.6 out of 5-star average rating from users. The plugin is currently active on more than 200,000 WordPress sites.</p>
<h3>Passing the 1 Million Downloads Milestone</h3>
<p>Michael Beckwith, the current maintainer of Custom Post Type UI, published a <a href="http://webdevstudios.com/2015/07/17/the-custom-post-type-ui-million-download-celebration/" target="_blank">post</a> detailing the evolution of the plugin&#8217;s UI and codebase. His transparent account covers how the team overcame the challenges of their massive codebase overhaul and the undetected bugs that come crawling out of the woodwork with a major release.</p>
<p>A plugin with a user base in the hundreds of thousands that manages to maintain a nearly 5-star average rating on WordPress.org is a notable achievement, especially when it involves weathering the UI and code updates required to keep pace with WordPress.</p>
<p>&#8220;I believe this milestone represents the fact that making features usable and more user-friendly to the &#8216;average Joe&#8217; can take you a long ways,&#8221; Beckwith said. &#8220;Custom Post Type UI made it easier for more people to tap into the power and customization ability that custom post types and taxonomies offer to a WordPress powered website. Because of that ease of use, many have added it to their toolbox for every website they have or work on, and recommend it to their friends.&#8221;</p>
<p>The plugin is being developed on <a href="https://github.com/WebDevStudios/custom-post-type-ui" target="_blank">GitHub</a>. Although there are many <a href="https://github.com/WebDevStudios/custom-post-type-ui/labels/enhancement" target="_blank">enhancements</a> under consideration, Beckwith said that no major changes are planned for the near future.</p>
<p>&#8220;I would love more to get more people up-to-date on the current version and let it be the stable version for awhile,&#8221; he said.</p>
<p>&#8220;Looking at our stats page, we still have reported active installs using as far back as version 0.6. While I can sit here scratching my head as to why, I also have to consider that that version is stable enough and still meeting the needs of 0.6% of our users.</p>
<p>&#8220;If it is not breaking for them, and there is no security concerns, then it is not all bad that they are still marching on. There is also the minimum version requirement to keep in mind. There are still WordPress installs active and out in the wild that are not running WordPress 3.8 or higher. Until they are, those users are not going to be notified that there is even an update available,&#8221; he said.</p>
<p>If you want to learn more about what it takes to maintain a popular plugin while successfully navigating the years of changes and support, check out WebDevStudios&#8217; <a href="http://webdevstudios.com/2015/07/17/the-custom-post-type-ui-million-download-celebration/" target="_blank">1 million downloads celebration post</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 01:35:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: WordPress 4.3 Moves Customize to Its Own Top-level Menu in the Admin Bar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46979";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wptavern.com/wordpress-4-3-moves-customize-to-its-own-top-level-menu-in-the-admin-bar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3156:"<p>When menu management was <a href="http://wptavern.com/menu-customizer-officially-proposed-for-merge-into-wordpress-4-3">proposed to be merged into WordPress 4.3</a>, a common complaint <a href="http://wptavern.com/menu-customizer-officially-proposed-for-merge-into-wordpress-4-3#comment-68988">expressed by readers</a> was that clicking the Widgets menu item in the admin bar loads the customizer instead of the Widgets admin screen. WordPress 4.3 separates the management interfaces by moving the Customize link to the top-level menu of the admin bar. This link opens the customizer, allowing you to manage menus, appearance, and widgets through the customizer interface.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP42AdminBar.png"><img class="wp-image-46995 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP42AdminBar.png?resize=429%2C232" alt="WordPress 4.2 Admin Bar" /></a>WordPress 4.2 Admin Bar
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP43AdminBar.png"><img class="wp-image-46996 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP43AdminBar.png?resize=428%2C202" alt="WP43AdminBar" /></a>WordPress 4.3 Admin Bar
<p>The Dashboard, Themes, Widgets, and Menus links take users to their corresponding admin pages in the backend of WordPress. This makes it clear which interface users are about to enter. The enhancement is a result of <a href="https://core.trac.wordpress.org/ticket/32678">ticket #32678</a> where Helen Hou-Sandí and other WordPress core contributors discussed ways to improve the context of each link over the course of five weeks.</p>
<p>Within the ticket, Nick Halsey, who has spent a lot of time on the customizer, explains that the approach taken in the ticket addresses short-term problems while setting the stage for future improvements.</p>
<blockquote><p>The Customizer gets the visibility it deserves and becomes more conceptually separated from &#8216;Appearance&#8217;, the admin becomes significantly more accessible from the front-end, the often-unhelpful dashboard is de-emphasized, etc. We also have the ability to easily upgrade the Customize link to do a much faster/shinier loading of the Customizer in the future without moving it.</p>
<p>Notably, the add-content and edit-content links remain separated from the admin menu (and we skip submenus there for simplicity), setting us up to be able to point them to a front-end-contextual content-creating/editing experience if we build that in the future, without moving links around. This minor rearrangement should be able to last several years without things moving around much if at all, even as further adjustments are made to the features they point to.</p></blockquote>
<p>On the surface, it appears to be a simple change but a lot of time and effort went into it. It required several core contributors to discuss a variety of mockups, ideas, and flows before the team figured out a solution.</p>
<p>Separating how users enter each interface will be a welcome enhancement to anyone who prefers one over the other to manage themes, widgets, and menus.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jul 2015 23:28:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: How and When Mullenweg Learned Thesis Changed Back to a Proprietary License";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46960";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://wptavern.com/how-and-when-mullenweg-learned-thesis-changed-back-to-a-proprietary-license";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5837:"<p>We now know when Matt Mullenweg discovered Chris Pearson changed Thesis&#8217; license from split GPL to a proprietary one. On April 1st 2014, Siobhan McKeown <a href="http://archive.wordpress.org/interviews/2014_04_01_Mullenweg.html">interviewed Matt Mullenweg</a> for the <a href="https://github.com/WordPress/book">WordPress history book</a>.</p>
<p>In the interview, we learn about the history of WordPress themes, the GPL, how Automattic unintentionally created the commercial theme market, why 200 themes were removed from the directory for sponsored links and much more.</p>
<p>At the 30 minute mark, McKeown asks Mullenweg, at what point did he decide to go to the Software Freedom Law Center to receive clarification on if the default themes that ship with WordPress are derivatives? He responds:</p>
<blockquote><p>I believe that was around our engagement with Mr. Pearson. I don&#8217;t know if it was before or after the Mixergy interview with our spirited online debate, but it was definitely around that time. I&#8217;m not a lawyer! I can read it and I can understand it from a logical point of view, but the Software Freedom Law Center is obviously the world experts in this and having them officially opine is the closest we can get to &#8211; it&#8217;s the next best thing to having a court case.</p>
<p>I was actually very excited that perhaps Chris would actually go to court, because as you know there isn&#8217;t a ton of case law around the GPL and normally, because no one is stubborn enough to actually go to court over it, and I thought, &#8220;Oh, we finally got one!&#8221; And I was looking forward to being able to discuss in the U.S. law system and provide the precedent for anyone who comes after us to protect the GPL.</p>
<p>Because companies like Cisco and LinkSys and huge companies with billions of dollars in resources have opted to not fight it, so you really do need someone who is going to be stubborn enough to fight it.</p></blockquote>
<p>At the climax of the debate in 2010, <a href="http://ma.tt/2010/07/syn-thesis-1/#comment-481743">some members</a> of the WordPress community wanted to see the argument go to court so a ruling could set a precedent on when a work becomes derivative.</p>
<p>At the 33 minute mark, McKeown informs Mullenweg that Thesis switched from a split GPL license to a proprietary license. This is the first time since his debate with Pearson in 2010, that Mullenweg discovers Thesis switched back to a proprietary license. He responds:</p>
<blockquote><p>I have not seen that. So we&#8217;d have to do a code analysis again. As you know the Software Freedom Law Center says that non-PHP, so non-linked code which can be CSS, images and JavaScript, isn&#8217;t required to be GPL. It doesn&#8217;t trigger the viral nature of WordPress&#8217; GPL code.</p>
<p>The stance of the WordPress community was that a theme without images or CSS isn&#8217;t much of a theme so, even though something could be legally compliant, if the entire package isn&#8217;t providing the same freedoms for users it&#8217;s not something that we want to link to or promote. Because it doesn&#8217;t really follow the things that we hold dear and true in WordPress.</p></blockquote>
<p>On January 15, 2014, <a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php">Chris Pearson received</a> a copy of Mullenweg&#8217;s inquiry into thesis.com from Larry of GetYourDomain.com. This is approximately four months prior to discovering Thesis was being sold under a proprietary license. However, the exact date in which Mullenweg obtained ownership of the domain is unknown.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-matt.png"><img class="size-full wp-image-46845" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-matt.png?resize=486%2C191" alt="Email shared by Pearson showing Mullenweg\'s interest in the domain" /></a>Email shared by Pearson showing Mullenweg&#8217;s interest in the domain
<p>The first <a href="http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks">publicly known use of the domain</a> that confirmed Mullenweg&#8217;s ownership was on October 26th, 2014, at WordCamp San Francisco during the Question and Answer session.</p>
<p>As the interview continues, McKeown asks Mullenweg if he reached out to companies like Template Monster that sells WordPress themes that are not GPL Licensed. He responds:</p>
<blockquote><p>We got in touch with everyone that we could, and it was definitely &#8211; it was a lot of time. There are times when WordPress core stuff is more than a full-time job for me and now is definitely one of them.</p>
<p>I see your link to a [inaudible]. There&#8217;s always ways to word licenses around multi-site support where perhaps the code is GPL but the developer chooses to not provide support for more than one site unless you buy a special license. So sometimes people interpret those to be a GPL violation when actually they&#8217;re not.</p>
<p>I&#8217;m not aware of what Chris has done and I&#8217;d like to think that he is supportive &#8211; he has done so well from the WordPress community that he&#8217;d be supportive of themes continuing to be GPL, especially since his business didn&#8217;t crash like he was worried it would.</p></blockquote>
<p>McKeown jokes that lawyers might have written Thesis&#8217; license agreement. Mullenweg responds, &#8220;Well, maybe we&#8217;ll dive back into it.&#8221; More than 14 months later, <a href="http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks">Mullenweg has dived back into it with Pearson</a>.</p>
<p>It&#8217;s unclear if in this second round of arguments, Mullenweg will take Pearson to court to settle the GPL derivative argument once and for all.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jul 2015 23:21:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:92:"WPTavern: Create and Manage BuddyPress Member Types with the BP Member Type Generator Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46893";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"http://wptavern.com/create-and-manage-buddypress-member-types-with-the-bp-member-type-generator-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4810:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/different-users.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/different-users.jpg?resize=1024%2C492" alt="photo credit: Dunechaser - cc" class="size-full wp-image-30565" /></a>photo credit: <a href="https://www.flickr.com/photos/dunechaser/6042984689/">Dunechaser</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p><a href="http://wptavern.com/buddypress-2-2-spumoni-released-featuring-new-member-type-api" target="_blank">BuddyPress 2.2</a> introduced a <a href="https://codex.buddypress.org/developer/member-types/" target="_blank">Member Type API</a>, which allows developers to register their own unique member types, i.e. teacher, student, coach, etc. This was an exciting addition to BuddyPress but not very accessible to non-technical community managers, since it requires writing your own plugin to utilize it.</p>
<p><a href="https://wordpress.org/plugins/bp-member-type-generator/" target="_blank">BP Member Type Generator</a> is a new plugin from Brajesh Singh, prolific plugin author and owner of <a href="http://buddydev.com/" target="_blank">BuddyDev</a>. The plugin makes it easy for site administrators to create and manage member types in the admin &#8211; without having to write any code.</p>
<p>A quick overview of its features includes:</p>
<ul>
<li>Create/Edit/Delete Member Types from WordPress admin</li>
<li>Bulk assign member type to users from the users list screen</li>
<li>A member type can be marked active/inactive from the edit member type page</li>
<li>Compatible with multisite installations</li>
</ul>
<p>When creating a new member type, administrators have the option to enable a directory that will list all members from that type on one page.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/create-member-type.png"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/create-member-type.png?resize=968%2C725" alt="create-member-type" class="aligncenter size-full wp-image-46984" /></a></p>
<p>If you want to add the plugin and separate your members into different types, the task is not as overwhelming as it might sound. When you visit the user listing page in the admin, you can use the plugin&#8217;s bulk &#8220;change member type&#8221; dropdown to bulk assign users to a new member type. (This feature is also available in the Extended Profile section for each individual user in the admin.)</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/change-member-type.png"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/change-member-type.png?resize=737%2C440" alt="change-member-type" class="aligncenter size-full wp-image-46988" /></a></p>
<p>If you want to make the member types available for selection upon user registration, Singh created a free companion plugin called <a href="http://buddydev.com/buddypress/using-buddypress-member-type-as-profile-field-introducing-bp-xprofile-member-type-field-plugin/" target="_blank">BP Xprofile Member Type Field</a> that puts this on the frontend. If you want to restrict members from modifying their user type after registration, you can also add the free <a href="http://buddydev.com/plugins/bp-non-editable-profile-fields/" target="_blank">Non Editable Profile</a> field plugin.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/registration-member-type-field.png"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/registration-member-type-field.png?resize=490%2C337" alt="registration-member-type-field" class="aligncenter size-full wp-image-46992" /></a></p>
<p>Please note that BP Member Type Generator cannot detect and manage other member types that have previously been added via code in a plugin. This might create some confusion if you already have existing member types. However, if you&#8217;re just starting with setting up and organizing member types, or are willing to reorganize member types, the BP Member Type Generator offers an easy way to do it.</p>
<p>This plugin is an important and much needed new tool that puts the creation of unique member types into the hands of BuddyPress community administrators, regardless of skill level. You can download <a href="https://wordpress.org/plugins/bp-member-type-generator/" target="_blank">BP Member Type Generator</a> for free from WordPress.org. Singh does not officially support his plugins via the WordPress forums, but users can provide feedback via the <a href="http://buddydev.com/buddypress/introducing-buddypress-member-type-generator/" target="_blank">BuddyDev blog</a> or get professional support on the <a href="http://buddydev.com/support/forums/" target="_blank">BuddyDev Premium Support Forums</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jul 2015 21:51:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Joseph: Recommended Consultants";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://josephscott.org/?p=9888";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"https://josephscott.org/archives/2015/07/recommended-consultants/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:277:"<p>My personal list of WordPress consultants has dried up ( some took full time jobs, the rest are always booked solid ).  Now I&#8217;m directing people to the <a href="http://jkudish.com/recommendations/">Recommended Consultants &amp; Resources list</a> from Joey Kudish.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jul 2015 14:01:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Joseph Scott";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: Nick Haskins Receives Cease and Desist Letter for Violating LassoSoft Trademarks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46768";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"http://wptavern.com/nick-haskins-receives-cease-and-desist-letter-for-violating-lassosoft-trademarks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4619:"<p><a href="http://nickhaskins.com/">Nick Haskins</a>, the founder and lead developer of <a href="https://lasso.is/">Lasso</a>, is <a href="https://lasso.is/the-ugly-truth-about-trademarks/">rebranding the product</a> after being served a cease and desist letter.</p>
<p>A few days ago, Haskins was served a cease and desist letter from <a href="http://lassosoft.com/">LassoSoft</a>. According <a href="http://www.lassosoft.com/What-Is-Lasso">to LassoSoft</a>, &#8220;Lasso is a development platform and is the easiest, quickest and most secure method of supporting custom, data-driven web sites on the market today.&#8221;</p>
<p>Before launching a product, Haskins searches Google to see if similar products exist with the same name, &#8220;Apparently we didn’t look hard enough when naming Lasso,&#8221; he said.</p>
<h2>Three Requirements That Must Be Met</h2>
<p>Haskins <a href="http://cl.ly/39400J3A100k">shared the letter</a> to educate others in the business of WordPress. In the letter, attorney&#8217;s for LassoSoft point out the company&#8217;s <a href="http://www.tmfile.com/mark/?q=861046116">registered trademarks</a> and says it commenced using the mark in the US in 1998 and in Canada in 1997.</p>
<p>LassoSoft claims to have documented at least one case of confusion between the two brands and says the continued use of Lasso will cause even more confusion.</p>
<p>Attorney&#8217;s for LassoSoft provided three requirements that must be met for an amicable end to the dispute:</p>
<ol>
<li>Permanently ceasing all use of the term &#8220;Lasso&#8221; and any trademark which includes or incorporates the term &#8220;Lasso&#8221;, in connection with any software or related goods and services.</li>
<li>Removing all references to the term &#8220;Lasso&#8221; from the Website.</li>
<li>Removing all references to the term &#8220;Lasso&#8221; from any marketing materials including flyers, catalogs, etc.</li>
</ol>
<p>Haskins has until <strong>July 29th</strong> to satisfy the requirements and provide LassoSoft with written confirmation that he has permanently ceased all use of the term &#8220;Lasso&#8221; in association with software.</p>
<h2>Transitioning Momentum</h2>
<p>Rebranding a product that has momentum can be a crushing blow to a business that doesn&#8217;t manage the transition correctly. I asked Haskins how he plans to shift momentum from Lasso to the new brand name.</p>
<p>&#8220;The first idea I had, was to let the community rename it, possibly even have a $500 prize to the winning name. By incentivizing a rebranding campaign, together with a concentrated effort on re-educating, along with URL redirects and custom messages, I feel pretty strongly that we&#8217;ll be able to move right along without skipping a beat,&#8221; he said.</p>
<p>When it comes to naming a WordPress product and launching it into the WordPress ecosystem, Haskins offers the following advice:</p>
<p>&#8220;Use Google to see if it already exists either in the WordPress ecosystem or in a related field. This may seem like a no-brainer and it&#8217;s really common sense, but for some reason, I either never searched or that company never popped up. At any rate, I think you&#8217;ll be in good shape by sticking to something with wp prefixed or appended to the name.&#8221;</p>
<p>&#8220;Avoid generic terms and verbs because apparently, you can trademark a verb. I&#8217;d also run the search again in six months and if it&#8217;s a product that you plan on working on for a while, go through the process of getting the term trademarked.&#8221;</p>
<p>In addition to Haskins&#8217; advice, I recommend using a search and discovery process provided by legal counsel familiar with trademark law.</p>
<h2>Help Haskins Rebrand Lasso</h2>
<p>In light of the battle between <a href="http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks">Chris Pearson and Matt Mullenweg</a> involving patents, GPL, and trademarks, Haskins decided to rebrand Lasso, &#8220;There are a lot more important things in life than the name of a plugin for WordPress,&#8221; he said.</p>
<p>Haskins is giving the community an opportunity to rebrand his product. So far, he&#8217;s ruled out WP Front End Editor as it&#8217;s too similar to the <a href="https://wordpress.org/plugins/wp-front-end-editor/">name of a feature plugin</a> that may one day be merged into WordPress core.</p>
<p>If you have an idea on what to call Lasso, please leave a comment on this post. Sometime next week, Haskins will gather the suggestions and publish a poll where the community can vote on which one is best.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jul 2015 01:08:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"Matt: There is No Such Thing as a Split License";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45256";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://ma.tt/2015/07/licenses-going-dutch/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2845:"<p>There&#8217;s a term that pops in the WordPress community, &#8220;split license&#8221;, that we should put to rest. It&#8217;s sloppy at best, misleading at worst.</p>
<p>First, some background. WordPress is under a license called the GPL, which basically says you can do whatever you like with the software, but if you distribute changes or create derivative works they also need to be under the GPL. Think of it like a Creative Commons Sharealike license.</p>
<p>In the past people weren&#8217;t sure if themes for WordPress were derivative works and needed to be GPL. <a href="https://wordpress.org/news/2009/07/themes-are-gpl-too/">In 2009 we got an outside legal opinion that cleared up the matter</a> saying that the PHP in themes definitely had to be GPL, and for CSS and images it was optional. Basically everyone in the WP community went fully GPL, sometimes called 100% GPL, for all the files required to run their theme (PHP, JS, CSS, artwork). The predicted theme apocalypse and death of WordPress didn&#8217;t happen and in fact both theme shops and WordPress flourished, and best of all users had all the same freedoms from their themes as they got from WordPress. It was controversial at the time, but I think history has reflected well on the approach the WP community took.</p>
<p>As I said the PHP has to be GPL, the other stuff can be something else &#8212; many people started to use the term &#8220;split license&#8221; or &#8220;split GPL&#8221; to describe this. The problem, especially with the latter, is it leaves out the most important information. &#8220;Split GPL&#8221; doesn&#8217;t say whether the theme is violating WordPress&#8217; license or not (maybe it&#8217;s proprietary PHP and GPL CSS), and more importantly doesn&#8217;t say what the non-GPL stuff is, which is the part you need to worry about! It also makes it sound like a split license is a thing, when all it really means is there are different licenses for different parts of the work. If something has a &#8220;split license&#8221; you have no idea what restrictions or freedoms it provides.</p>
<p>If someone decides to have different licenses for different parts of a theme they ship in one package, it&#8217;s probably worth taking a few extra words to spell out what the rights and restrictions are, like &#8220;GPL PHP, and a restrictive proprietary license for all other elements included with the theme.&#8221; This is really important because if you&#8217;re a smart WordPress consumer you should avoid proprietary software, there is always a GPL alternative that <a href="http://www.gnu.org/philosophy/free-sw.en.html">gives you the rights and freedoms you deserve</a>, and probably is from a nicer person who is more in line with the philosophy of the rest of WordPress. Vote with your pocketbook, buy GPL software!</p>
<p>&nbsp;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Jul 2015 20:55:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:94:"WPTavern: Shortcake Bakery Plugin Offers a Suite of Useful Shortcodes for WordPress Publishers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46896";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://wptavern.com/shortcake-bakery-plugin-offers-a-suite-of-useful-shortcodes-for-wordpress-publishers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4116:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/baker.jpg"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/baker.jpg?resize=1024%2C516" alt="photo credit: Panettiere - (license)" class="size-full wp-image-46899" /></a>photo credit: <a href="http://www.flickr.com/photos/27505428@N06/16282512996">Panettiere</a> &#8211; <a href="https://creativecommons.org/licenses/by-sa/2.0/">(license)</a>
<p>In March, the <a href="http://wptavern.com/shortcake-is-now-a-wordpress-feature-plugin" target="_blank">Shortcake project officially began its journey as a feature plugin</a> with regular meetings for contributors working to make it ready to propose for inclusion in WordPress core. The <a href="https://wordpress.org/plugins/shortcode-ui/" target="_blank">plugin</a> provides a friendly UI for adding shortcodes and transforms them to render a nice preview in the visual editor.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/pullquote-shortcode.png"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/pullquote-shortcode.png?resize=1025%2C538" alt="pullquote-shortcode" class="aligncenter size-full wp-image-46904" /></a></p>
<p>Last week, <a href="https://twitter.com/danielbachhuber" target="_blank">Daniel Bachhuber</a> and the engineering team at <a href="http://fusion.net/" target="_blank">Fusion</a> released <a href="https://wordpress.org/plugins/shortcake-bakery/" target="_blank">Shortcake Bakery</a>, a plugin that extends the Shortcake project to supply a suite of handy shortcodes for publishers. The plugin currently includes the following:</p>
<ul>
<li>Image Comparison (powered by <a href="https://juxtapose.knightlab.com/" target="_blank">JuxtaposeJS</a>)</li>
<li>Facebook embeds</li>
<li>iFrames (require whitelisted hostnames)</li>
<li>Infogram embeds</li>
<li>PDF’s (powered by <a href="https://mozilla.github.io/pdf.js/" target="_blank">PDF.js</a>)</li>
<li>Playbuzz embeds</li>
<li>Rap Genius annotations</li>
<li>Scribd embeds</li>
<li>Scripts (require whitelisted hostnames)</li>
</ul>
<p>&#8220;We’ve been steadily making shortcodes for use by the Fusion newsroom since we launched Shortcake in November, and by releasing these universally useful patterns to the world, we hope to create a large repository of structured post elements for use by the WordPress community,&#8221; Bachhuber said.</p>
<p>For example, Shortcake Bakery supplies a friendly UI for embedding an infographic from <a href="https://infogr.am/" target="_blank">Infogra.am</a>. The author selects the post element and then pastes in the URL to the infographic. It instantly appears in the post editor with a TinyMCE preview.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2015/07/shortcake-bakery-demo.mp4">http://wptavern.com/wp-content/uploads/2015/07/shortcake-bakery-demo.mp4</a></p>
<p>Shortcake Bakery also makes it easy to embed a single Facebook post, PDF, image comparison, and other content types that might otherwise prove troublesome to include in WordPress. Each content type is optimized for instant visual preview in the editor.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/shortcake-bakery-facebook-embed.png"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/shortcake-bakery-facebook-embed.png?resize=919%2C689" alt="shortcake-bakery-facebook-embed" class="aligncenter size-full wp-image-46917" /></a></p>
<p>Version 0.1.0 includes nine useful post elements that make it easy to embed content from external services commonly referenced by publishers. Shortcodes for Instagram, Tubmlr, and Silk are listed as possible upcoming enhancements on the project&#8217;s <a href="https://github.com/fusioneng/shortcake-bakery/labels/enhancement" target="_blank">GitHub issues queue</a>. <a href="https://wordpress.org/plugins/shortcake-bakery/" target="_blank">Shortcake Bakery</a> is an open source plugin and is now available on WordPress.org. It works best when combined with the <a href="https://wordpress.org/plugins/shortcode-ui/" target="_blank">Shortcake</a> plugin.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Jul 2015 02:16:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: WP Rocket Reports $355K in Annual Revenue After 2 Years in Business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46719";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wptavern.com/wp-rocket-reports-355k-in-annual-revenue-after-2-years-in-business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4872:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-rocket-feature.jpg"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-rocket-feature.jpg?resize=1025%2C452" alt="wp-rocket-feature" class="aligncenter size-full wp-image-22199" /></a></p>
<p><a href="http://wp-rocket.me/" target="_blank">WP Rocket</a> is celebrating its second year in business. The commercial caching plugin for WordPress launched two years ago in the French market and <a href="http://blog.wp-rocket.me/2-years-reports-feedbacks/" target="_blank">opened its doors to international customers</a> last May.</p>
<p>At that time, WP Rocket was entering unproven territory as the first major caching plugin to launch with a 100% commercial model. Could the plugin succeed in a market dominated by free caching solutions like <a href="https://wordpress.org/plugins/w3-total-cache/" target="_blank">W3 Total Cache</a> and <a href="https://wordpress.org/plugins/wp-super-cache/" target="_blank">WP Super Cache</a>?</p>
<p>WP Rocket has the numbers to prove that WordPress users are willing to pay for an easy-to-configure solution to site optimization. In February, the 100% bootstrapped company published a transparency report showing that the product was now active on 15,000+ websites and <a href="http://wptavern.com/wp-rocket-grows-from-0-to-35k-in-monthly-revenue" target="_blank">averaging $35K in monthly revenue</a>. Six months later, the plugin is now active on more than 32,000 websites. From July 2014 &#8211; July 2015, WP Rocket <a href="http://blog.wp-rocket.me/2-years-reports-feedbacks/" target="_blank">reports</a> that the company pulled in a total of $351,097 in revenue.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/wprocket-2014-2015.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/wprocket-2014-2015.jpg?resize=629%2C525" alt="photo credit: WP Rocket</a." /></a>photo credit: <a href="http://blog.wp-rocket.me/2-years-reports-feedbacks/">WP Rocket</a>
<p>WP Rocket has been successful in identifying ways to stand out among established competitors. During our <a href="http://wptavern.com/wp-rocket-launches-commercial-caching-plugin-for-wordpress" target="_blank">initial tests of the plugin</a>, we found that it took under a minute to configure caching for a small blogging site using its simple, basic settings panel. Without even touching the more advanced options, such as DNS prefetching and file exclusions, we were able to reduce the page size and load time by roughly 50%.</p>
<p>Inspired by a recent three-month stay in San Francisco, WP Rocket developers and co-founders  Jonathan Buttigieg and Jean-Baptiste Marchand-Arvier are now working to diversify their product offerings.</p>
<p>&#8220;WP Rocket will be one product among others from our startup and not the only one,&#8221; Marchand-Arvier said. &#8220;We want to have a portfolio of products and not depend on only one.&#8221;</p>
<p>To that end, the company is dipping its toes into multiple potentially welcoming revenue streams, including plugins, themes, and SaaS.</p>
<p>&#8220;For the past few months, Julio has been working on a security plugin,&#8221; Marchand-Arvier said. &#8220;This is going to be a great challenge for us as we experiment with a freemium model for the first time, and because there are great competitors in the space, like WordFence and iThemes Security.</p>
<p>WP Rocket currently has a dedicated team working on <a href="https://imagify.io/" target="_blank">Imagify</a>, an image compression toolkit and their first SaaS venture. The company also plans to enter the theme market with its own shop.</p>
<p>&#8220;We want to take on that huge challenge which will be very different compared to selling a plugin,&#8221; Marchand-Arvier said.</p>
<p>WP Rocket&#8217;s founders believe that building a strong company culture will be one of the key factors to their continued success.</p>
<p>&#8220;To work in a mostly remote team can create a lack of human connection,&#8221; Marchand-Arvier said. &#8220;That’s why we’ve decided to organize a ‘startup retreat’ every year.&#8221; This decision was inspired by the founders&#8217; 2014 trip to explore Silicon Valley, a pivotal event that changed the way they approached business in the WordPress ecosystem.</p>
<p>&#8220;This [trip] transformed three guys who were selling a WordPress plugin into a Startup of eight people (today) with a strong company culture,&#8221; he said.</p>
<p>If the success of WP Rocket&#8217;s caching plugin is any indication, WordPress users should be on the lookout for the company to bring a new twist into other existing product niches. Momentum is running high on their currently incubating projects with <a href="https://imagify.io/" target="_blank">Imagify</a> on track to launch in the upcoming weeks.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 20 Jul 2015 20:33:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Matt: Streak Broken";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45251";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:35:"http://ma.tt/2015/07/streak-broken/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:689:"<p>Due to some distractions and mishandling of scheduled posts on my part, I broke my blogging streak. I got up to 198 days, which isn&#8217;t bad, and I&#8217;m looking forward to beating it next time. A lot of people might not know this, but if you&#8217;re on <a href="http://wordpress.com/">WordPress.com</a> or run <a href="http://jetpack.me/">Jetpack</a> when you start a posting streak it will give you a notification high-five every day you continue it, this was the last one I got:</p>
<p><img class="aligncenter  wp-image-45252" src="http://i2.wp.com/ma.tt/files/2015/07/Screen-Shot-2015-07-18-at-9.06.19-AM.png?resize=386%2C394" alt="Screen Shot 2015-07-18 at 9.06.19 AM" /></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 18 Jul 2015 13:08:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: Mullenweg and Pearson Square Off on Patents, GPL, and Trademarks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46814";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8449:"<p>In a post titled &#8220;<a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php" target="_blank">The Truth About Thesis.com</a>,&#8221; Chris Pearson responded to the recent heated discussions about his <a href="http://wptavern.com/automattic-wins-cybersquatting-case-against-chris-pearson" target="_blank">legal battle with Automattic over the Thesis.com domain</a> and related trademarks. His public response revives a <a href="http://wordpress.tv/2010/07/15/mixergy-interview-pearson-mullenweg/">five-year old licensing disagreement</a>.</p>
<p>&#8220;I think the most important place to start is by asking: Why would Automattic—a website software company with over $300 million in funding—buy thesis.com when I owned the trademark for Thesis in the website software space?&#8221; Pearson asked.</p>
<p>In February 2013, Pearson started negotiations with a domain broker named Larry of GetYourDomain.com in an attempt to purchase thesis.com. He opened with an offer of $37,500 which he considered to be more than enough for an unused domain. After months of negotiating, the deal fell through.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-matt.png"><img class="size-full wp-image-46845" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-matt.png?resize=486%2C191" alt="Email shared by Pearson showing Mullenweg\'s interest in the domain" /></a>Email shared by Pearson showing Mullenweg&#8217;s interest in the domain
<p>&#8220;I didn’t see how Matt could justify buying the domain for $100,000. Because of my trademark, there was no way he could legally use the domain for Automattic, and therefore, I didn’t believe there was a reason for him to spend that much money,&#8221; Pearson said.</p>
<p>Nine months after negotiations failed, Pearson received an email from Larry asking if he&#8217;d like to renegotiate since Mullenweg showed interest in the domain. Further negotiations went nowhere and Mullenweg won the domain for $100K.</p>
<p>News of Mullenweg&#8217;s purchase didn&#8217;t reach the public until he replied to a question about WordPress&#8217; relationship with commercial theme providers at the 2014 State of the Word Q&amp;A. In his response, he encouraged the audience to visit Thesis.com. Notice Mullenweg&#8217;s delivery and how the crowd reacts to his announcement.</p>
<p></p>
<p></p>
<p>Pearson also accused Mullenweg of <a href="http://tsdr.uspto.gov/#caseNumber=4039583&caseType=US_REGISTRATION_NO&searchType=statusSearch">violating his trademark</a>.</p>
<blockquote><p>Principles? Matt spent $100,000 to buy thesis.com—a domain in which he had no legitimate business interest—forwarded the domain to his property, and violated my trademark.</p>
<p>This is ironic considering how vigilant Matt has been about protecting the WordPress trademark—especially as it <a href="http://wptavern.com/the-wordpress-foundation-sues-jeff-yablon-for-trademark-infringement">relates to domain names</a>.</p></blockquote>
<p>Pearson goes on to describe his duty to protect to his trademark and the details of the UDRP Case Ruling, as well as the fallout regarding the court&#8217;s decision in Automattic&#8217;s favor.</p>
<p>&#8220;It’s time for the community to ask itself if using $300 million in funding to purchase $100,000 domains, fund aggressive lawsuits, and fuel unending drama is properly representative of the WordPress project,&#8221; he said.</p>
<p>Pearson admitted to &#8220;being a jerk&#8221; both in the post and the comments. This admission is based on his attitude and the way he presented himself in 2010 in the <a href="http://wordpress.tv/2010/07/15/mixergy-interview-pearson-mullenweg/">interview with Andrew Warner</a> on Mixergy. Mullenweg focused on the fact that Pearson changed the licensing structure of Thesis so that part of it is incompatible with the GPL:</p>
<p>&#8220;So why do the exact same thing you did before, change your license to violate the GPL and take rights away from your users? And then litigate against someone else?&#8221; Mullenweg asked.</p>
<p>He is referring to Thesis&#8217; <a href="http://diythemes.com/thesis/rtfm/software-license-agreement/">license agreement</a> customers agree to when they purchase the theme. The agreement has terms that take user freedoms away that GPL licensed software provides. Here are a few of terms in the agreement:</p>
<ul>
<li>You can’t sell, rent, or otherwise transfer the software to anyone else.</li>
<li>The license provides you, and only you, with the rights to use the software for its intended purpose.</li>
<li>Other than for educational purposes, any modification of the Thesis “core” is prohibited.</li>
</ul>
<p>Mullenweg is well known as a zealous protector of the GPL and users&#8217; rights. However, Pearson and many others perceived his comments on licensing to be a distraction from the main issue.</p>
<p>In responding to commenters on whether the issue is dead, he <a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507944" target="_blank">said</a>:</p>
<blockquote><p>The issue isn’t dead — Chris went back on his word and re-changed his license to be 100% proprietary and violate the GPL, sneakily sometime in the past 5 years since the last time he did that. He also patented how themes work, and color pickers.</p></blockquote>
<p>The patent Mullenweg is <a href="http://www.google.com/patents/US20140095982">referring to</a> was published in September of 2012. The patent describes systems, servers, and methods for managing websites using the Thesis software. One of the fears is that the patent is vague and closely describes how WordPress themes work in general, although Pearson claims the patent has <a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507962">nothing to do with WordPress</a>.</p>
<p>Pearson <a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507962" target="_blank">clarified Thesis&#8217; new proprietary licensing</a>, which Mullenweg believes to be in violation of their agreement in 2010:</p>
<blockquote><p>In October 2012, I released an all-new version of Thesis that carried the same name as the original (which had a split-GPL license), but that’s where the similarities stopped.</p>
<p>The new Thesis is not a Theme—it is an operating system for templates and design. This system runs Skins and Boxes, which are similar to Themes and Plugins, but with a boatload of built-in efficiencies that Themes and Plugins cannot provide.</p>
<p>Skins and Boxes carry MIT licenses, which are not only open source, but also easy for anyone to understand and use.</p>
<p>There is nothing sneaky about the licensing structure that has been in place since October 2012. DIYthemes customers must agree to the proprietary licensing on the Thesis core before downloading and using the software.</p></blockquote>
<p>After Mullenweg purchased the domain, he <a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507947">received no personal communication from Pearson</a> on the issue until Automattic was hit with litigation. The litigation stems from Pearson trying to protect his trademark.</p>
<p>&#8220;I don’t know the last time I got an email from Chris directly (3+ years?), and myself and Automattic didn’t hear anything from him before we got the litigation notice he was trying to seize the domain,&#8221; Mullenweg commented. &#8220;No questions, no concerns, no offer to resolve, no discussion, we were just hit with legal action out of the blue.&#8221;</p>
<p>In a <a href="http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507959">comment published</a> on Pearson&#8217;s blog post, Mullenweg contends that Pearson is repeating the same mistake he made in 2010 by not licensing Thesis as GPL.</p>
<p>&#8220;It doesn’t matter if you admit what you did was wrong in the past if you go and do the exact same thing again: violate the GPL, and make it worse by patenting common theme practices,&#8221; he said.</p>
<p>Up until this point, Mullenweg has declined to comment directly on Automattic&#8217;s interest in purchasing thesis.com in the first place. There are a lot of forces at play, including patents, GPL adherence, trademarks, and domain names. This is a developing and complicated story that we&#8217;ll continue to keep our eyes on.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 18 Jul 2015 05:24:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: New Feature Plugin Proposed: oEmbed for WordPress Posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46826";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wptavern.com/new-feature-plugin-proposed-oembed-for-wordpress-posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2809:"<p>WordPress has a <a href="https://codex.wordpress.org/Embeds" target="_blank">whitelist</a> of 31 trusted sites from which users can oEmbed content, but one source is noticeably missing &#8211; WordPress itself. During this week&#8217;s <a href="https://make.wordpress.org/core/2015/07/10/feature-plugin-chat-on-july-14/" target="_blank">feature plugin chat</a>, Pascal Birchler and a group of contributors proposed the idea of <a href="https://make.wordpress.org/core/2015/07/10/feature-plugin-chat-on-july-14/#comment-26324" target="_blank">oEmbed for WordPress Posts</a>:</p>
<blockquote><p>Basically, we want to make WordPress an oEmbed provider. Users should be able to paste an URL from a WordPress blog and the post gets embedded right away. Difficulties here are discovering other WordPress sites as oEmbed providers and whitelisting them. The oEmbed endpoint requires the WP-API to be in use, so this can’t land in core until the API does.</p></blockquote>
<p>The <a href="https://github.com/swissspidy/oEmbed-API" target="_blank">oEmbed API</a> proof-of-concept feature plugin is currently in development on GitHub. It requires WordPress 4.3 beta 3 or later and version 2 of the <a href="https://github.com/WP-API/WP-API" target="_blank">WP REST API</a> plugin.</p>
<p>Mel Choyce, author of the trac <a href="https://core.trac.wordpress.org/ticket/32522" target="_blank">ticket</a> requesting the feature, created a mockup of how embedded WordPress posts might look:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wordpress-oembed-feature-plugin-mockup.jpg"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wordpress-oembed-feature-plugin-mockup.jpg?resize=1024%2C960" alt="wordpress-oembed-feature-plugin-mockup" class="aligncenter size-full wp-image-46828" /></a></p>
<p>The <a href="https://core.trac.wordpress.org/ticket/32522" target="_blank">ticket</a> is home to an active discussion with excellent reasons on both sides of the argument for why this should or should not be included in core, highlighting the many <a href="https://core.trac.wordpress.org/ticket/32522#comment:32" target="_blank">considerations</a> that would be involved with having oEmbed discovery turned on. Tackling <a href="https://core.trac.wordpress.org/ticket/32522#comment:34" target="_blank">abuse of the feature</a> could also pose a significant challenge.</p>
<p>The feature plugin is still in the early development stages and discussion regarding its implementation is ongoing. Birchler said the team needs help with design and development, particularly with the oEmbed auto-discovery part of the project. If you&#8217;d like to get involved with the discussion, you can join in the weekly chats in the <strong>#feature-oembed</strong> WordPress Slack channel.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Jul 2015 22:51:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WPTavern: New Roots Radio Podcast Discusses WordPress and Modern Web Development Topics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46679";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wptavern.com/new-roots-radio-podcast-discusses-wordpress-and-modern-web-development-topics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3530:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/roots.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/roots.jpg?resize=700%2C300" alt="roots" class="aligncenter size-full wp-image-46801" /></a></p>
<p>Ben Word and the team behind <a href="https://roots.io/" target="_blank">Roots</a> are launching a new WordPress-related podcast called <a href="https://roots.io/radio0/" target="_blank">Roots Radio</a>. Earlier this year, Word <a href="http://wptavern.com/roots-wordpress-starter-theme-rebrands-as-sage-with-8-0-release" target="_blank">rebranded the Roots starter theme as “Sage”</a> under the Roots organization as part of <a href="http://wptavern.com/roots-starter-theme-for-wordpress-will-become-framework-agnostic-in-2015" target="_blank">a long-term plan to make it framework-agnostic</a>. Opening up the starter theme to be available for use with a variety of frontend frameworks means that the Roots community is utilizing a wide range of technologies for development.</p>
<p>The new podcast was created to discuss WordPress and Roots development and will also explore general modern web development topics. The <a href="https://roots.io/radio0/" target="_blank">inaugural episode</a> introduces Roots team members, many of whom use WordPress and others who are more active outside of WordPress development. They also discuss their individual WordPress workflows, dependency management, and project structure.</p>
<blockquote class="twitter-tweet" width="550"><p lang="en" dir="ltr">If you’re interested in a smoother WordPress workflow, listen to Roots Radio, whether you use Roots or not. <a href="https://t.co/vhocxb9tkC">https://t.co/vhocxb9tkC</a></p>
<p>&mdash; Fränk Klein (@fklux) <a href="https://twitter.com/fklux/status/621432291341017088">July 15, 2015</a></p></blockquote>
<p></p>
<p>Ben Word and Scott Walkinshaw recently appeared on <a href="https://changelog.com/podcast/" target="_blank">The Changelog</a> podcast, a weekly show that covers the intersection of software development and open source, to discuss &#8220;<a href="https://changelog.com/156/" target="_blank">Modern WordPress using Bedrock and Sage</a>.&#8221;</p>
<p>&#8220;After Scott and I appeared on the Changelog podcast, the guys on the team wanted to get something going,&#8221; Word said. Even though the WordPress community already has many regular podcasts devoted to news, business, and development, Word believes that the Roots team has something unique to offer with their experience and dedication to using modern web development tools.</p>
<p>He shared a sneak preview of some of the topics the team plans to cover in future episodes of Roots Radio:</p>
<ul>
<li>Deployments</li>
<li>Theme wrapper and DRY</li>
<li>Security</li>
<li>Composer</li>
<li>Forking WordPress</li>
<li>Open Source Support/Maintenance/Burnout</li>
<li>Keeping Roots projects up-to-date</li>
<li>Framework agnostic workflow</li>
<li>Theming tips and tricks</li>
<li>How to contribute to Roots / open source</li>
<li>Stepping outside of WordPress land</li>
<li>Unit tests</li>
</ul>
<p>Word confirmed that Roots Radio will have guests on upcoming episodes. If these topics have piqued your interest, you can subscribe to the podcast via <a href="https://itunes.apple.com/us/podcast/roots-radio/id1015480854" target="_blank">iTunes</a> or <a href="http://feeds.soundcloud.com/users/soundcloud:users:160680092/sounds.rss" target="_blank">RSS</a>. New episodes will be released every couple of weeks.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Jul 2015 20:24:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WPTavern: WordPress 4.3 Beta 3 Adds Site Icon Feature to the Customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46676";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://wptavern.com/wordpress-4-3-beta-3-adds-site-icon-feature-to-the-customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4288:"<p>WordPress 4.3 <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/" target="_blank">beta 3</a> was released this week right on <a href="https://make.wordpress.org/core/version-4-3-project-schedule/" target="_blank">schedule</a>, and beta 4 is expected to arrive next Wednesday. This release includes more than <a href="https://core.trac.wordpress.org/log?action=stop_on_copy&mode=stop_on_copy&rev=33286&stop_rev=33141&limit=150" target="_blank">140 fixes and improvements</a> since last week&#8217;s beta.</p>
<p>One of the most important changes you&#8217;ll notice is that the <a href="http://wptavern.com/wordpress-4-3-adds-new-site-icons-feature-and-a-text-editor-to-press-this" target="_blank">Site Icon feature</a> is now available in the customizer in addition to its spot under <strong>General > Settings</strong>. The new panel is called Site Identity and it includes the site title, tagline, and the icon upload controls.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/site-identity-new-customizer-panel.jpg"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/site-identity-new-customizer-panel.jpg?resize=1025%2C690" alt="site-identity-new-customizer-panel" class="aligncenter size-full wp-image-46773" /></a></p>
<p>&#8220;The feature is now complete and requires lots of testing,&#8221; WordPress 4.3 release lead Konstantin Obenland said in the announcement. &#8220;Please help us ensure the site icon feature works well in both Settings and the Customizer.&#8221;</p>
<p>Mark Jaquith&#8217;s work to improve passwords has also been added to the installation process so that administrators will be prompted to select a strong password when setting up a new site. This screenshot from Ryan Boren&#8217;s most recent &#8220;<a href="https://make.wordpress.org/core/2015/07/15/today-in-the-nightly-site-icons-in-the-customizer-editor-patterns-more-accessible-comment-bubbles-row-toggle-focus-styling/" target="_blank">Today in the Nightly</a>&#8221; update shows the password strength meter&#8217;s feedback added to the UI.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/passwords-ui-on-install-screen-1024x740.png"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/passwords-ui-on-install-screen-1024x740.png?resize=1024%2C740" alt="photo credit: Ryan Boren" class="size-full wp-image-46779" /></a>photo credit: <a href="https://make.wordpress.org/core/2015/07/15/today-in-the-nightly-site-icons-in-the-customizer-editor-patterns-more-accessible-comment-bubbles-row-toggle-focus-styling/passwords-ui-on-install-screen/">Ryan Boren</a>
<p>Boren also highlighted the value of the new Markdown-esque patterns recognized in the post editor and their convenience for mobile users. Instead of trying to format HTML on a tiny screen, users will be able to take advantage of the new shortcuts which require fewer keystrokes.</p>
<p>&#8220;Create bulleted lists, ordered lists, and blockquotes using markdown like patterns,&#8221; he said. &#8220;I find this particularly handy on phones when the editor toolbar is offscreen.&#8221;</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/editor-patterns-keyboard-shortcuts-list.jpg"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/editor-patterns-keyboard-shortcuts-list.jpg?resize=1025%2C541" alt="photo credit: Ryan Boren" class="size-full wp-image-46785" /></a>photo credit: <a href="https://make.wordpress.org/core/2015/07/15/today-in-the-nightly-site-icons-in-the-customizer-editor-patterns-more-accessible-comment-bubbles-row-toggle-focus-styling/">Ryan Boren</a>
<p>Beta 3 also improves the accessibility of comments and media list tables with a better design for comment bubbles and focus styling for row toggles. Obenland welcomes feedback on the accessibility improvements from those who are using WordPress with screen readers.</p>
<p>With 140 changes in beta 3, a new round of testing is in order. You can help by installing the <a href="https://wordpress.org/plugins/wordpress-beta-tester/" target="_blank">WordPress Beta Tester</a> plugin on a development site and reporting any bugs you find in the recent improvements. The official WordPress 4.3 release is now just four weeks away.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jul 2015 22:01:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: WPWeekly Episode 199 – Preview of WordPress 4.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=46746&preview_id=46746";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wptavern.com/wpweekly-episode-199-preview-of-wordpress-4-3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2747:"<p>In this episode of WordPress Weekly, <a href="http://marcuscouch.com/">Marcus Couch</a> and I preview WordPress 4.3. We discuss what WordPress.tv should do with old videos now that the site is six years old. There&#8217;s a conference this weekend devoted to the Genesis Framework and we let you know how you can watch it for free.</p>
<p>Theme translations and language packs are on their way to the WordPress theme directory. Last but not least, we congratulate Topher DeRosia on reaching his funding goals to attend WordCamp Pune, India.</p>
<h2>Stories Discussed:</h2>
<p><a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/">WordPress 4.3 Beta 3</a><br />
<a href="http://www.wpbeginner.com/news/whats-coming-in-wordpress-4-3-features-and-screenshots">What’s Coming in WordPress 4.3</a><br />
<a href="https://make.wordpress.org/tv/2015/07/03/ui-for-outdated-content/">UI For Outdated Content on WordPress.tv</a><br />
<a href="http://wptavern.com/theme-translations-and-language-packs-are-coming-to-wordpress-org">Theme Translations and Language Packs are Coming to WordPress.org</a><br />
<a href="http://wptavern.com/the-first-24hr-conference-devoted-to-the-genesis-framework-set-for-july-19-20">The First 24hr Conference Devoted to the Genesis Framework Set for July 18-20</a><br />
<a href="http://wptavern.com/topher-derosia-launches-gofundme-campaign-to-attend-wordcamp-pune-india">Topher DeRosia Launches GoFundMe Campaign to Attend WordCamp Pune, India</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="https://wordpress.org/plugins/background-image-cropper/">Background Image Cropper</a> is a WordPress core feature-plugin that adds cropping to background images for parity with header images.</p>
<p><a href="https://wordpress.org/plugins/frontier-restrict-media/">Frontier Restrict Media</a> will restrict users so they can only access their own media files from the media library.</p>
<p><a href="https://wordpress.org/plugins/image-hover-effects/">Image Hover Effects</a> allows users to add 40+ hover effects to images with captions.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, July 22nd 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #199:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jul 2015 19:02:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: How to Give Back to the WordPress Foundation when Shopping on Amazon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46683";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://wptavern.com/how-to-give-back-to-the-wordpress-foundation-when-shopping-on-amazon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5051:"<p>Consumer disappointment ran high yesterday when Amazon Prime Day <a href="https://twitter.com/hashtag/PrimeDayFail?src=hash" target="_blank">failed</a> to deliver on its ambitious claim to have &#8220;more deals than Black Friday.&#8221; Prime customers were surprised to find modest deals on knee braces, shoe horns, and pet grooming kits instead of steep discounts on shiny electronics.</p>
<blockquote class="twitter-tweet" width="550"><p lang="en" dir="ltr">A Diane Keaton T Shirt,  with a 5 pack of brass knuckles AND ham?!?! DREAMS CAN COME TRUE <a href="https://twitter.com/hashtag/PrimeDayFail?src=hash">#PrimeDayFail</a> <a href="http://t.co/hE1X6lhGb5">pic.twitter.com/hE1X6lhGb5</a></p>
<p>&mdash; Roy Buckingham (@shave_my_lemon) <a href="https://twitter.com/shave_my_lemon/status/621462914533232640">July 15, 2015</a></p></blockquote>
<p></p>
<p>The world was optimistic that if any company could create a consumer holiday out of thin air, Amazon would be the one to do it. Despite Prime Day&#8217;s humor-inspiring failure, consumer obsession with the online retail giant isn&#8217;t likely to wane anytime soon. In fact, the company reported that its &#8220;&#8216;<a href="http://phx.corporate-ir.net/phoenix.zhtml?c=176060&p=irol-newsArticle&ID=2068090" target="_blank">Prime Day&#8217; peak order rates surpassed that of 2014’s Black Friday</a>&#8221; early in the day.</p>
<p>If you&#8217;re a die hard Amazon shopper, you&#8217;ll probably continue on as if Prime Day never happened. Here&#8217;s how you can do something good for WordPress while you&#8217;re at it:</p>
<p>The <a href="http://smile.amazon.com/" target="_blank">AmazonSmile Foundation</a> enables shoppers to support their favorite charitable organizations when making purchases, at no extra cost. If you select a charity, AmazonSmile will automatically donate 0.5% of the purchase price from your eligible purchases. The <a href="http://wordpressfoundation.org/" target="_blank">WordPress Foundation</a> is among the nearly one million organizations that you can support.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/amazon-wordpress-foundation.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/amazon-wordpress-foundation.jpg?resize=1025%2C479" alt="amazon-wordpress-foundation" class="aligncenter size-full wp-image-46731" /></a></p>
<p>To sign up, simply visit <a href="http://smile.amazon.com/" target="_blank">Smile.Amazon.com</a> and select the WordPress Foundation. You&#8217;ll be presented with options that will help you navigate to Smile.Amazon.com more conveniently the next time you shop. If you have already selected a charity and want to change it, you can visit your account settings to search and select a new organization.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/amazon-smile-change-charity.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/amazon-smile-change-charity.jpg?resize=877%2C492" alt="amazon-smile-change-charity" class="aligncenter size-full wp-image-46735" /></a></p>
<h3>What does the WordPress Foundation do?</h3>
<p>Before you opt to support the <a href="http://wordpressfoundation.org/" target="_blank">WordPress Foundation</a>, it&#8217;s important to know what it&#8217;s all about. The 501(c)3 non-profit organization was established &#8220;to further the mission of the WordPress open source project: to democratize publishing through Open Source, GPL software.&#8221; Matt Mullenweg created the charity to ensure that future generations will have access to WordPress as the project&#8217;s leadership and contributor base continue to evolve. It also exists to protect the WordPress and WordCamp trademarks and logos.</p>
<p>A large portion of donations to the foundation go towards subsidizing WordCamp expenses, including video production of presentations for WordCamp.tv. The foundation also <a href="http://wptavern.com/wordpress-foundation-to-foot-the-bill-for-meetup-com-organizer-dues" target="_blank">covers Meetup.com organizer dues</a> for those who run WordPress meetups. At the beginning of this year, the foundation <a href="http://wptavern.com/the-wordpress-foundation-creates-a-traveling-scholarship-in-memory-of-kim-parsell" target="_blank">created a new traveling scholarship for women attending WordCamp US</a>, in memory of Kim Parsell, a prolific WordPress contributor who passed away this year.</p>
<p>When you support the WordPress Foundation, you are supporting a variety of community initiatives that help ensure the future of WordPress for years to come. Rose Goldman, who helps manage the foundation, recently set the organization up on AmazonSmile. So far, she said the donations from Amazon represent just a trickle of the budget, but that&#8217;s probably due to lack of awareness of AmazonSmile. If you haven&#8217;t yet selected a charity for automatic donations from <a href="http://smile.amazon.com/" target="_blank">AmazonSmile</a>, the WordPress Foundation is a worthy cause.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jul 2015 18:52:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WPTavern: What Should WordPress.tv Do with Old Videos?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46713";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wptavern.com/what-should-wordpress-tv-do-with-old-videos";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4208:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WordPressTVFeaturedImage.png"><img class="size-full wp-image-46739" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WordPressTVFeaturedImage.png?resize=666%2C254" alt="WordPress TV Featured Image" /></a>photo credit: <a href="http://www.flickr.com/photos/30719244@N06/8648634062">tvs</a> &#8211; <a href="https://creativecommons.org/licenses/by-sa/2.0/">(license)</a>
<p><a href="http://wordpress.tv/">WordPress.tv</a> launched in <a href="https://wordpress.org/news/2009/01/wordpresstv/">January of 2009</a> and since then has become one of the largest repositories of information dedicated to WordPress. To put that in perspective, WordPress 2.8 and 2.9 were released the same year.</p>
<p>However, with more than six years of content available, the team has run into a problem. On July 3rd, Brash Rebel, who helps manage WordPress.tv, <a href="https://make.wordpress.org/tv/2015/07/03/ui-for-outdated-content/">asked</a> if there should be a user interface for outdated content.</p>
<blockquote><p>A reality we are now facing is the fact that the software we know and love has evolved and changed considerably over this time period, thus rendering much of the early content on this site no longer applicable to users of more current releases of WordPress. In <a href="https://wordpress.slack.com/archives/wptv/p1435856572000421">today’s TV team Slack meeting</a> the question was raised about how to properly address outdated, deprecated, no-longer-accurate content.</p></blockquote>
<p>The first question considered is whether to keep or delete old content, specifically, videos in the <a href="http://wordpress.tv/category/how-to/">How To</a> category. Since so many people watch older tutorial style videos, the team decided that removing the content permanently from the site is not the best course of action. The other question considered is whether older presentations on specific subjects should be deleted.</p>
<p>For example, the following two sessions are about the same subject but four years apart. The content in the 2015 video is more likely to match the Google Analytics experience of today.</p>
<ol>
<li><a href="http://wordpress.tv/2013/03/16/melinda-samson-workshop-google-analytics-101/">Melinda Samson: Google Analytics 101 Workshop (2011)</a></li>
<li><a href="http://wordpress.tv/2015/05/16/david-bird-google-analytics-and-wordpress-for-beginners-2/">David Bird: Google Analytics and WordPress for Beginners (May, 2015)</a></li>
</ol>
<p>The team also discussed a variety of ideas on how to display information to viewers that they&#8217;re watching outdated content. These included, text prompts, information bars, links, and determining the best method to indicate videos don&#8217;t reflect the current WordPress experience.</p>
<p>Rebel says the goal isn&#8217;t to strictly deal with the issue today, but also set a precedence for the future. As more WordCamps occur across the globe and more <a href="https://make.wordpress.org/tv/2015/06/16/do-you-screencast-or-make-video-tutorials-of-how-to-use-wordpress-wordpress-tv-wants-you/">screencasts</a> show up on WordPress.tv, the team needs to figure out a balance between displaying old content and making the most out of fresh content.</p>
<h2>Mimic the Plugin Directory</h2>
<p>I&#8217;m happy that the team won&#8217;t delete old videos. As someone who writes about WordPress everyday, the videos on WordPress.tv contain a wealth of knowledge. It would be a shame to see so much information deleted.</p>
<p>I think the best and easiest solution is to mimic the WordPress plugin directory in how it deals with plugins that haven&#8217;t been updated in two years or more. A prominent message displays on the page telling the viewer that the content they&#8217;re watching is outdated. It could be taken a step further by showing the viewer a list of related videos that are more recent.</p>
<p>I encourage you to<a href="https://make.wordpress.org/tv/2015/07/03/ui-for-outdated-content/"> read the blog post</a> and the associated comments as they contain some good ideas. What do you think should be done with old content on WordPress.tv?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jul 2015 18:12:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt: TSA Jazz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45236";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:30:"http://ma.tt/2015/07/tsa-jazz/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:769:"<p>At an airport in Frankfurt airport security asked famous jazz saxophonist <a href="http://www.joshuaredman.com/">Joshua Redman</a> to prove it was a real instrument.</p>
<blockquote class="twitter-tweet" width="550"><p lang="en" dir="ltr">[airport security, FRA]&#10;*sax flagged*&#10;“Pls play”&#10;“Seriously?”&#10;“Yes”&#10;*i play Ornithology*&#10;*midway thru 1st chorus*&#10;“Enuf u’re clear pls stop”</p>
<p>&mdash; Joshua Redman (@Joshua_Redman) <a href="https://twitter.com/Joshua_Redman/status/619144413369909248">July 9, 2015</a></p></blockquote>
<p></p>
<p>Hilarious! I can&#8217;t find any recordings of Joshua playing that classic bebop song, but here&#8217;s a Charlie Parker recording:</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jul 2015 15:12:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"WPTavern: Explore the WordPress REST API with the New Interactive Console Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46685";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://wptavern.com/explore-the-wordpress-rest-api-with-the-new-interactive-console-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3697:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg?resize=1025%2C469" alt="wp-rest-api" class="aligncenter size-full wp-image-43000" /></a></p>
<p>WordPress REST API project lead <a href="https://twitter.com/rmccue" target="_blank">Ryan McCue</a>, in cooperation with <a href="https://twitter.com/AutomatticEng" target="_blank">Automattic&#8217;s Engineering team</a>, released a <a href="https://wordpress.org/plugins/rest-api-console/" target="_blank">REST API Console</a> plugin on WordPress.org today. It&#8217;s a basic console that fits right into the WordPress admin and allows you to explore the API, make small changes, and find out what your site is exposing.</p>
<p>&#8220;This is a forked version of the WP.com console that myself and members of the Apollo team at Automattic worked on,&#8221; McCue told the Tavern. The console was converted in approximately four casual days, and McCue credits <a href="http://viewsource.beaucollins.com/" target="_blank">Beau Collins</a> for this, as he originally wrote the majority of the console for developers working on WordPress.com.</p>
<p>&#8220;It&#8217;s pretty useful for exploring the API as a learning tool, but also for developers who are extending the API to get a sense of how their stuff fits in,&#8221; he said.</p>
<p>The REST API Console plugin requires the <a href="https://wordpress.org/plugin/rest-api/" target="_blank">WP REST API plugin</a> version 2.0 or later. You can find this on the <a href="https://github.com/WP-API/WP-API" target="_blank">GitHub project page</a> and version 2 should be up on WordPress.org within the next day or two. Once you have both plugins installed, the console is visible in the admin under <strong>Tools > Rest API Console</strong>.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-rest-api-console-demo.jpg"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-rest-api-console-demo.jpg?resize=829%2C236" alt="wp-rest-api-console-demo" class="aligncenter size-full wp-image-46693" /></a></p>
<p>You can actually make changes to your site using the console, so it&#8217;s advisable to install it on a local site and play with it there. While the GET requests can&#8217;t change anything, the other types can edit or delete posts (which would end up in your trash).</p>
<p>The plugin can only connect to the local site you&#8217;re currently on and cannot access remote WordPress sites. McCue recommends using something like <a href="https://www.getpostman.com/" target="_blank">Postman</a> or <a href="http://luckymarmot.com/paw" target="_blank">Paw</a> if you want to play around with remote sites.</p>
<p>In the future, he hopes to add more features and improve the plugin&#8217;s parameter documentation.</p>
<p>&#8220;The older WordPress.com console had the ability to click through to links, so I&#8217;d like to re-add that at some point,&#8221; he said. &#8220;The parameter documentation and tooling hasn&#8217;t been fleshed out yet, but the plan is to do it eventually &#8211; we&#8217;re working on exposing more from the API itself, too.&#8221;</p>
<p>If you want to tinker with the API but don&#8217;t have a local testing site handy, check out the live demo at <a href="http://demo.wp-api.org" target="_blank">demo.wp-api.org</a> where you can click around to explore. This will save you the trouble of installing the plugin, if you just want to try it out. Also, you can&#8217;t perform any destructive changes there. Version 2 of the WP REST API plugin should be available on WordPress.org within 24-48 hours.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jul 2015 00:31:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:106:"WPTavern: WordPress Theme Review Team Unanimously Approves Roadmap to Improve Directory and Review Process";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46551";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:116:"http://wptavern.com/wordpress-theme-review-team-unanimously-approves-roadmap-to-improve-directory-and-review-process";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2613:"<p>The <a href="https://make.wordpress.org/themes/">Theme Review Team</a> has spent the last two months <a href="http://wptavern.com/wordpress-theme-review-team-seeks-feedback-on-the-review-process-themes-and-the-directory">collecting data from surveys</a> to discover common pain points people experience using the theme directory and going through the theme review process. The results of those surveys were used to <a href="https://make.wordpress.org/themes/2015/07/07/roadmap-for-phase-one/">create a roadmap</a> of areas to focus on.</p>
<p>In yesterday&#8217;s meeting, the Theme Review Team voted and those in attendance <a href="https://wordpress.slack.com/archives/themereview/p1436896772000053">unanimously approved</a> the roadmap.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ThemeReviewTeamRoadmapVote.png"><img class="size-full wp-image-46668" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ThemeReviewTeamRoadmapVote.png?resize=471%2C560" alt="Phase One Roadmap Approved" /></a>Phase One Roadmap Approved
<p>One of the key parts to the roadmap is creating groups with a scope of responsibilities. The groups include:</p>
<ul>
<li>Directory</li>
<li>Documentation</li>
<li>Tools</li>
<li>Reviews and queues</li>
<li>UX and research</li>
</ul>
<p>Each group needs a point person who acts as the communication bridge between the group and Theme Review Team. Tammie Lister explains what the point person&#8217;s role is within a group.</p>
<blockquote><p>This person will report weekly what is going on during the chats. They will also post on the make.blog each week about what is going on in each group. This should ensure we keep up communication and make sure things get done.</p></blockquote>
<p>They&#8217;re not necessarily in charge of getting things done but rather, act as a facilitator to make sure the group stays on track.</p>
<p>One part of the roadmap that I&#8217;m interested in is the possibility of a report button added to the theme directory to allow users to report themes. If this happens, it will be interesting to see how it&#8217;s used or abused and whether it adds any additional work load to the theme reviewers.</p>
<p>The roadmap looks solid and shows the team is focused on improving several aspects of the Theme Directory. This is a great opportunity for new contributors to get involved with the project. If you&#8217;re interested in joining any of the groups within the Theme Review Team, please visit the <strong>#themereview</strong> channel on <a href="https://make.wordpress.org/chat/">Slack</a> and let the team know.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jul 2015 21:10:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: Proper Lite: A Free and Flexible WordPress Theme for Creatives";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46585";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://wptavern.com/proper-lite-a-free-and-flexible-wordpress-theme-for-creatives";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3530:"<p>Last November, ModernThemes <a href="http://wptavern.com/modernthemes-launches-site-dedicated-to-providing-free-wordpress-themes" target="_blank">officially launched its free WordPress themes site</a> and has been gradually adding to its <a href="https://wordpress.org/themes/author/modernthemesnet/" target="_blank">collection</a> hosted on WordPress.org. Founders Robbie Grabowski and Mike Driscoll launched the site with a commitment to produce themes that support the native customizer and keep plugin functionality separate while still being &#8220;plugin-friendly.&#8221;</p>
<p><a href="https://modernthemes.net/wordpress-themes/proper-lite/" target="_blank">Proper Lite</a> is ModernThemes&#8217; latest release, created to be fully compatible with their new <a href="https://modernthemes.net/plugins/" target="_blank">library of free plugins</a> that add functionality like shortcodes, widgets, sidebars, services, testimonials, projects, etc.</p>
<p>The theme features a fullscreen homepage hero section with multiple controls for customizing the background, text, and buttons.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/properlite_mockups.png"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/properlite_mockups.png?resize=1000%2C700" alt="properlite_mockups" class="aligncenter size-full wp-image-46645" /></a></p>
<p>Proper Lite was designed with a modular homepage layout that supports three flexible widget areas where you can drop in portfolio items, blogs, testimonials, or any other content you choose. This is one of the reasons why ModernThemes calls it their most flexible free theme to date.</p>
<p>In addition to the default template, Proper Lite includes Homepage, Full Width, and Left Sidebar templates. It also has specific styling for various content blocks added from the plugin library, as you can see in the <a href="https://modernthemes.net/demo/?theme=properlite" target="_blank">live demo</a>.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/team-members.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/team-members.jpg?resize=926%2C897" alt="team-members" class="aligncenter size-full wp-image-46654" /></a></p>
<p>Proper Lite has an amazing array of controls included in the customizer. Users can easily adjust Google Fonts, logos and icons, nearly every color used in the theme, social media icons, a footer call-to-action, the number of columns in the widget areas, and much more. The theme was not created with a set, inflexible design. Versatility is one of its key features.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/proper-lite-customizer.png"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/proper-lite-customizer.png?resize=1025%2C426" alt="proper-lite-customizer" class="aligncenter size-full wp-image-46659" /></a></p>
<p>Proper Lite, like other themes from ModernThemes, has extensive <a href="https://modernthemes.net/proper-lite-documentation/" target="_blank">documentation</a> available on the website for every section included in the theme. While this theme is heavily geared toward creatives with an emphasis on fullwidth images and portfolio content, it is also suitable for personal blogs, agencies, and creative businesses, thanks to the wide range of plugins available to extend it. <a href="https://modernthemes.net/wordpress-themes/proper-lite/" target="_blank">Download</a> it for free from the ModernThemes website.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jul 2015 18:42:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Matt: Sleep Dep";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45247";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:31:"http://ma.tt/2015/07/sleep-dep/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:186:"<p><a href="http://www.theatlantic.com/health/archive/2013/12/how-sleep-deprivation-decays-the-mind-and-body/282395/">How Sleep Deprivation Decays the Mind and Body</a>. Crazy story.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jul 2015 04:46:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Matt: Plato, Phaedrus, Google";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45224";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:36:"http://ma.tt/2015/07/plato-phaedrus/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:822:"<blockquote><p>and now you, who are the father of letters, have been led by your affection to ascribe to them a power the opposite of that which they really possess. For this invention will produce forgetfulness in the minds of those who learn to use it, because they will not practice their memory. Their trust in writing, produced by external characters which are no part of themselves, will discourage the use of their own memory within them. You have invented an elixir not of memory, but of reminding; [&#8230;]</p></blockquote>
<p><a href="http://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.01.0174%3Atext%3DPhaedrus%3Asection%3D275a">A few thousand years ago Plato predicted how Google would make us less able to remember things</a>.</p>
<p>Hat tip: <a href="http://chris.ink/">Chris Rudzki</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jul 2015 04:24:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:97:"WPTavern: BuddyBoss Expands Into LMS Market with Free BuddyPress Plugins for LearnDash and Sensei";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46573";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:107:"http://wptavern.com/buddyboss-expands-into-lms-market-with-free-buddypress-plugins-for-learndash-and-sensei";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3139:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/learndash.png"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/learndash.png?resize=680%2C310" alt="learndash" class="aligncenter size-full wp-image-46576" /></a></p>
<p>In May, <a href="http://www.buddyboss.com/" target="_blank">BuddyBoss</a> founder Michael Eisenwasser shared with Tavern readers the <a href="http://wptavern.com/inside-buddyboss-with-michael-eisenwasser" target="_blank">challenges of creating a profitable business</a> in what is still a relatively small marketplace for BuddyPress themes and plugins. Developers are building niche social networks every day, but BuddyPress&#8217; appeal as a platform hinges on the availability of compelling and reliable third-party add-ons.</p>
<p>Over the past couple of months, BuddyBoss has branched out into serving the LMS market with free BuddyPress integration plugins for <a href="http://www.learndash.com/" target="_blank">LearnDash</a> and <a href="http://www.woothemes.com/products/sensei/" target="_blank">Sensei</a>, two of WordPress&#8217; most popular LMS solutions. Both <a href="https://wordpress.org/plugins/buddypress-learndash/" target="_blank">BuddyPress for LearnDash</a> and <a href="https://wordpress.org/plugins/sensei-buddypress/" target="_blank">BuddyPress for Sensei</a> were created to work with any theme, but are also guaranteed to work seamlessly with BuddyBoss&#8217; new Social Learner theme.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/social-learner.png"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/social-learner.png?resize=1000%2C573" alt="social-learner" class="aligncenter size-full wp-image-46620" /></a></p>
<p>Both plugins have similar core feature sets that include the ability to create courses, lessons, quizzes, and tie it all in to BuddyPress activity, groups, and forums to create a social learning platform. Course managers can even introduce gamification into the learning process with open source <a href="http://badgeos.org/" target="_blank">BadgeOS</a> plugin integration.</p>
<p>Social learning communities, like popular social goal or fitness tracking apps, bring a higher level of engagement by leveraging the people factor. An LMS powered by WordPress and BuddyPress provides students with the ability to connect to new friends, collaborate, send messages, earn badges &#8211; all activities that contribute to a higher level of motivation for learning and success.</p>
<p>The idea is not new to BuddyPress, as the long-abandoned <a href="http://buddypress.coursewa.re/" target="_blank">BuddyPress Courseware</a> project brought a social aspect to e-learning nearly four years ago. However, it is difficult to maintain an LMS plugin that only works with BuddyPress, because it doesn&#8217;t have the benefit of contributions and testing from a larger community. BuddyBoss made a strategic move in building plugins that would bridge BuddyPress to extend existing LMS solutions that serve the larger WordPress market. Both newer alternatives are available for free on WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Jul 2015 22:53:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WPTavern: Theme Translations and Language Packs are Coming to WordPress.org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46589";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://wptavern.com/theme-translations-and-language-packs-are-coming-to-wordpress-org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3610:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/globe.jpg"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/globe.jpg?resize=1024%2C499" alt="photo credit: . Entrer dans le rêve - cc" class="size-full wp-image-29134" /></a>photo credit: <a href="https://www.flickr.com/photos/tranbina/4765484383/">. Entrer dans le rêve</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p>WordPress.org will soon support translations and language packs for themes hosted in the official directory. In <a href="http://wptavern.com/highlights-of-matt-mullenwegs-qa-session-at-wordcamp-europe-2015" target="_blank">Matt Mullenweg&#8217;s Q&amp;A at WordCamp Europe 2015</a>, he emphasized the importance of having better language support for themes and plugins and identified this as a high priority for continued improvements to WordPress.org.</p>
<p>Today the WordPress meta team <a href="https://make.wordpress.org/themes/2015/07/14/theme-translations-on-wordpress-org/" target="_blank">announced</a> that theme translations will soon be available on WordPress.org at <a href="http://translate.wordpress.org" target="_blank">translate.wordpress.org</a>. Within the next few days or weeks, all active themes (those updated within the last two years) will have their strings imported.</p>
<p>&#8220;This will involve importing ~1500 themes, which, combined, have about 315,000 total strings,&#8221; Sam Sidler said in the announcement. &#8220;After duplicates, the number drops to only 80,000 unique strings.&#8221;</p>
<h3>Language Packs Will Reduce Download Sizes for Themes</h3>
<p>Sidler outlined several advantages for theme authors who opt to manage translations on WordPress.org, including the community&#8217;s large network of contributing translators who currently maintain 140 locales on <a href="http://translate.wordpress.org" target="_blank">translate.wordpress.org</a>.</p>
<p>The most exciting change is that themes hosted on WordPress.org will soon be able to take advantage of language packs. Theme authors will have the option to remove translations from their zip file in favor of allowing WordPress.org to deliver the language packs, resulting in smaller download sizes.</p>
<p>&#8220;Eventually, we also plan to give priority to localized themes in localized directories; e.g., someone searching the Romanian theme directory will see Romanian themes prioritized over English-only themes,&#8221; Sidler said.</p>
<p>The more languages a theme can be translated into, the greater its prominence in WordPress&#8217; language-specific theme directories. This should provide WordPress.org theme authors with a strong motivation to <a href="https://make.wordpress.org/polyglots/handbook/rosetta/theme-plugin-directories/" target="_blank">work with the polyglots team</a> to get more translations. Theme authors can also request new translation editors to be added to polyglots, if they want to continue working with their own translators.</p>
<p>Those who prefer to ship their own translations can continue to do so. Keeping the translation files in your zip package will essentially opt you out of language packs for those specific translations. If you need help adding support for translations and language packs, Sidler recommends Otto&#8217;s <a href="http://ottopress.com/2013/language-packs-101-prepwork/" target="_blank">Language Packs 101</a> tutorial in addition to the <a href="https://developer.wordpress.org/themes/functionality/internationalization/" target="_blank">Theme Developer Handbook section on Internationalization</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Jul 2015 20:22:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WPTavern: The First 24hr Conference Devoted to the Genesis Framework Set for July 18-20";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46565";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wptavern.com/the-first-24hr-conference-devoted-to-the-genesis-framework-set-for-july-19-20";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1461:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/GenesisCampFeaturedImage.png"><img class="aligncenter size-full wp-image-46579" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/GenesisCampFeaturedImage.png?resize=880%2C275" alt="Genesis Camp Featured Image" /></a><a href="http://genesis.camp/">Genesis Camp</a> is the first 24 hour conference dedicated to the Genesis framework by <a href="http://www.studiopress.com/">Studiopress</a>. The event takes place on July 18-20 and is free to attend. Even though the event is dedicated to the Genesis framework, it&#8217;s not associated with Copyblogger Media or Studiopress.</p>
<p>Organized by a community of Genesis users, the event features <a href="http://genesis.camp/sessions/">sessions</a> on development workflow, branding, collaboration, and more. Each session will include an area for viewers to chat and ask questions. Speakers include Chris Lema, Carrie Dils, Wes Linda, David Wang, Heather Porter, and more.</p>
<p>Sessions will be recorded in case you can&#8217;t stay awake to watch all 24 hours of the event. Videos will be handled by <a href="http://www.google.com/+/learnmore/hangouts/">Google Hangouts</a> while <a href="https://www.crowdcast.io/">Crowd Cast</a> will be used to allow viewers to chat during sessions. To watch the event you&#8217;ll need to register on the <a href="https://www.crowdcast.io/e/genesiscamp1">Genesis Camp Crowd Cast site</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Jul 2015 17:43:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: Candid Conversation with Tom McFarlin About the WordPress Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46549";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wptavern.com/candid-conversation-with-tom-mcfarlin-about-the-wordpress-community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1158:"<p>Earlier this month, Tom McFarlin <a href="https://tommcfarlin.com/the-wordpress-community-a-comedy-of-drama-ego-oligarchies-and-more/">published a great post</a> where he shares his perspective on the WordPress community. His post struck a nerve and instead of discussing it through comments, I invited him to a Google Hangout to have a candid conversation. Within the conversation, McFarlin and I discuss a number of topics, including:</p>
<ul>
<li>Community behaviour and discourse</li>
<li>It&#8217;s not a WordPress problem</li>
<li>Comment moderation strategies</li>
<li>Subtweeting</li>
<li>How, as men, do we show that a significant portion of us are color/ethnicity/whatever blind?</li>
<li>Women in tech</li>
</ul>
<p>McFarlin is the father of two daughters which adds an interesting dynamic to the women in tech issue. I enjoyed the time I spent with him discussing topics we both feel are important. If you have any feedback concerning the content in this recording, please leave a comment.</p>
<p>There&#8217;s also a transcript of the interview <a href="http://www.wptavern.com/wpweeklyaudio/TomMcFarlinTranscript.zip">available here</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Jul 2015 16:16:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Matt: Hacking Team Hack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45238";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:39:"http://ma.tt/2015/07/hacking-team-hack/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:966:"<p>I haven&#8217;t been following the Hacking Team story too closely. If you&#8217;re the same, here&#8217;s a quick catch-up: an Italian company that sold hacking tools, often to questionable governments, had all of their internal company data including emails, source code, everything released. <a href="http://www.engadget.com/2015/07/09/how-spyware-peddler-hacking-team-was-publicly-dismantled/">Engadget has the best summary I&#8217;ve seen so far of how they got hacked</a>, which was apparently done by a hacker vigilante who did something similar to another organization called the Gamma Group. <a href="https://firstlook.org/theintercept/2015/07/08/hacking-team-emails-exposed-death-squad-uk-spying/">The Intercept also has a good look at some of the more egregious behavior</a>. Bruce Schneier <a href="https://www.schneier.com/blog/archives/2015/07/organizational_.html">calls this new trend Organizational Doxxing and considers its ramifications</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Jul 2015 03:43:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: Topher DeRosia Launches GoFundMe Campaign to Attend WordCamp Pune, India";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46545";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wptavern.com/topher-derosia-launches-gofundme-campaign-to-attend-wordcamp-pune-india";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2000:"<p>Topher DeRosia, founder of <a href="http://t.co/Q9hSlXsBKQ">HeroPress</a>, is <a href="http://www.gofundme.com/heropress-in-pune">asking for</a> $2,150 to attend <a href="https://pune.wordcamp.org/2015/">WordCamp Pune</a>, India. DeRosia was asked to speak about HeroPress by Saurabh Shukla, who is a<a href="http://heropress.com/essays/ill-keep-looking-for-a-cms-unless-i-find-wordpress/" target="_blank"> HeroPress contributor</a> and also the lead organizer of WordCamp Pune, India.</p>
<p>In an effort to be transparent, DeRosia published how he will spend the money.</p>
<ul>
<li>$1400 for the plane ticket</li>
<li>$300 for hotel</li>
<li>$200 for food, cabs, Uber, etc</li>
<li>$100 for emergencies</li>
<li>$150 for GoFundMe&#8217;s fees</li>
</ul>
<p>If DeRosia has money left over from his trip, he plans to sponsor a WordCamp that&#8217;s having difficulty finding sponsors or donate it to the WordPress Foundation.</p>
<p>Since launching the campaign a few days ago, he&#8217;s raised $1,000. Unlike most other campaigns, <a href="https://www.gofundme.com/heropress-in-pune/donate">donors can choose</a> the amount they want to give. Among the donors listed is Matt Mullenweg, who contributed $250. If you enjoy the time, work, and effort put into HeroPress, consider donating a few dollars.</p>
<p><strong>Within 24 hours since this post was published, DeRosia surpassed his funding goal.</strong></p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WordCampPuneGoalMet.png"><img class="size-full wp-image-46569" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WordCampPuneGoalMet.png?resize=976%2C649" alt="WordCamp Pune Goal Met" /></a>WordCamp Pune Goal Met
<p>I asked DeRosia how it feels to meet is funding goal, &#8220;I&#8217;m super excited about this. Not just the fact that <em>other people</em> paid for a trip but that the HeroPress community feels this kind of thing is valuable enough to put money out for it. That means a lot.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 13 Jul 2015 23:11:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Embed Your Meerkat Stream on Your WordPress Site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46325";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wptavern.com/embed-your-meerkat-stream-on-your-wordpress-site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4187:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat.png"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat.png?resize=655%2C300" alt="meerkat" class="aligncenter size-full wp-image-46518" /></a></p>
<p>Just one day after <a href="https://meerkatapp.co/" target="_blank">Meerkat</a>, the popular video streaming service, <a href="http://techcrunch.com/2015/06/26/meerkat-outs-an-embeddable-player-hooks-discovery-channels-shark-week/#.qqszef:XITC" target="_blank">launched its embedded player</a>, a WordPress plugin was in the works to make it easy for publishers to take advantage of it. <a href="http://www.artiss.co.uk" target="_blank">David Artiss</a>, an English developer and author of several popular embedding <a href="https://profiles.wordpress.org/dartiss/#content-plugins" target="_blank">plugins</a>, is the first to bring Meerkat embedding to WordPress.</p>
<p>The <a href="https://wordpress.org/plugins/meerkat/" target="_blank">Meerkat plugin</a> lets users embed their streams in WordPress content using a simple shortcode. The embedded player automatically does the following, according to Meerkat&#8217;s documentation:</p>
<blockquote><p>It will show your live stream if you’re live. If you’re not live, if will show your next upcoming stream. If you have no upcoming streams, it will display stats from your last stream. If you have not streamed yet, it will show your profile.</p></blockquote>
<p>All you need is the Meerkat username to use the shortcode in its simplest form:</p>
<p><code>[meerkat username="meerkatapi"]</code></p>
<p>It also includes optional parameters for customizing the username, player type, participation, cover image, muted defaults, and debug settings. These parameters essentially let you customize everything available in the <a href="http://widgets.meerkatapp.co/embed" target="_blank">Meerkat embed code generator</a>.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat-customize-embedded-player.jpg"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat-customize-embedded-player.jpg?resize=746%2C515" alt="meerkat-customize-embedded-player" class="aligncenter size-full wp-image-46532" /></a></p>
<p>The shortcode can be embedded in posts or pages. Artiss plans to add a widget option soon, as the default player size seems to lend itself to display in a sidebar. I tested the plugin with WordPress 4.3 beta 2 and found that it works as advertised.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat-wordpress-plugin-example.jpg"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat-wordpress-plugin-example.jpg?resize=778%2C635" alt="meerkat-wordpress-plugin-example" class="aligncenter size-full wp-image-46533" /></a></p>
<p>At TechCrunch Disrupt in May 2015, Meerkat founder Ben Rubin reported that the service was <a href="http://www.businessinsider.com/meerkat-has-nearly-2-million-users-2015-5" target="_blank">approaching nearly two million users</a>. Chances are that plenty of those users also have WordPress sites where they can gain more exposure for their streams.</p>
<p>Artiss wanted to make it easy for anyone to embed a stream. He isn&#8217;t a Meerkat user himself but found that its API was easy to work with for embedding content.</p>
<p>&#8220;I didn&#8217;t write it for myself but I thought putting the newly released embed function in a simple-to-use plugin for WordPress users would be useful,&#8221; he said. &#8220;I just happened to be working on <a href="https://wordpress.org/plugins/zingtree-embed/" target="_blank">Zingtree Embed plugin</a> at the same time, so it was quite simple to clone that and modify it for a different embed type.&#8221;</p>
<p>If you want your fans and followers to be able to find your Meerkat stream on the web, download the <a href="https://wordpress.org/plugins/meerkat/" target="_blank">Meerkat</a> embed plugin from the WordPress plugin directory. This will allow folks to join you live from your website, without having to use the app on their phones. The widget embed option should land in the next release.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 13 Jul 2015 19:47:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: Envato Targeted by DDoS Attack, WordPress Theme Authors Report Major Decline in Sales";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46485";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://wptavern.com/envato-targeted-by-ddos-attack-wordpress-theme-authors-report-major-decline-in-sales";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6430:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/envato.jpg"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/envato.jpg?resize=697%2C314" alt="envato" class="aligncenter size-full wp-image-29973" /></a></p>
<p>If you&#8217;ve attempted to access Themeforest or any other site on the <a href="http://www.envato.com/" target="_blank">Envato</a> network lately, you may have encountered some down time. The company <a href="http://inside.envato.com/denial-of-service-attacks-on-envato/" target="_blank">updated</a> customers and community members today, attributing the technical difficulties to a DDoS attack:</p>
<blockquote><p>Since July 1, Envato has been the target of a sustained DDoS (distributed denial of service) attack. The attacker, whose motive and identity are unknown, has repeatedly flooded our servers with high levels of traffic, causing our services to be unavailable at various times.</p></blockquote>
<p>The most recent outage happened over the weekend when Envato Market was down for three hours on Friday and one hour on Sunday. This is a significant chunk of time for a market that <a href="http://www.envato.com/2014" target="_blank">paid out $224 million dollars to its members in 2014</a>.</p>
<p>The downtime has also impacted WordPress theme authors, who continue to dominate the Envato&#8217;s marketplace. According to Ben Chan, the company&#8217;s director of growth and revenue, 30 of the 31 sellers who make up the <a href="http://elite.envato.com/wall-of-fame/" target="_blank">Power Elite wall of fame</a> (selling $1 million+ worth of items) are WordPress product authors.</p>
<p>The power of the WordPress economy on Envato is undeniable, but sales have taken a sharp decline in the past couple of months, even before the DDoS attack. According to PremiumWP, which cites reports from elite theme author Chris Robinson of Contempo and many others, <a href="http://www.premiumwp.com/themeforest-authors-report-50-70-drop-in-theme-sales/" target="_blank">sales have suddenly declined 50-70%</a>.</p>
<p>&#8220;Sales have declined over 70% starting from May with each passing day getting worse,&#8221; Robinson said in the <a href="http://themeforest.net/forums/thread/envato-are-youre-not-telling-us-something/185158" target="_blank">members&#8217; forum</a>. &#8220;I’ve also spoken with other elite authors explaining the same thing. One example going from $1500/day to $700 &#8211; sure that’s still a great deal of money BUT what the hell is happening?</p>
<p>&#8220;This isn’t just one or maybe twenty authors, it is marketplace wide affecting everyone. A marketplace wide decline in sales of this magnitude doesn’t just happen due to vacations, or other buyer factors. Going through the years of sales data (since 2008) this has never happened, I’ve personally gone from $2-3000/week to less than $700/week…that’s insane!&#8221;</p>
<p>With new authors and products entering the market every day, the market share for established authors is slowly diminishing, but members are not convinced that this is the sole cause of the sharp drop in sales.</p>
<p>FinalDestiny of TeoThemes, another author whose sales are declining, blames the <a href="http://wptavern.com/envato-continues-to-rake-in-the-cash-from-wordpress-themes-packaged-as-complete-website-solutions" target="_blank">one-size-fits-all theme products</a> for gobbling up a greater slice of the market share.</p>
<p>&#8220;Everybody is tired of these huge, monster multipurpose themes having the same price as normal themes, and that’s pretty much killing the marketplaces. But Envato couldn’t care less, as long as they get their share,&#8221; he <a href="http://themeforest.net/forums/thread/envato-are-youre-not-telling-us-something/185158?page=1&message_id=1303716#1303716" target="_blank">said</a>.</p>
<p>In another <a href="http://themeforest.net/forums/thread/whats-wrong-with-sales-on-tf-/181436" target="_blank">thread</a>, which ended up getting locked, there are 27 pages of comments from users speculating about why their sales have been dropping. Members cite seasonal buying fluctuations, piracy, Themeforest&#8217;s recent drop in Google search rankings, VAT and hidden price additions on checkout, and unfair pricing advantages for monster themes that claim to do everything, among other possible causes.</p>
<p>In one thread, titled &#8220;<a href="http://themeforest.net/forums/thread/more-than-50-sales-drop-for-most-of-the-authors-does-tf-care-for-authors/182262" target="_blank">More than 50% sales drop for most of the authors. Does TF care for Authors?</a>&#8220;, an Envato community officer offered the following comment:</p>
<blockquote><p>We don’t really give sales updates over the forums other than to say your sales can go up and down for a multitude of reasons. Try not to assume the sky is falling every time the USA has a long weekend :) We have fast and slow periods throughout the year same as any business, and your portfolio will no doubt have peaks and valleys as well.</p></blockquote>
<p>This kind of generic reply has left theme authors scratching their heads, despite multiple threads in the forums popping up with concerns from those who are alarmed by the sudden drop. Many WordPress theme authors depend on Themeforest as their primary source of income. In one <a href="http://themeforest.net/forums/thread/more-than-50-sales-drop-for-most-of-the-authors-does-tf-care-for-authors/182262?page=3&message_id=1291143#1291143" target="_blank">reply</a>, the Aligator Studio seller sums up their concerns and frustration with the inability to convince Envato of the unusual circumstances that are affecting large numbers of sellers:</p>
<blockquote><p>We are not talking about valleys and peaks, we’re talking about a general traffic and sales fall, from New Year until now, especially after April. We’re not talking about regular ups and downs (sometimes steeper, sometimes not), due to longer weekends, summer holidays, and general and the usual stuff happening here in the last couple of years.</p>
<p>It’s not a sky falling – it’s inability to pay our bills, we’re not fanatics that foresee the end of the world.</p></blockquote>
<p>Envato has yet to provide an official statement about the marketplace-wide decline in sales, apart from recognizing the network&#8217;s unavailability due to the recent DDoS attack.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 13 Jul 2015 16:42:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Matt: Neil Gaiman Speech at University of the Arts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45241";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://ma.tt/2015/07/neil-gaiman-commencement/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:78:"<p>&#8220;Make good art.&#8221;</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 12 Jul 2015 20:15:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Matt: WordCamp Scranton";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45234";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:39:"http://ma.tt/2015/07/wordcamp-scranton/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:800:"<p>As was just announced, I&#8217;m going to make a not-surprise appearance at WordCamp Scranton next Saturday. It&#8217;s their first year <a href="https://central.wordcamp.org/">doing a Wordcamp</a> and I was able to find some space in my schedule to swing by in between business meetings in New York and Philadelphia, so very much looking forward to meeting the Scranton community.</p>
<blockquote class="twitter-tweet" width="550"><p lang="en" dir="ltr">Matt Mullenweg (<a href="https://twitter.com/photomatt">@photomatt</a>) will Host a Town Hall Q&amp;A at WordCamp Scranton! <a href="https://t.co/qmZSWYPQBS">https://t.co/qmZSWYPQBS</a></p>
<p>&mdash; WordCamp Scranton (@WCScranton) <a href="https://twitter.com/WCScranton/status/619508207283625984">July 10, 2015</a></p></blockquote>
<p></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 11 Jul 2015 16:03:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: WPWeekly Episode 198 – Tackling Mental Health With Cory Miller";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=46473&preview_id=46473";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://wptavern.com/wpweekly-episode-198-tackling-mental-health-with-cory-miller";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2636:"<p>In this episode of WordPress Weekly, <a href="http://marcuscouch.com/">Marcus Couch</a> and I are joined by Cory Miller, <a href="https://ithemes.com/our-founder/">founder of iThemes</a>. Miller discusses his entrepreneurship journey and shares in detail, how he <a href="http://wordpress.tv/2015/07/02/cory-miller-entrepreneurship-and-my-mental-health/">maintains his mental health</a>.</p>
<p>We learn that people battling mental health are not alone and that it&#8217;s ok to ask for help. Miller explains how seeing a counselor four times a year helps him maintain his mental health. We also discuss coping mechanisms that might work for those not interested in seeing a counselor.</p>
<p>For more background on this episode, I highly encourage you to <a href="http://wordpress.tv/2015/07/02/cory-miller-entrepreneurship-and-my-mental-health/">watch his presentation</a> at WordCamp Denver 2015, on mental health. Also, check out <a href="http://www.slideshare.net/corymiller303/the-emotional-roller-coaster-of-entrepreneurship-how-i-cope-7-years-in">his slides on slideshare</a> that are filled with motivational messages.</p>
<p>I apologize for the audio quality in this episode. Miller was in New Mexico on a spotty WiFi connection that seemed to get worse as the show went on.</p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="https://wordpress.org/plugins/save-import-image-from-url/">Save and Import Image from URL</a> replaces the built-in &#8216;Import from URL&#8217; media upload tab. It allows users to download an image from a remote URL and upload it to the WordPress media gallery.</p>
<p class="shortdesc"><a href="https://wordpress.org/plugins/meerkat/">Meerkat</a> lets you embed your Meerkat stream on your site so your followers, friends, and fans can watch your stream anywhere.</p>
<p><a href="https://wordpress.org/plugins/simple-job-board/">Simple Job Board</a> is an easy and lightweight plugin that adds a job board to your website.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, July 15th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #198:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Jul 2015 22:01:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: SocialCrumbs: A Free WordPress Theme that Streams Social Activity Using IFTTT Recipes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46448";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://wptavern.com/socialcrumbs-a-free-wordpress-theme-that-streams-social-activity-using-ifttt-recipes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3949:"<p>With all of the content an average user generates across social media sites, it can be challenging to get a full view of all that activity. Let&#8217;s face it, your social media posts are scattered all over the web.</p>
<p><a href="https://github.com/ademilter/socialcrumbs" target="_blank">SocialCrumbs</a> is a non-traditional, niche WordPress theme that aggregates all of your social media activity into one stream with the help of <a href="https://ifttt.com/" target="_blank">IFTTT</a> recipes. The theme was created by <a href="http://ademilter.com/" target="_blank">Adam Ilter</a>, a user interface designer and developer living in Istanbul. He designed a Pinterest-style display to output the social posts brought in by IFTTT. The masonry grid is responsive and colorful with posts featuring icons for each social network.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/socialcrumbs-screenshot.jpg"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/socialcrumbs-screenshot.jpg?resize=1025%2C745" alt="socialcrumbs-screenshot" class="aligncenter size-full wp-image-46451" /></a></p>
<p>You can view a live demo of SocialCrumbs at <a href="http://adem.social/" target="_blank">adem.social</a>.</p>
<p>In order to use the theme, you need to sign up for IFTTT and set up recipes for all the social accounts you want to include in the stream. The theme&#8217;s readme.txt files includes a list of 19 <a href="https://github.com/ademilter/socialcrumbs#recipes" target="_blank">recipes</a> that Ilter has pre-configured, with a checklist of many more planned.</p>
<p>Certain networks have multiple options. For example, you can choose to include Twitter tweets and/or favorites:</p>
<ul>
<li>twitter-tweet-write <a href="https://ifttt.com/recipes/189363" target="_blank">https://ifttt.com/recipes/189363</a></li>
<li>twitter-tweet-favorite <a href="https://ifttt.com/recipes/189331" target="_blank">https://ifttt.com/recipes/189331</a></li>
</ul>
<p>It can take up to 15 minutes for the content to appear in your theme after posting to the social network, as most IFTTT recipes check for new trigger data at that interval.</p>
<p>It&#8217;s important to note that this theme is hosted on GitHub, not officially supported, and is an example of a fun, experimental concept that relies on IFTTT. As such, it doesn&#8217;t includes a single post template but rather outputs as an index. SocialCrumbs is not yet capable of providing a comprehensive archive for social media posts, so it&#8217;s not a theme you would use if you intend to record all of your social activities for preservation.</p>
<p>One might argue that this kind of functionality is better housed in a plugin. In that case you might want to take a look at the <a href="https://wordpress.org/plugins/social-streams/" target="_blank">Social Streams</a> or <a href="https://wordpress.org/plugins/wp-social-stream/" target="_blank">WP Social Stream</a> plugins on WordPress.org. WP Social Stream is based on <a href="https://github.com/christianv/jquery-lifestream" target="_blank">jQuery Lifestream</a>, as opposed to IFTTT. The methods of retrieving social posts vary from plugin to plugin, depending on how you want to fetch, display, and store that content.</p>
<p>The most ideal use for the SocialCrumbs theme would be where you dedicate a subsite to its display, i.e. for showing social media posts surrounding an event or brand. If it was forked to include the ability to make the social media content searchable and sortable, SocialCrumbs would be even more useful beyond a simple visual display of activities.</p>
<p>In its current state, the theme is a nice example of IFTTT and WordPress working together to create a configurable social stream that aggregates activity from multiple networks to a single page of your WordPress site. Check it out on <a href="https://github.com/ademilter/socialcrumbs" target="_blank">GitHub</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Jul 2015 18:31:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: Paired Opposites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45232";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2015/07/paired-opposites/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:517:"<blockquote><p>I used to think that paired opposites were a given, that love was the opposite of hate, right the opposite of wrong. But now I think we sometimes buy into these concepts because it is so much easier to embrace absolutes than to suffer reality. I don&#8217;t think anything is the opposite of love. Reality is unforgivingly complex.</p>
<p>&#8212; Anne Lamott</p></blockquote>
<p>From her great book <a href="http://www.amazon.com/Bird-Some-Instructions-Writing-Life/dp/0385480016">Bird by Bird</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Jul 2015 14:58:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: Chris Pearson Loses Cybersquatting Case Against Automattic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46365";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wptavern.com/automattic-wins-cybersquatting-case-against-chris-pearson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6258:"<p>First <a href="http://domainnamewire.com/2015/07/08/wordpress-wins-another-round-against-chris-pearson/">reported by Domain Name Wire</a>, Automattic has <a href="http://www.adrforum.com/domaindecisions/1613723.htm">won their <span class="_Tgc"> Uniform Domain-Name Dispute-Resolution Policy</span> (UDRP) case</a> against <a href="http://www.pearsonified.com/">Chris Pearson</a>. UDRP requests are<span class="_Tgc"> a process established by the Internet Corporation for Assigned Names and Numbers (ICANN) for the resolution of disputes regarding the registration of internet domain names. </span></p>
<h2>Automattic Wins Thesis.com</h2>
<p>According to <a href="http://www.adrforum.com/domaindecisions/1613723.htm">findings by the UDRP panel</a>, in late 2014, a third-party who owned <a href="http://themeshaper.com/">Thesis.com</a> approached Automattic and Pearson to see if they were interested in buying the domain. Automattic won the domain by bidding $100K.</p>
<p>Soon after winning the domain, Pearson filed a UDRP request with ICANN seeking relief requesting that the domain name be transferred from Automattic to himself. In June 2015, a three-member panel was appointed to review the case.</p>
<p>According to <a href="https://www.icann.org/resources/pages/rules-be-2012-02-25-en">rule number five</a> set forth by ICANN for the UDRP process, Respondents have 20 days to respond to the Provider. If a Respondent does not submit a response, in the absence of exceptional circumstances, the Panel decides the dispute based upon the complaint.</p>
<p>In a controversial move, the Panel accepted and reviewed Automattic&#8217;s late response.</p>
<blockquote><p>The Panel notes that Respondent failed to submit its response within the requisite time period, failing to comply with ICANN Rule #5.  In its discretion, the Panel considered Respondent’s arguments in the late filed Response in the interest of justice.</p></blockquote>
<p>Pearson satisfied two of the three burdens imposed under the Policy in order for the Panel to order transfer of a domain name from the entity registering it. Pearson failed to provide evidence that showed Thesis.com redirects to Themeshaper.com. In its response to the Panel, Automattic admitted to using the domain in this way but it appears to have had no affect on the Panel&#8217;s decision.</p>
<p>The Panel noted that if Complainant’s submissions are insufficient, it may request additional exhibits or information under Rule 12 but given the outcome, the Panel chose not to seek additional submissions.</p>
<p>You can view the panel&#8217;s findings in <a href="http://www.adrforum.com/domaindecisions/1613723.htm">this public document.</a> The panel concluded that the Complainant (Pearson) failed to establish all three elements required under the ICANN Policy and that relief shall be denied.</p>
<blockquote><p>A party must satisfy all three of the burdens imposed under the Policy in order for the Panel to order transfer of a domain name from the entity registering it. Here, Complainant failed to establish that Respondent registered and used the disputed domain name in bad faith.</p>
<p><em>See Starwood Hotels &amp; Resorts Worldwide, Inc. v. Samjo CellTech.Ltd</em>, FA 406512 (Nat. Arb. Forum Mar. 9, 2005) (finding that the complainant failed to establish that respondent registered and used the disputed domain name in bad faith because mere assertions of bad faith are insufficient for a complainant to establish Policy ¶ 4(a)(iii)). Therefore, the Panel finds that Complainant failed to support its allegations under Policy ¶ 4(a)(iii) and finds for Respondent.</p></blockquote>
<p>Therefore, Thesis.com is allowed to remain under Automattic&#8217;s ownership.</p>
<h2>Automattic Strikes Back</h2>
<p>On June 16th, Automattic struck back by <a href="http://ttabvue.uspto.gov/ttabvue/v?pno=92061714&pty=CAN&eno=1">filing a petition for cancellation</a> with the United States Patent and Trademark Office. In their petition, Automattic argues that the three trademarks owned by Pearson, DIYTHEMES, THESIS THEME, and THESIS, should be cancelled.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/PetitionForCancellation.png"><img class="size-full wp-image-46431" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/PetitionForCancellation.png?resize=704%2C721" alt="Petition for Cancellation" /></a>Petition for Cancellation
<p>When questioned about the Thesis.com domain and petition to cancel Perason&#8217;s trademarks, Automattic responded with the following statement:</p>
<blockquote><p>Chris Pearson tried to seize a domain Automattic owns through the UDRP process. As part of defending ourselves we have dug into the trademarks that were being claimed by the aggressor, as that was the basis of his claim.</p>
<p>We&#8217;re happy the panel ruled in our favor. We think Thesis.com is a cool, generic .com that could be used for a variety of things. Just because you have a small WordPress theme doesn&#8217;t mean you have a right to seize generic English word .com domains.</p></blockquote>
<p>I&#8217;ve reached out to Pearson for comment but have yet to receive a response.</p>
<h2>Automattic&#8217;s Interest in Thesis.com Remains Unexplained</h2>
<p>There are a lot of unanswered questions that need to be answered. For instance, why did Automattic participate in the bidding process for Thesis.com when it has nothing to do with WordPress.com or associated services?</p>
<p>The turbulent history between <a href="http://wordpress.tv/2010/07/15/mixergy-interview-pearson-mullenweg/">Matt Mullenweg and Pearson in 2010</a> nearly resulted in a lawsuit over GPLv2 compliance. The statement from Automattic fails to clarify why the company pursued Pearson again years later by bidding on a domain relevant to his business, apart from stating that it&#8217;s &#8220;a cool generic.com&#8221;. Going after Pearson&#8217;s trademarks in order to have them cancelled raises questions as to whether the move is motivated by retribution.</p>
<p>We&#8217;ll keep a close eye on the <a href="http://ttabvue.uspto.gov/ttabvue/v?pno=92061714&pty=CAN&eno=1">trademark cancellation petition</a> and if there are any updates, we&#8217;ll let you know.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 10 Jul 2015 04:40:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:96:"WPTavern: PhpStorm 9 Introduces Partial PHP 7 Support, Inline Debugging, and Remote File Editing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46327";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://wptavern.com/phpstorm-9-introduces-partial-php-7-support-inline-debugging-and-remote-file-editing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3006:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/introduce_parameter.png"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/introduce_parameter.png?resize=1025%2C513" alt="New in PhpStorm 9: Introduce parameter refactoring" class="size-full wp-image-46421" /></a>New in PhpStorm 9: <em>Introduce parameter</em> refactoring
<p><a href="http://www.jetbrains.com/phpstorm/whatsnew/" target="_blank">PhpStorm 9</a> was released this week with a slew of improvements and new features for PHP and web developers. The popular IDE is used by more than 300,000 developers and its development team usually puts out one major release per year. <a href="http://wptavern.com/phpstorm-8-released-with-full-wordpress-support" target="_blank">Version 8</a> was released last September with official support for WordPress.</p>
<p>Highlights of version 9 include:</p>
<ul>
<li>PHP Language &#038; Editing Experience: Includes <a href="http://blog.jetbrains.com/phpstorm/2015/05/postfix-code-completion-for-php-in-phpstorm-9-eap/" target="_blank">postfix code completion for PHP</a>, partial PHP 7 support, advanced code understanding, and other enhancements</li>
<li>New Debugging Experience: <a href="http://blog.jetbrains.com/phpstorm/2015/03/inline-debugging-for-php-in-phpstorm-9-eap/" target="_blank">Inline debugger</a> for PHP and <a href="http://blog.jetbrains.com/phpstorm/2015/07/debugging-improvements-in-phpstorm-9/" target="_blank">debugging workflow enhancements</a></li>
<li>Remote Development: <a href="http://blog.jetbrains.com/phpstorm/2015/04/remote-edit-in-phpstorm-9-eap/" target="_blank">Remote edit</a>, PHP Code Sniffer and Mess Detector via remote PHP interpreters</li>
<li>Many improvements related to frameworks and tools</li>
<li>A range of new and updated third-party plugins available in the <a href="https://plugins.jetbrains.com/phpStorm" target="_blank">PhpStorm plugin repository</a></li>
</ul>
<p>The new <a href="http://blog.jetbrains.com/phpstorm/2015/03/inline-debugging-for-php-in-phpstorm-9-eap/" target="_blank">inline debugging</a> feature is already a hit with WordPress developers. It lets you view variable values in the source code, next to their usages, without having to switch over to the Variables pane or Debug tool window.</p>
<blockquote class="twitter-tweet" width="550"><p lang="en" dir="ltr">Pretty much in love with <a href="https://twitter.com/phpstorm">@phpstorm</a> 9\'s inline debugging h/t <a href="https://twitter.com/jeremyfelt">@jeremyfelt</a></p>
<p>&mdash; Zack Tollman (@tollmanz) <a href="https://twitter.com/tollmanz/status/618905116326805504">July 8, 2015</a></p></blockquote>
<p></p>
<p>Auto-recognition of <a href="https://youtrack.jetbrains.com/issue/WI-21339" target="_blank">common WordPress global variables</a> (global variable => classname) is also included in the latest release.</p>
<p>Check out the version 9 tour video to see some of the new features in action:</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 09 Jul 2015 22:33:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Edit WordPress Email Templates in the Customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=46394";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wptavern.com/edit-wordpress-email-templates-in-the-customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3806:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/02/mailboxes.jpg"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/02/mailboxes.jpg?resize=1024%2C496" alt="mailboxes" class="aligncenter size-full wp-image-39214" /></a></p>
<p>Argentinian WordPress developer <a href="https://wp.timersys.com/" target="_blank">Damian Logghe</a> had never touched the <a href="https://codex.wordpress.org/Theme_Customization_API" target="_blank">Customizer API</a>, but with all the controversy swirling around it, he decided to jump in to see what all the fuss was about.</p>
<p>&#8220;The customizer has been making a lot of noise lately, as we all know, bringing politics to WordPress, and by politics I mean people arguing but getting nowhere,&#8221; he said.</p>
<p>&#8220;As a plugin developer I never coded with the customizer and I only used it as a front end user. But at the latest <a href="https://buenosaires.wordcamp.org/2015/" target="_blank">WordCamp Buenos Aires</a>, <a href="https://twitter.com/eliorivero" target="_blank">Elio Rivero</a> spoke about using the customizer in plugins, and I decided to give it a try instead of entering into debate. And you know what? I loved it!&#8221;</p>
<p>Logghe was contracted to build a new WordPress site and was looking for an easy way to beautify WordPress&#8217; default emails. He thought that the customizer would be the best choice for the job. After a week of development, he created <a href="https://wordpress.org/plugins/email-templates/" target="_blank">Email Templates</a>, the first plugin to enhance WordPress email templates using the customizer.</p>
<p>Email Templates can be accessed under the Appearance menu. The plugin creates customizer panels for editing the template, email header, footer, and settings. It even includes the ability to send a test email.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/email-templates-panels.jpg"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/email-templates-panels.jpg?resize=1014%2C638" alt="email-templates-panels" class="aligncenter size-full wp-image-46399" /></a></p>
<p>Adding a logo to the top of your email template is as easy as uploading an image. You can also customize the alignment, background color, and header text. The plugin includes panels for changing the &#8220;from name&#8221; and &#8220;from email&#8221;, footer text, and basic template styles.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-templates-logo.jpg"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-templates-logo.jpg?resize=1025%2C643" alt="email-templates-logo" class="aligncenter size-full wp-image-46401" /></a></p>
<p>After you finish your customizations, you can fire off a test email to see how the new template looks in your inbox. I tested the plugin and found that it works as advertised. Ordinarily, customizing WordPress&#8217; default email template is not something your average user would attempt to do. The <a href="https://wordpress.org/plugins/email-templates/" target="_blank">Email Templates</a> plugin makes this accessible to anyone.</p>
<p>Building with the Customizer API has solidified Logghe&#8217;s belief in its potential for the future of WordPress. His example of live previewing email templates is a creative use of the API in the context of a plugin.</p>
<p>&#8220;In my opinion, the customizer is the right choice for every design change,&#8221; he said. &#8220;The API is extremely easy to use and previewing changes on the fly makes it awesome for every end user.</p>
<p>&#8220;It is just matter of time until the waters get calm and everyone migrates to it. In a year or so, editing your theme without the customizer is going to feel strange.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 09 Jul 2015 20:00:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Matt: 39 WordCamps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45228";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:34:"http://ma.tt/2015/07/39-wordcamps/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:220:"<p>There have been 39 WordCamps already so far this year, <a href="https://wordpress.org/news/2015/07/wordcamps-update/">here are a bunch more interesting stats about WordCamps including a list of upcoming ones.</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 09 Jul 2015 15:50:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Joseph: WordCamp SLC 2015";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://josephscott.org/?p=13154";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://josephscott.org/archives/2015/07/wordcamp-slc-2015/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1045:"<p><a href="https://slc.wordcamp.org/2015/">WordCamp Salt Lake City 2015</a> is coming September 12 at Washington Square ( 451 South State Street ).  <a href="https://slc.wordcamp.org/2015/tickets/">Tickets</a> are already on sale, only <a href="https://slc.wordcamp.org/2015/tickets/">$18 each</a>.  The <a href="https://slc.wordcamp.org/2015/attendees/">attendees page</a> has a list of some of the people who have already signed up.</p>
<p><a href="https://slc.wordcamp.org/2015/speakers/">Speakers</a> are being <a href="https://slc.wordcamp.org/2015/news/">announced on the news page</a>.  If you area interested in presenting fill out the <a href="https://slc.wordcamp.org/2015/07/01/call-for-speakers/">call for speakers form</a>.  We are also looking for <a href="https://slc.wordcamp.org/2015/07/01/call-for-volunteers/">volunteers</a> and <a href="https://slc.wordcamp.org/2015/07/01/call-for-sponsors/">sponsors</a>.</p>
<div class="jetpack-video-wrapper"></div>
<p>Come learn and hang out with the local Utah WordPress community.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 09 Jul 2015 14:48:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Joseph Scott";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Mon, 27 Jul 2015 20:03:21 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"267516";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Mon, 27 Jul 2015 19:45:16 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wpLi_options` VALUES (299, '_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1438070603', 'no') ; 
INSERT INTO `wpLi_options` VALUES (300, '_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1438027403', 'no') ; 
INSERT INTO `wpLi_options` VALUES (301, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1438070605', 'no') ; 
INSERT INTO `wpLi_options` VALUES (302, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:117:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"WordPress Plugins » View: Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"https://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:34:"WordPress Plugins » View: Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 27 Jul 2015 19:55:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:30:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29860@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"23862@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:28:"Your WordPress, Streamlined.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"18101@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Google Analytics by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2316@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:124:"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"Yoast SEO";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"8321@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast&#039;s WordPress SEO plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Really Simple CAPTCHA";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/really-simple-captcha/#post-9542";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2009 02:17:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"9542@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2141@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2082@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"753@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WP Super Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2572@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"132@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Arne Brachhold";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-PageNavi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wp-pagenavi/#post-363";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 23:17:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"363@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:49:"Adds a more advanced paging navigation interface.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Lester Chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"1169@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 12 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Hello Dolly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/hello-dolly/#post-5790";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2008 22:11:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"5790@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"15@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Advanced Custom Fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/advanced-custom-fields/#post-25254";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Mar 2011 04:07:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"25254@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:68:"Customise WordPress with powerful, professional and intuitive fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"elliotcondon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29832@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/w3-total-cache/#post-12073";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2009 18:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"12073@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Regenerate Thumbnails";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/regenerate-thumbnails/#post-6743";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 23 Aug 2008 14:38:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"6743@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Allows you to regenerate your thumbnails after changing the thumbnail sizes.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:25:"Alex Mills (Viper007Bond)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Disable Comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wordpress.org/plugins/disable-comments/#post-26907";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 May 2011 04:42:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26907@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:134:"Allows administrators to globally disable comments on their site. Comments can be disabled according to post type. Multisite friendly.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Samir Shah";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WP Multibyte Patch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wp-multibyte-patch/#post-28395";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Jul 2011 12:22:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"28395@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Multibyte functionality enhancement for the WordPress Japanese package.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"plugin-master";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Duplicate Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/duplicate-post/#post-2646";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 05 Dec 2007 17:40:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2646@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:22:"Clone posts and pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"lopo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"21738@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Black Studio TinyMCE Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Nov 2011 15:06:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"31973@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"The visual editor widget for Wordpress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marco Chiesi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Meta Slider";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/ml-slider/#post-49521";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Feb 2013 16:56:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"49521@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:145:"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Matcha Labs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Google Analytics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/plugins/googleanalytics/#post-11199";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 09 Jun 2009 22:09:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"11199@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:38:"Enables google analytics on all pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Kevin Sylvestre";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"WP-DB-Backup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/wp-db-backup/#post-472";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 17 Mar 2007 04:41:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"472@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:44:"On-demand backup of your WordPress database.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"ringmaster";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Page Builder by SiteOrigin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/siteorigin-panels/#post-51888";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Apr 2013 10:36:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"51888@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:111:"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Greg Priday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"50539@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:127:"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"Duplicator";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/duplicator/#post-26607";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 16 May 2011 12:15:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26607@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:88:"Duplicate, clone, backup, move and transfer an entire site from one location to another.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Cory Lamle";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"https://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:12:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Mon, 27 Jul 2015 20:03:25 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:25:"strict-transport-security";s:11:"max-age=360";s:7:"expires";s:29:"Mon, 27 Jul 2015 20:30:34 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Mon, 27 Jul 2015 19:55:34 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wpLi_options` VALUES (303, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1438070605', 'no') ; 
INSERT INTO `wpLi_options` VALUES (304, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1438027405', 'no') ; 
INSERT INTO `wpLi_options` VALUES (305, '_transient_timeout_plugin_slugs', '1438113805', 'no') ; 
INSERT INTO `wpLi_options` VALUES (306, '_transient_plugin_slugs', 'a:3:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:9:"hello.php";}', 'no') ; 
INSERT INTO `wpLi_options` VALUES (307, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1438070605', 'no') ; 
INSERT INTO `wpLi_options` VALUES (308, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2015/07/wordpress-4-2-3/\'>WordPress 4.2.3 Security and Maintenance Release</a> <span class="rss-date">23-07-2015</span><div class="rssSummary">WordPress 4.2.3 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was initially reported by Jon Cave and [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://ma.tt/2015/07/mpaa-smoking-gun/\'>Matt: MPAA Smoking Gun</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/plugin-developers-demand-a-better-security-release-process-after-wordpress-4-2-3-breaks-thousands-of-websites\'>WPTavern: Plugin Developers Demand a Better Security Release Process After WordPress 4.2.3 Breaks Thousands of Websites</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/fooplugins-digital-license-key-management-plugin-is-now-open-source-for-developers\'>WPTavern: FooPlugin’s Digital License Key Management Plugin is Now Open Source for Developers</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'https://wordpress.org/plugins/ml-slider/\' class=\'dashboard-news-plugin-link\'>Meta Slider</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=ml-slider&amp;_wpnonce=55a4ab0e21&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Meta Slider\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wpLi_options` VALUES (313, '_transient_doing_cron', '1438039960.7265520095825195312500', 'yes') ;
#
# End of data contents of table wpLi_options
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_postmeta`
#

DROP TABLE IF EXISTS `wpLi_postmeta`;


#
# Table structure of table `wpLi_postmeta`
#

CREATE TABLE `wpLi_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_postmeta (31 records)
#
 
INSERT INTO `wpLi_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wpLi_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (3, 4, '_edit_lock', '1437836892:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (5, 6, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (6, 6, '_edit_lock', '1437836208:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (8, 8, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (9, 8, '_edit_lock', '1437836174:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (11, 10, '_wp_attached_file', '2015/07/SFS-Passamynd.jpg') ; 
INSERT INTO `wpLi_postmeta` VALUES (12, 10, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1518;s:6:"height";i:1518;s:4:"file";s:25:"2015/07/SFS-Passamynd.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"SFS-Passamynd-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"SFS-Passamynd-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"SFS-Passamynd-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:16;s:6:"credit";s:11:"Unspecified";s:6:"camera";s:21:"Canon EOS-1Ds Mark II";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1169819456;s:9:"copyright";s:11:"Unspecified";s:12:"focal_length";s:2:"70";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (15, 13, '_wp_attached_file', '2015/07/lilja-ingva.png') ; 
INSERT INTO `wpLi_postmeta` VALUES (16, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:208;s:6:"height";i:209;s:4:"file";s:23:"2015/07/lilja-ingva.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"lilja-ingva-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (18, 15, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (19, 15, '_edit_lock', '1437836664:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (21, 18, '_wp_attached_file', '2015/07/auga.jpg') ; 
INSERT INTO `wpLi_postmeta` VALUES (22, 18, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:272;s:6:"height";i:272;s:4:"file";s:16:"2015/07/auga.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"auga-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:16;s:6:"credit";s:11:"Unspecified";s:6:"camera";s:21:"Canon EOS-1Ds Mark II";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1169819456;s:9:"copyright";s:11:"Unspecified";s:12:"focal_length";s:2:"70";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (24, 15, '_wp_old_slug', 'joi-spo-spiturass') ; 
INSERT INTO `wpLi_postmeta` VALUES (27, 20, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (28, 20, '_edit_lock', '1437839430:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (29, 21, '_wp_attached_file', '2015/07/nebbi.jpg') ; 
INSERT INTO `wpLi_postmeta` VALUES (30, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:282;s:6:"height";i:282;s:4:"file";s:17:"2015/07/nebbi.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nebbi-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:11:"Unspecified";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (32, 23, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (33, 23, '_edit_lock', '1438029412:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (35, 25, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (36, 25, '_edit_lock', '1437918627:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (37, 25, '_wp_page_template', 'umsagnir.php') ; 
INSERT INTO `wpLi_postmeta` VALUES (40, 31, '_wp_attached_file', '2015/07/lilja2009.jpg') ; 
INSERT INTO `wpLi_postmeta` VALUES (41, 31, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:148;s:6:"height";i:250;s:4:"file";s:21:"2015/07/lilja2009.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"lilja2009-148x150.jpg";s:5:"width";i:148;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (42, 32, '_wp_attached_file', '2015/07/lilja2013.jpg') ; 
INSERT INTO `wpLi_postmeta` VALUES (43, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:167;s:6:"height";i:250;s:4:"file";s:21:"2015/07/lilja2013.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"lilja2013-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (44, 31, '_wp_attachment_image_alt', 'Þessi mynd er tekin í mars 2009') ; 
INSERT INTO `wpLi_postmeta` VALUES (45, 32, '_wp_attachment_image_alt', 'Mynd tekin um páskana árið 2013') ;
#
# End of data contents of table wpLi_postmeta
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_posts`
#

DROP TABLE IF EXISTS `wpLi_posts`;


#
# Table structure of table `wpLi_posts`
#

CREATE TABLE `wpLi_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_posts (33 records)
#
 
INSERT INTO `wpLi_posts` VALUES (1, 1, '2015-07-10 17:16:32', '2015-07-10 17:16:32', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2015-07-10 17:16:32', '2015-07-10 17:16:32', '', 0, 'http://localhost/liljaingva/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wpLi_posts` VALUES (2, 1, '2015-07-10 17:16:32', '2015-07-10 17:16:32', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost/liljaingva/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2015-07-10 17:16:32', '2015-07-10 17:16:32', '', 0, 'http://localhost/liljaingva/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (4, 1, '2015-07-25 08:57:57', '2015-07-25 08:57:57', '<h4>með vel skipulögðum markmiðum</h4>
Í þjálfun hjá mér færðu framúrskarandi þjónus45 tu og árangur. Ég legg metna 75 ð minn í að fylgja þér eftir svo þú náir hámarks árangri miðað við raunhæf markmið sem við setjum saman handa þér.

<strong>Innifalið í einkaþjálfun hjá mér er eftirfarandi:</strong>
<ul>
	<li>Líkamstöðu og ástandsgreining</li>
	<li>Mælingar á 4 vikna fresti</li>
	<li>Markmiðasetning</li>
	<li>Dagleg matardagbók og ráðgjöf, orkuþörf og áætlun</li>
	<li>55 mín þjálfunartími í sal - Einstaklingsmiðuð æfingaáætlun</li>
	<li>Eftirfylgni</li>
</ul>
<h3>Þú nærð árangri hjá mér!</h3>', 'Pottþéttur árangur', '', 'publish', 'open', 'open', '', 'pottthettur-arangur', '', '', '2015-07-25 15:08:12', '2015-07-25 15:08:12', '', 0, 'http://localhost/liljaingva/?p=4', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (5, 1, '2015-07-25 08:57:57', '2015-07-25 08:57:57', '<h4>með vel skipulögðum markmiðum</h4>
Í þjálfun hjá mér færðu framúrskarandi þjónus45 tu og árangur. Ég legg metna 75 ð minn í að fylgja þér eftir svo þú náir hámarks árangri miðað við raunhæf markmið sem við setjum saman handa þér.

<strong>Innifalið í einkaþjálfun hjá mér er eftirfarandi:</strong>
<ul>
	<li>Líkamstöðu og ástandsgreining</li>
	<li>Mælingar á 4 vikna fresti</li>
	<li>Markmiðasetning</li>
	<li>Dagleg matardagbók og ráðgjöf, orkuþörf og áætlun</li>
	<li>55 mín þjálfunartími í sal - Einstaklingsmiðuð æfingaáætlun</li>
	<li>Eftirfylgni</li>
</ul>
<h3>Þú nærð árangri hjá mér!</h3>', 'Pottþéttur árangur', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2015-07-25 08:57:57', '2015-07-25 08:57:57', '', 4, 'http://localhost/liljaingva/2015/07/25/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (6, 1, '2015-07-25 11:50:35', '2015-07-25 11:50:35', '<img class="alignnone size-medium wp-image-10" src="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd-300x300.jpg" alt="SFS-Passamynd" width="300" height="300" />Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Steingrímur Fannar', '', 'publish', 'open', 'open', '', 'steingrimur-fannar', '', '', '2015-07-25 12:02:36', '2015-07-25 12:02:36', '', 0, 'http://localhost/liljaingva/?p=6', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (7, 1, '2015-07-25 11:50:35', '2015-07-25 11:50:35', 'Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Steingrímur Fannar', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2015-07-25 11:50:35', '2015-07-25 11:50:35', '', 6, 'http://localhost/liljaingva/2015/07/25/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (8, 1, '2015-07-25 11:51:48', '2015-07-25 11:51:48', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png"><img class="alignnone size-full wp-image-13" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png" alt="lilja-ingva" width="208" height="209" /></a>In a professional context it often happens that private or corporate clients corder a publication to be made and presented with the actual content still not being ready. Think of a news blog that\'s filled with content hourly on the day of going live. However, reviewers tend to be distracted by comprehensible content, say, a random text copied from a newspaper or the internet. The are likely to focus on the text, disregarding the layout and its elements. Besides, random text risks to be unintendedly humorous or offensive, an unacceptable risk in corporate environments. <strong>Lorem ipsum</strong> and its many variants have been employed since the early 1960ies, and quite likely since the sixteenth century.', 'Lilja Ingva', '', 'publish', 'open', 'open', '', 'lilja-ingva', '', '', '2015-07-25 14:55:55', '2015-07-25 14:55:55', '', 0, 'http://localhost/liljaingva/?p=8', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (9, 1, '2015-07-25 11:51:48', '2015-07-25 11:51:48', 'In a professional context it often happens that private or corporate clients corder a publication to be made and presented with the actual content still not being ready. Think of a news blog that\'s filled with content hourly on the day of going live. However, reviewers tend to be distracted by comprehensible content, say, a random text copied from a newspaper or the internet. The are likely to focus on the text, disregarding the layout and its elements. Besides, random text risks to be unintendedly humorous or offensive, an unacceptable risk in corporate environments. <strong>Lorem ipsum</strong> and its many variants have been employed since the early 1960ies, and quite likely since the sixteenth century.', 'Lilja Ingva', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2015-07-25 11:51:48', '2015-07-25 11:51:48', '', 8, 'http://localhost/liljaingva/2015/07/25/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (10, 1, '2015-07-25 12:01:54', '2015-07-25 12:01:54', '', 'SFS-Passamynd', '', 'inherit', 'open', 'open', '', 'sfs-passamynd', '', '', '2015-07-25 12:01:54', '2015-07-25 12:01:54', '', 6, 'http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wpLi_posts` VALUES (11, 1, '2015-07-25 12:01:59', '2015-07-25 12:01:59', 'Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd.jpg"><img class="alignnone size-medium wp-image-10" src="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd-300x300.jpg" alt="SFS-Passamynd" width="300" height="300" /></a>', 'Steingrímur Fannar', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2015-07-25 12:01:59', '2015-07-25 12:01:59', '', 6, 'http://localhost/liljaingva/2015/07/25/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (12, 1, '2015-07-25 12:02:36', '2015-07-25 12:02:36', '<img class="alignnone size-medium wp-image-10" src="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd-300x300.jpg" alt="SFS-Passamynd" width="300" height="300" />Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Steingrímur Fannar', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2015-07-25 12:02:36', '2015-07-25 12:02:36', '', 6, 'http://localhost/liljaingva/2015/07/25/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (13, 1, '2015-07-25 14:55:49', '2015-07-25 14:55:49', '', 'lilja-ingva', '', 'inherit', 'open', 'open', '', 'lilja-ingva-2', '', '', '2015-07-25 14:55:49', '2015-07-25 14:55:49', '', 8, 'http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wpLi_posts` VALUES (14, 1, '2015-07-25 14:55:55', '2015-07-25 14:55:55', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png"><img class="alignnone size-full wp-image-13" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png" alt="lilja-ingva" width="208" height="209" /></a>In a professional context it often happens that private or corporate clients corder a publication to be made and presented with the actual content still not being ready. Think of a news blog that\'s filled with content hourly on the day of going live. However, reviewers tend to be distracted by comprehensible content, say, a random text copied from a newspaper or the internet. The are likely to focus on the text, disregarding the layout and its elements. Besides, random text risks to be unintendedly humorous or offensive, an unacceptable risk in corporate environments. <strong>Lorem ipsum</strong> and its many variants have been employed since the early 1960ies, and quite likely since the sixteenth century.', 'Lilja Ingva', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2015-07-25 14:55:55', '2015-07-25 14:55:55', '', 8, 'http://localhost/liljaingva/2015/07/25/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (15, 1, '2015-07-25 14:59:28', '2015-07-25 14:59:28', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg"><img class="alignnone size-full wp-image-18" src="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg" alt="auga" width="272" height="272" /></a>Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Jói Spói spíturass', '', 'publish', 'open', 'open', '', 'joi-spoi-spiturass', '', '', '2015-07-25 15:05:00', '2015-07-25 15:05:00', '', 0, 'http://localhost/liljaingva/?p=15', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (16, 1, '2015-07-25 14:59:28', '2015-07-25 14:59:28', '<img class="alignnone size-medium wp-image-10" src="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd-300x300.jpg" alt="SFS-Passamynd" width="300" height="300" />Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Jói Spó spíturass', '', 'inherit', 'open', 'open', '', '15-revision-v1', '', '', '2015-07-25 14:59:28', '2015-07-25 14:59:28', '', 15, 'http://localhost/liljaingva/2015/07/25/15-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (17, 1, '2015-07-25 15:04:59', '2015-07-25 15:04:59', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg"><img class="alignnone size-full wp-image-18" src="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg" alt="auga" width="272" height="272" /></a>Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Jói Spói spíturass', '', 'inherit', 'open', 'open', '', '15-autosave-v1', '', '', '2015-07-25 15:04:59', '2015-07-25 15:04:59', '', 15, 'http://localhost/liljaingva/2015/07/25/15-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (18, 1, '2015-07-25 15:04:54', '2015-07-25 15:04:54', '', 'auga', '', 'inherit', 'open', 'open', '', 'auga', '', '', '2015-07-25 15:04:54', '2015-07-25 15:04:54', '', 15, 'http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wpLi_posts` VALUES (19, 1, '2015-07-25 15:05:00', '2015-07-25 15:05:00', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg"><img class="alignnone size-full wp-image-18" src="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg" alt="auga" width="272" height="272" /></a>Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Jói Spói spíturass', '', 'inherit', 'open', 'open', '', '15-revision-v1', '', '', '2015-07-25 15:05:00', '2015-07-25 15:05:00', '', 15, 'http://localhost/liljaingva/2015/07/25/15-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (20, 1, '2015-07-25 15:13:11', '2015-07-25 15:13:11', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg"><img class="alignnone size-full wp-image-21" src="http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg" alt="nebbi" width="282" height="282" /></a>dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do', 'Nebbi Nebbason', '', 'publish', 'open', 'open', '', 'nebbi-nebbason', '', '', '2015-07-25 15:13:11', '2015-07-25 15:13:11', '', 0, 'http://localhost/liljaingva/?p=20', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (21, 1, '2015-07-25 15:13:01', '2015-07-25 15:13:01', '', 'nebbi', '', 'inherit', 'open', 'open', '', 'nebbi', '', '', '2015-07-25 15:13:01', '2015-07-25 15:13:01', '', 20, 'http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wpLi_posts` VALUES (22, 1, '2015-07-25 15:13:11', '2015-07-25 15:13:11', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg"><img class="alignnone size-full wp-image-21" src="http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg" alt="nebbi" width="282" height="282" /></a>dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do', 'Nebbi Nebbason', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2015-07-25 15:13:11', '2015-07-25 15:13:11', '', 20, 'http://localhost/liljaingva/2015/07/25/20-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (23, 1, '2015-07-25 15:53:26', '2015-07-25 15:53:26', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2009.jpg"><img class="alignleft wp-image-31 size-thumbnail" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2009-148x150.jpg" alt="Þessi mynd er tekin í mars 2009" width="148" height="150" /></a>Meðfylgjandi myndir eru teknar í lok mars 2009 og svo fjórum árum síðar eða um páskana árið 2013 þegar ég steig á svið í minni fyrstu fitnesskeppni.

Fljótlega eftir að fyrri myndin var tekin tók ég skrefið og hóf að breyta um lífsstíl fyrir bætta heilsu. Ég var þarna allt of þung, illt í liðum og þreytt á eigin ástandi. Markmiðasetning var eitt af þeim tólum sem ég notaði mikið. Alltaf ný markmið og eitt af markmiðunum sem ég setti mér þegar ég var komin vel af stað var að fara á svið í fitnesskeppni sem ég náði að uppfylla um páskana árið 2013. Á mínu ferðalagi hef ég unnið marga persónulega sigra sem mig hafði ekki einu sinni dreymt um og keppt tvisvar í fitness.

&nbsp;

Það er allt hægt með viljanum, þolinmæði og án öfga. Ég náði þessum árangri hægt og bítandi. Fór aldrei framúr sjálfri mér. Hér voru engar skyndilausnir. Eingöngu gott matarræði og hreyfing sem beindist að mínum markmiðum og því sem mér fannst skemmtilegt. Það var aldrei svo að mér fannst þetta erfitt né leiðinlegt. Er svo glöð að hafa uppgötvað og fundið mig í þessum frábæra lífsstíl!!

<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2013.jpg"><img class=" size-thumbnail wp-image-32 alignright" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2013-150x150.jpg" alt="Mynd tekin um páskana árið 2013" width="150" height="150" /></a>Nú er markmið mitt að hjálpa fólki að tileinka sér betri lífsstíl án öfga sem bætir lífsgæði, andlega og líkamlega heilsu til f<span class="text_exposed_show">rambúðar.
</span>

<span class="text_exposed_show">Eftir algera lífstílsbreytingu sem hófst 2009 hjá mér þá fór ég í IAK Einkaþjálfaranám hjá Keili 2014/15 einmitt til að geta hjálpað öðru fólki að breita um lífsstíl fyrir bætt lífsgæði. Það er allt hægt ef viljinn og trúin á sjálfan sig er fyrir hendi - og þar ætla ég svo sannarlega að standa fyrir því og hjálpa ÞÉR að ná þínum markmiðum!</span>

&nbsp;', 'Ferðalagið mitt', '', 'publish', 'open', 'open', '', 'ferdalagid-mitt', '', '', '2015-07-27 20:36:51', '2015-07-27 20:36:51', '', 0, 'http://localhost/liljaingva/?p=23', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (24, 1, '2015-07-25 15:53:26', '2015-07-25 15:53:26', 'Árangursmyndir frá því rétt áður en ég tók mig taki í lok mars 2009 og brey 70 tti mínum lífstíl til frambúðar. 2013 um páska - 4 árum síðar var ég mætt á sviðið og keppti í fitness - sem var enn eitt markmið sem ég setti mér og náði. Hefði aldrei dreymt um það þegar ég stóð þarna í svarta kjólnum, of þung, illt í liðum og þreytt á eigin ástandi. Það er allt hægt með viljanum, þolinmæði og án öfga.

Ég náði þessum árangri hægt og bítandi. Fór aldrei framúr sjálfum mér. Hér voru engar skyndilausnir, eingöngu gott matarræði ávallt og hreyfing sem beindist að mínum markmiðum og því sem mér fannst skemmtilegt. Það var aldrei svo að mér fannst þetta erfitt né leiðinlegt. Er svo glöð að hafa uppgötvað og fundið mig í þessum frábæra lífstil!!', 'Ferðalagið mitt', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-07-25 15:53:26', '2015-07-25 15:53:26', '', 23, 'http://localhost/liljaingva/2015/07/25/23-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (25, 1, '2015-07-25 21:25:18', '2015-07-25 21:25:18', '', 'Umsagnir', '', 'publish', 'open', 'open', '', 'umsagnir', '', '', '2015-07-25 21:25:18', '2015-07-25 21:25:18', '', 0, 'http://localhost/liljaingva/?page_id=25', 0, 'page', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (26, 1, '2015-07-25 21:25:18', '2015-07-25 21:25:18', '', 'Umsagnir', '', 'inherit', 'open', 'open', '', '25-revision-v1', '', '', '2015-07-25 21:25:18', '2015-07-25 21:25:18', '', 25, 'http://localhost/liljaingva/25-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (27, 1, '2015-07-27 20:03:16', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-07-27 20:03:16', '0000-00-00 00:00:00', '', 0, 'http://localhost/liljaingva/?p=27', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (28, 1, '2015-07-27 20:39:55', '2015-07-27 20:39:55', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2009.jpg"><img class="alignleft wp-image-31 size-thumbnail" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2009-148x150.jpg" alt="Þessi mynd er tekin í mars 2009" width="148" height="150" /></a>Meðfylgjandi myndir eru teknar í lok mars 2009 og svo fjórum árum síðar eða um páskana árið 2013 þegar ég steig á svið í minni fyrstu fitnesskeppni.

Fljótlega eftir að fyrri myndin var tekin tók ég skrefið og hóf að breyta um lífsstíl fyrir bætta heilsu. Ég var þarna allt of þung, illt í liðum og þreytt á eigin ástandi. Markmiðasetning var eitt af þeim tólum sem ég notaði mikið. Alltaf ný markmið og eitt af markmiðunum sem ég setti mér þegar ég var komin vel af stað var að fara á svið í fitnesskeppni sem ég náði að uppfylla um páskana árið 2013. Á mínu ferðalagi hef ég unnið marga persónulega sigra sem mig hafði ekki einu sinni dreymt um og keppt tvisvar í fitness.

&nbsp;

Það er allt hægt með viljanum, þolinmæði og án öfga. Ég náði þessum árangri hægt og bítandi. Fór aldrei framúr sjálfri mér. Hér voru engar skyndilausnir. Eingöngu gott matarræði og hreyfing sem beindist að mínum markmiðum og því sem mér fannst skemmtilegt. Það var aldrei svo að mér fannst þetta erfitt né leiðinlegt. Er svo glöð að hafa uppgötvað og fundið mig í þessum frábæra lífsstíl!!

<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2013.jpg"><img class=" size-thumbnail wp-image-32 alignright" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2013-150x150.jpg" alt="Mynd tekin um páskana árið 2013" width="150" height="150" /></a>Nú er markmið mitt að hjálpa fólki að tileinka sér betri lífsstíl án öfga sem bætir lífsgæði, andlega og líkamlega heilsu til f<span class="text_exposed_show">rambúðar.
</span>

<span class="text_exposed_show">Eftir algera lífstílsbreytingu sem hófst 2009 hjá mér þá fór ég í IAK Einkaþjálfaranám hjá Keili 2014/15 einmitt til að geta hjálpað öðru fólki að breita um lífsstíl fyrir bætt lífsgæði. Það er allt hægt ef viljinn og trúin á sjálfan sig er fyrir hendi - og þar ætla ég svo sannarlega að standa fyrir því og hjálpa ÞÉR að ná þínum markmiðum!</span>

&nbsp;', 'Ferðalagið mitt', '', 'inherit', 'open', 'open', '', '23-autosave-v1', '', '', '2015-07-27 20:39:55', '2015-07-27 20:39:55', '', 23, 'http://localhost/liljaingva/23-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (29, 1, '2015-07-27 20:25:04', '2015-07-27 20:25:04', 'Meðfylgjandi myndir eru teknar í lok mars 2009 og svo 4 árum síðar eða um páskana árið 2013 þegar ég steig á svið í minni fyrstu fitnesskeppni.

Fljótlega eftir að fyrri myndin var tekin tók ég skrefið og hóf að breyta um lífsstíl fyrir bætta heilsu. Ég var þarna allt of þung, illt í liðum og þreytt á eigin ástandi. Markmiðasetning var eitt af þeim tólum sem ég notaði mikið. Alltaf ný markmið og eitt af markmiðunum sem ég setti mér þegar ég var komin vel af stað var að fara á svið í fitnesskeppni sem ég náði að uppfylla um páskana árið 2013. Á mínu ferðalagi hef ég unnið marga persónulega sigra sem mig hafði ekki einu sinni dreymt um og keppt tvisvar í fitness.

Það er allt hægt með viljanum, þolinmæði og án öfga. Ég náði þessum árangri hægt og bítandi. Fór aldrei framúr sjálfri mér. Hér voru engar skyndilausnir. Eingöngu gott matarræði og hreyfing sem beindist að mínum markmiðum og því sem mér fannst skemmtilegt. Það var aldrei svo að mér fannst þetta erfitt né leiðinlegt. Er svo glöð að hafa uppgötvað og fundið mig í þessum frábæra lífsstíl!!

Nú er markmið mitt að hjálpa fólki að tileinka sér betri lífsstíl án öfga sem bætir lífsgæði, andlega og líkamlega heilsu til f<span class="text_exposed_show">rambúðar.
</span>

<span class="text_exposed_show">Eftir algera lífstílsbreytingu sem hófst 2009 hjá mér þá fór ég í IAK Einkaþjálfaranám hjá Keili 2014/15 einmitt til að geta hjálpað öðru fólki að breita um lífsstíl fyrir bætt lífsgæði. Það er allt hægt ef viljinn og trúin á sjálfan sig er fyrir hendi - og þar ætla ég svo sannarlega að standa fyrir því og hjálpa ÞÉR að ná þínum markmiðum!</span>

&nbsp;', 'Ferðalagið mitt', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-07-27 20:25:04', '2015-07-27 20:25:04', '', 23, 'http://localhost/liljaingva/23-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (30, 1, '2015-07-27 20:27:43', '2015-07-27 20:27:43', 'Meðfylgjandi myndir eru teknar í lok mars 2009 og svo fjórum árum síðar eða um páskana árið 2013 þegar ég steig á svið í minni fyrstu fitnesskeppni.

Fljótlega eftir að fyrri myndin var tekin tók ég skrefið og hóf að breyta um lífsstíl fyrir bætta heilsu. Ég var þarna allt of þung, illt í liðum og þreytt á eigin ástandi. Markmiðasetning var eitt af þeim tólum sem ég notaði mikið. Alltaf ný markmið og eitt af markmiðunum sem ég setti mér þegar ég var komin vel af stað var að fara á svið í fitnesskeppni sem ég náði að uppfylla um páskana árið 2013. Á mínu ferðalagi hef ég unnið marga persónulega sigra sem mig hafði ekki einu sinni dreymt um og keppt tvisvar í fitness.

Það er allt hægt með viljanum, þolinmæði og án öfga. Ég náði þessum árangri hægt og bítandi. Fór aldrei framúr sjálfri mér. Hér voru engar skyndilausnir. Eingöngu gott matarræði og hreyfing sem beindist að mínum markmiðum og því sem mér fannst skemmtilegt. Það var aldrei svo að mér fannst þetta erfitt né leiðinlegt. Er svo glöð að hafa uppgötvað og fundið mig í þessum frábæra lífsstíl!!

Nú er markmið mitt að hjálpa fólki að tileinka sér betri lífsstíl án öfga sem bætir lífsgæði, andlega og líkamlega heilsu til f<span class="text_exposed_show">rambúðar.
</span>

<span class="text_exposed_show">Eftir algera lífstílsbreytingu sem hófst 2009 hjá mér þá fór ég í IAK Einkaþjálfaranám hjá Keili 2014/15 einmitt til að geta hjálpað öðru fólki að breita um lífsstíl fyrir bætt lífsgæði. Það er allt hægt ef viljinn og trúin á sjálfan sig er fyrir hendi - og þar ætla ég svo sannarlega að standa fyrir því og hjálpa ÞÉR að ná þínum markmiðum!</span>

&nbsp;', 'Ferðalagið mitt', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-07-27 20:27:43', '2015-07-27 20:27:43', '', 23, 'http://localhost/liljaingva/23-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (31, 1, '2015-07-27 20:34:10', '2015-07-27 20:34:10', '', 'lilja2009', '', 'inherit', 'open', 'open', '', 'lilja2009', '', '', '2015-07-27 20:34:41', '2015-07-27 20:34:41', '', 23, 'http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2009.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wpLi_posts` VALUES (32, 1, '2015-07-27 20:34:11', '2015-07-27 20:34:11', '', 'lilja2013', '', 'inherit', 'open', 'open', '', 'lilja2013', '', '', '2015-07-27 20:34:56', '2015-07-27 20:34:56', '', 23, 'http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2013.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wpLi_posts` VALUES (33, 1, '2015-07-27 20:35:07', '2015-07-27 20:35:07', 'Meðfylgjandi myndir eru teknar í lok mars 2009 og svo fjórum árum síðar eða um páskana árið 2013 þegar ég steig á svið í minni fyrstu fitnesskeppni.

<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2009.jpg"><img class="alignleft size-full wp-image-31" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2009.jpg" alt="Þessi mynd er tekin í mars 2009" width="148" height="250" /></a>Fljótlega eftir að fyrri myndin var tekin tók ég skrefið og hóf að breyta um lífsstíl fyrir bætta heilsu. Ég var þarna allt of þung, illt í liðum og þreytt á eigin ástandi. Markmiðasetning var eitt af þeim tólum sem ég notaði mikið. Alltaf ný markmið og eitt af markmiðunum sem ég setti mér þegar ég var komin vel af stað var að fara á svið í fitnesskeppni sem ég náði að uppfylla um páskana árið 2013. Á mínu ferðalagi hef ég unnið marga persónulega sigra sem mig hafði ekki einu sinni dreymt um og keppt tvisvar í fitness.

&nbsp;

Það er allt hægt með viljanum, þolinmæði og án öfga. Ég náði þessum árangri hægt og bítandi. Fór aldrei framúr sjálfri mér. Hér voru engar skyndilausnir. Eingöngu gott matarræði og hreyfing sem beindist að mínum markmiðum og því sem mér fannst skemmtilegt. Það var aldrei svo að mér fannst þetta erfitt né leiðinlegt. Er svo glöð að hafa uppgötvað og fundið mig í þessum frábæra lífsstíl!!

Nú er markmið mitt að hjálpa fólki að tileinka sér betri lífsstíl án öfga sem bætir lífsgæði, andlega og líkamlega heilsu til f<span class="text_exposed_show">rambúðar.
</span>

<span class="text_exposed_show">Eftir algera lífstílsbreytingu sem hófst 2009 hjá mér þá fór ég í IAK Einkaþjálfaranám hjá Keili 2014/15 einmitt til að geta hjálpað öðru fólki að breita um lífsstíl fyrir bætt lífsgæði. Það er allt hægt ef viljinn og trúin á sjálfan sig er fyrir hendi - og þar ætla ég svo sannarlega að standa fyrir því og hjálpa ÞÉR að ná þínum markmiðum!</span>

&nbsp;', 'Ferðalagið mitt', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-07-27 20:35:07', '2015-07-27 20:35:07', '', 23, 'http://localhost/liljaingva/23-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (34, 1, '2015-07-27 20:36:51', '2015-07-27 20:36:51', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2009.jpg"><img class="alignleft wp-image-31 size-thumbnail" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2009-148x150.jpg" alt="Þessi mynd er tekin í mars 2009" width="148" height="150" /></a>Meðfylgjandi myndir eru teknar í lok mars 2009 og svo fjórum árum síðar eða um páskana árið 2013 þegar ég steig á svið í minni fyrstu fitnesskeppni.

Fljótlega eftir að fyrri myndin var tekin tók ég skrefið og hóf að breyta um lífsstíl fyrir bætta heilsu. Ég var þarna allt of þung, illt í liðum og þreytt á eigin ástandi. Markmiðasetning var eitt af þeim tólum sem ég notaði mikið. Alltaf ný markmið og eitt af markmiðunum sem ég setti mér þegar ég var komin vel af stað var að fara á svið í fitnesskeppni sem ég náði að uppfylla um páskana árið 2013. Á mínu ferðalagi hef ég unnið marga persónulega sigra sem mig hafði ekki einu sinni dreymt um og keppt tvisvar í fitness.

&nbsp;

Það er allt hægt með viljanum, þolinmæði og án öfga. Ég náði þessum árangri hægt og bítandi. Fór aldrei framúr sjálfri mér. Hér voru engar skyndilausnir. Eingöngu gott matarræði og hreyfing sem beindist að mínum markmiðum og því sem mér fannst skemmtilegt. Það var aldrei svo að mér fannst þetta erfitt né leiðinlegt. Er svo glöð að hafa uppgötvað og fundið mig í þessum frábæra lífsstíl!!

<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2013.jpg"><img class=" size-thumbnail wp-image-32 alignright" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja2013-150x150.jpg" alt="Mynd tekin um páskana árið 2013" width="150" height="150" /></a>Nú er markmið mitt að hjálpa fólki að tileinka sér betri lífsstíl án öfga sem bætir lífsgæði, andlega og líkamlega heilsu til f<span class="text_exposed_show">rambúðar.
</span>

<span class="text_exposed_show">Eftir algera lífstílsbreytingu sem hófst 2009 hjá mér þá fór ég í IAK Einkaþjálfaranám hjá Keili 2014/15 einmitt til að geta hjálpað öðru fólki að breita um lífsstíl fyrir bætt lífsgæði. Það er allt hægt ef viljinn og trúin á sjálfan sig er fyrir hendi - og þar ætla ég svo sannarlega að standa fyrir því og hjálpa ÞÉR að ná þínum markmiðum!</span>

&nbsp;', 'Ferðalagið mitt', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-07-27 20:36:51', '2015-07-27 20:36:51', '', 23, 'http://localhost/liljaingva/23-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wpLi_posts
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_term_relationships`
#

DROP TABLE IF EXISTS `wpLi_term_relationships`;


#
# Table structure of table `wpLi_term_relationships`
#

CREATE TABLE `wpLi_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_term_relationships (7 records)
#
 
INSERT INTO `wpLi_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (4, 1, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (8, 2, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (15, 2, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (20, 2, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (23, 1, 0) ;
#
# End of data contents of table wpLi_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_term_taxonomy`
#

DROP TABLE IF EXISTS `wpLi_term_taxonomy`;


#
# Table structure of table `wpLi_term_taxonomy`
#

CREATE TABLE `wpLi_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_term_taxonomy (2 records)
#
 
INSERT INTO `wpLi_term_taxonomy` VALUES (1, 1, 'category', '', 0, 3) ; 
INSERT INTO `wpLi_term_taxonomy` VALUES (2, 2, 'category', 'Setja póst í þennan hóp ef pósturinn er umsögn frá viðskiptavin', 0, 4) ;
#
# End of data contents of table wpLi_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_terms`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_terms`
#

DROP TABLE IF EXISTS `wpLi_terms`;


#
# Table structure of table `wpLi_terms`
#

CREATE TABLE `wpLi_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_terms (2 records)
#
 
INSERT INTO `wpLi_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wpLi_terms` VALUES (2, 'Umsagnir', 'umsagnir', 0) ;
#
# End of data contents of table wpLi_terms
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_usermeta`
#

DROP TABLE IF EXISTS `wpLi_usermeta`;


#
# Table structure of table `wpLi_usermeta`
#

CREATE TABLE `wpLi_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_usermeta (17 records)
#
 
INSERT INTO `wpLi_usermeta` VALUES (1, 1, 'nickname', 'liljan') ; 
INSERT INTO `wpLi_usermeta` VALUES (2, 1, 'first_name', '') ; 
INSERT INTO `wpLi_usermeta` VALUES (3, 1, 'last_name', '') ; 
INSERT INTO `wpLi_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wpLi_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wpLi_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wpLi_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wpLi_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wpLi_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wpLi_usermeta` VALUES (10, 1, 'wpLi_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wpLi_usermeta` VALUES (11, 1, 'wpLi_user_level', '10') ; 
INSERT INTO `wpLi_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw') ; 
INSERT INTO `wpLi_usermeta` VALUES (13, 1, 'default_password_nag', '') ; 
INSERT INTO `wpLi_usermeta` VALUES (14, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wpLi_usermeta` VALUES (16, 1, 'wpLi_dashboard_quick_press_last_post_id', '27') ; 
INSERT INTO `wpLi_usermeta` VALUES (17, 1, 'wpLi_user-settings', 'hidetb=1&editor=tinymce&libraryContent=browse&align=left&imgsize=thumbnail') ; 
INSERT INTO `wpLi_usermeta` VALUES (18, 1, 'wpLi_user-settings-time', '1438029407') ;
#
# End of data contents of table wpLi_usermeta
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Monday 27. July 2015 23:32 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_users`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_users`
#

DROP TABLE IF EXISTS `wpLi_users`;


#
# Table structure of table `wpLi_users`
#

CREATE TABLE `wpLi_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_users (1 records)
#
 
INSERT INTO `wpLi_users` VALUES (1, 'liljan', '$P$BlKQyW7tnJjZ6YAp4XPXyYHLlKc9Z91', 'liljan', 'steingrimur@740.is', '', '2015-07-10 17:16:31', '', 0, 'liljan') ;
#
# End of data contents of table wpLi_users
# --------------------------------------------------------

