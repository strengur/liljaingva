# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_commentmeta`
#

DROP TABLE IF EXISTS `wpLi_commentmeta`;


#
# Table structure of table `wpLi_commentmeta`
#

CREATE TABLE `wpLi_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_commentmeta (0 records)
#

#
# End of data contents of table wpLi_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_comments`
#

DROP TABLE IF EXISTS `wpLi_comments`;


#
# Table structure of table `wpLi_comments`
#

CREATE TABLE `wpLi_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_comments (1 records)
#
 
INSERT INTO `wpLi_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-07-10 17:16:32', '2015-07-10 17:16:32', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wpLi_comments
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_links`
#

DROP TABLE IF EXISTS `wpLi_links`;


#
# Table structure of table `wpLi_links`
#

CREATE TABLE `wpLi_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_links (0 records)
#

#
# End of data contents of table wpLi_links
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_options`
#

DROP TABLE IF EXISTS `wpLi_options`;


#
# Table structure of table `wpLi_options`
#

CREATE TABLE `wpLi_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=277 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_options (123 records)
#
 
INSERT INTO `wpLi_options` VALUES (1, 'siteurl', 'http://localhost/liljaingva', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (2, 'home', 'http://localhost/liljaingva', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (3, 'blogname', 'Lilja Ingva - ÍAK Einkaþjálfari', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (4, 'blogdescription', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (5, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (6, 'admin_email', 'steingrimur@740.is', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (7, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (8, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (9, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (10, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (11, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (12, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (13, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (14, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (15, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (16, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (17, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (18, 'default_category', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (19, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (20, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (21, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (23, 'date_format', 'd-m-Y', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (24, 'time_format', 'H:i', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (26, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (27, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (28, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (29, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (30, 'hack_file', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (31, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (32, 'moderation_keys', '', 'no') ; 
INSERT INTO `wpLi_options` VALUES (33, 'active_plugins', 'a:1:{i:0;s:35:"backupwordpress/backupwordpress.php";}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `wpLi_options` VALUES (41, 'template', 'liljaingva-theme', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (42, 'stylesheet', 'liljaingva-theme', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wpLi_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (49, 'db_version', '31536', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (52, 'blog_public', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (54, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (80, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wpLi_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (85, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (88, 'initial_db_version', '31535', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (89, 'wpLi_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (90, '_transient_random_seed', '99fcafd3386b6c9a5bb4d7d6065ad5a8', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (91, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (92, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (93, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (94, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (95, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (96, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (98, 'cron', 'a:7:{i:1437974193;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1437982920;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1437987323;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1438017439;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1438038000;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"7a3d3c0a2bc3decec2c0a68ef25aa23c";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:10:"1437088150";}s:8:"interval";i:86400;}}}i:1438484400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"5fc97bf18118d9765d16120a15b1f250";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:10:"1437088151";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (107, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1437948024;s:7:"checked";a:4:{s:16:"liljaingva-theme";s:3:"1.0";s:13:"twentyfifteen";s:3:"1.2";s:14:"twentyfourteen";s:3:"1.4";s:14:"twentythirteen";s:3:"1.5";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (132, '_transient_twentyfifteen_categories', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (133, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (134, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (135, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (137, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (140, 'current_theme', 'Webpage for liljaingva.com', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (141, 'theme_mods_liljaingva-theme', 'a:1:{i:0;b:0;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (142, 'theme_switched', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (143, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1436549353;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (176, 'recently_activated', 'a:1:{s:19:"akismet/akismet.php";i:1437088087;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (181, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1437948024;s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:3:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.1.3";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.1.3.zip";}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"3.2.6";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.3.2.6.zip";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (182, 'hmbkp_schedule_1437088150', 'a:7:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1437174000;s:11:"max_backups";i:7;s:5:"email";a:1:{s:5:"email";s:0:"";}s:14:"duration_total";i:20;s:16:"backup_run_count";i:4;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (183, 'hmbkp_schedule_1437088151', 'a:6:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1437274800;s:11:"max_backups";i:3;s:14:"duration_total";i:6;s:16:"backup_run_count";i:2;}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (184, 'hmbkp_plugin_version', '3.2.6', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (226, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (238, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (240, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.2.3.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.2.3.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.2.3-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.2.3-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.2.3";s:7:"version";s:5:"4.2.3";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1437948023;s:15:"version_checked";s:5:"4.2.3";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (242, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (243, '_site_transient_timeout_available_translations', '1437852977', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (244, '_site_transient_available_translations', 'a:59:{s:2:"ar";a:8:{s:8:"language";s:2:"ar";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-26 06:57:37";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/ar.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:2;s:3:"ara";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:2:"az";a:8:{s:8:"language";s:2:"az";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:11:"Azerbaijani";s:11:"native_name";s:16:"Azərbaycan dili";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/az.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:2;s:3:"aze";}s:7:"strings";a:1:{s:8:"continue";s:5:"Davam";}}s:5:"bg_BG";a:8:{s:8:"language";s:5:"bg_BG";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-27 06:36:25";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/bg_BG.zip";s:3:"iso";a:2:{i:1;s:2:"bg";i:2;s:3:"bul";}s:7:"strings";a:1:{s:8:"continue";s:22:"Продължение";}}s:5:"bs_BA";a:8:{s:8:"language";s:5:"bs_BA";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-08 17:43:43";s:12:"english_name";s:7:"Bosnian";s:11:"native_name";s:8:"Bosanski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/bs_BA.zip";s:3:"iso";a:2:{i:1;s:2:"bs";i:2;s:3:"bos";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:2:"ca";a:8:{s:8:"language";s:2:"ca";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/ca.zip";s:3:"iso";a:2:{i:1;s:2:"ca";i:2;s:3:"cat";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"cy";a:8:{s:8:"language";s:2:"cy";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-08 11:08:34";s:12:"english_name";s:5:"Welsh";s:11:"native_name";s:7:"Cymraeg";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/cy.zip";s:3:"iso";a:2:{i:1;s:2:"cy";i:2;s:3:"cym";}s:7:"strings";a:1:{s:8:"continue";s:6:"Parhau";}}s:5:"da_DK";a:8:{s:8:"language";s:5:"da_DK";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-06-03 00:26:43";s:12:"english_name";s:6:"Danish";s:11:"native_name";s:5:"Dansk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/da_DK.zip";s:3:"iso";a:2:{i:1;s:2:"da";i:2;s:3:"dan";}s:7:"strings";a:1:{s:8:"continue";s:12:"Forts&#230;t";}}s:5:"de_CH";a:8:{s:8:"language";s:5:"de_CH";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:20:"German (Switzerland)";s:11:"native_name";s:17:"Deutsch (Schweiz)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/de_CH.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:5:"de_DE";a:8:{s:8:"language";s:5:"de_DE";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-24 13:10:37";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/de_DE.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:12:"de_DE_formal";a:8:{s:8:"language";s:12:"de_DE_formal";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-24 13:33:41";s:12:"english_name";s:15:"German (Formal)";s:11:"native_name";s:13:"Deutsch (Sie)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/4.2.3/de_DE_formal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:2:"el";a:8:{s:8:"language";s:2:"el";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-24 12:08:43";s:12:"english_name";s:5:"Greek";s:11:"native_name";s:16:"Ελληνικά";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/el.zip";s:3:"iso";a:2:{i:1;s:2:"el";i:2;s:3:"ell";}s:7:"strings";a:1:{s:8:"continue";s:16:"Συνέχεια";}}s:5:"en_CA";a:8:{s:8:"language";s:5:"en_CA";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:16:"English (Canada)";s:11:"native_name";s:16:"English (Canada)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/en_CA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_GB";a:8:{s:8:"language";s:5:"en_GB";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/en_GB.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_AU";a:8:{s:8:"language";s:5:"en_AU";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:19:"English (Australia)";s:11:"native_name";s:19:"English (Australia)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/en_AU.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"eo";a:8:{s:8:"language";s:2:"eo";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:9:"Esperanto";s:11:"native_name";s:9:"Esperanto";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/eo.zip";s:3:"iso";a:2:{i:1;s:2:"eo";i:2;s:3:"epo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Daŭrigi";}}s:5:"es_MX";a:8:{s:8:"language";s:5:"es_MX";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/es_MX.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_ES";a:8:{s:8:"language";s:5:"es_ES";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/es_ES.zip";s:3:"iso";a:1:{i:1;s:2:"es";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_PE";a:8:{s:8:"language";s:5:"es_PE";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-04-25 13:39:01";s:12:"english_name";s:14:"Spanish (Peru)";s:11:"native_name";s:17:"Español de Perú";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/es_PE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CL";a:8:{s:8:"language";s:5:"es_CL";s:7:"version";s:3:"4.0";s:7:"updated";s:19:"2014-09-04 19:47:01";s:12:"english_name";s:15:"Spanish (Chile)";s:11:"native_name";s:17:"Español de Chile";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.0/es_CL.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"et";a:8:{s:8:"language";s:2:"et";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-05 20:09:08";s:12:"english_name";s:8:"Estonian";s:11:"native_name";s:5:"Eesti";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/et.zip";s:3:"iso";a:2:{i:1;s:2:"et";i:2;s:3:"est";}s:7:"strings";a:1:{s:8:"continue";s:6:"Jätka";}}s:2:"eu";a:8:{s:8:"language";s:2:"eu";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:6:"Basque";s:11:"native_name";s:7:"Euskara";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/eu.zip";s:3:"iso";a:2:{i:1;s:2:"eu";i:2;s:3:"eus";}s:7:"strings";a:1:{s:8:"continue";s:8:"Jarraitu";}}s:5:"fa_IR";a:8:{s:8:"language";s:5:"fa_IR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/fa_IR.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:2:"fi";a:8:{s:8:"language";s:2:"fi";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-15 10:49:37";s:12:"english_name";s:7:"Finnish";s:11:"native_name";s:5:"Suomi";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/fi.zip";s:3:"iso";a:2:{i:1;s:2:"fi";i:2;s:3:"fin";}s:7:"strings";a:1:{s:8:"continue";s:5:"Jatka";}}s:5:"fr_FR";a:8:{s:8:"language";s:5:"fr_FR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-10 14:16:27";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/fr_FR.zip";s:3:"iso";a:1:{i:1;s:2:"fr";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:2:"gd";a:8:{s:8:"language";s:2:"gd";s:7:"version";s:3:"4.0";s:7:"updated";s:19:"2014-09-05 17:37:43";s:12:"english_name";s:15:"Scottish Gaelic";s:11:"native_name";s:9:"Gàidhlig";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.0/gd.zip";s:3:"iso";a:3:{i:1;s:2:"gd";i:2;s:3:"gla";i:3;s:3:"gla";}s:7:"strings";a:1:{s:8:"continue";s:15:"Lean air adhart";}}s:5:"gl_ES";a:8:{s:8:"language";s:5:"gl_ES";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:8:"Galician";s:11:"native_name";s:6:"Galego";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/gl_ES.zip";s:3:"iso";a:2:{i:1;s:2:"gl";i:2;s:3:"glg";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:3:"haz";a:8:{s:8:"language";s:3:"haz";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-26 15:20:27";s:12:"english_name";s:8:"Hazaragi";s:11:"native_name";s:15:"هزاره گی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.1.6/haz.zip";s:3:"iso";a:1:{i:2;s:3:"haz";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"he_IL";a:8:{s:8:"language";s:5:"he_IL";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-12 08:05:04";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/he_IL.zip";s:3:"iso";a:1:{i:1;s:2:"he";}s:7:"strings";a:1:{s:8:"continue";s:12:"להמשיך";}}s:2:"hr";a:8:{s:8:"language";s:2:"hr";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-07 17:26:35";s:12:"english_name";s:8:"Croatian";s:11:"native_name";s:8:"Hrvatski";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/hr.zip";s:3:"iso";a:2:{i:1;s:2:"hr";i:2;s:3:"hrv";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:5:"hu_HU";a:8:{s:8:"language";s:5:"hu_HU";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 11:42:14";s:12:"english_name";s:9:"Hungarian";s:11:"native_name";s:6:"Magyar";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/hu_HU.zip";s:3:"iso";a:2:{i:1;s:2:"hu";i:2;s:3:"hun";}s:7:"strings";a:1:{s:8:"continue";s:7:"Tovább";}}s:5:"id_ID";a:8:{s:8:"language";s:5:"id_ID";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/id_ID.zip";s:3:"iso";a:2:{i:1;s:2:"id";i:2;s:3:"ind";}s:7:"strings";a:1:{s:8:"continue";s:9:"Lanjutkan";}}s:5:"is_IS";a:8:{s:8:"language";s:5:"is_IS";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:9:"Icelandic";s:11:"native_name";s:9:"Íslenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/is_IS.zip";s:3:"iso";a:2:{i:1;s:2:"is";i:2;s:3:"isl";}s:7:"strings";a:1:{s:8:"continue";s:6:"Áfram";}}s:5:"it_IT";a:8:{s:8:"language";s:5:"it_IT";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/it_IT.zip";s:3:"iso";a:2:{i:1;s:2:"it";i:2;s:3:"ita";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"ja";a:8:{s:8:"language";s:2:"ja";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/ja.zip";s:3:"iso";a:1:{i:1;s:2:"ja";}s:7:"strings";a:1:{s:8:"continue";s:9:"続ける";}}s:5:"ko_KR";a:8:{s:8:"language";s:5:"ko_KR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 22:21:58";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/ko_KR.zip";s:3:"iso";a:2:{i:1;s:2:"ko";i:2;s:3:"kor";}s:7:"strings";a:1:{s:8:"continue";s:6:"계속";}}s:5:"lt_LT";a:8:{s:8:"language";s:5:"lt_LT";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-04-23 15:23:08";s:12:"english_name";s:10:"Lithuanian";s:11:"native_name";s:15:"Lietuvių kalba";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/lt_LT.zip";s:3:"iso";a:2:{i:1;s:2:"lt";i:2;s:3:"lit";}s:7:"strings";a:1:{s:8:"continue";s:6:"Tęsti";}}s:5:"my_MM";a:8:{s:8:"language";s:5:"my_MM";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-26 15:57:42";s:12:"english_name";s:17:"Myanmar (Burmese)";s:11:"native_name";s:15:"ဗမာစာ";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.6/my_MM.zip";s:3:"iso";a:2:{i:1;s:2:"my";i:2;s:3:"mya";}s:7:"strings";a:1:{s:8:"continue";s:54:"ဆက်လက်လုပ်ေဆာင်ပါ။";}}s:5:"nb_NO";a:8:{s:8:"language";s:5:"nb_NO";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 22:03:44";s:12:"english_name";s:19:"Norwegian (Bokmål)";s:11:"native_name";s:13:"Norsk bokmål";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/nb_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nb";i:2;s:3:"nob";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsett";}}s:5:"nl_NL";a:8:{s:8:"language";s:5:"nl_NL";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-16 14:25:19";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/nl_NL.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nn_NO";a:8:{s:8:"language";s:5:"nn_NO";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-06-08 07:10:14";s:12:"english_name";s:19:"Norwegian (Nynorsk)";s:11:"native_name";s:13:"Norsk nynorsk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/nn_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nn";i:2;s:3:"nno";}s:7:"strings";a:1:{s:8:"continue";s:9:"Hald fram";}}s:3:"oci";a:8:{s:8:"language";s:3:"oci";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-06-10 17:07:58";s:12:"english_name";s:7:"Occitan";s:11:"native_name";s:7:"Occitan";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.2.2/oci.zip";s:3:"iso";a:2:{i:1;s:2:"oc";i:2;s:3:"oci";}s:7:"strings";a:1:{s:8:"continue";s:9:"Contunhar";}}s:5:"pl_PL";a:8:{s:8:"language";s:5:"pl_PL";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-09 10:15:05";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/pl_PL.zip";s:3:"iso";a:2:{i:1;s:2:"pl";i:2;s:3:"pol";}s:7:"strings";a:1:{s:8:"continue";s:9:"Kontynuuj";}}s:2:"ps";a:8:{s:8:"language";s:2:"ps";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-29 22:19:48";s:12:"english_name";s:6:"Pashto";s:11:"native_name";s:8:"پښتو";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.6/ps.zip";s:3:"iso";a:1:{i:1;s:2:"ps";}s:7:"strings";a:1:{s:8:"continue";s:8:"دوام";}}s:5:"pt_PT";a:8:{s:8:"language";s:5:"pt_PT";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-22 10:25:51";s:12:"english_name";s:21:"Portuguese (Portugal)";s:11:"native_name";s:10:"Português";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/pt_PT.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_BR";a:8:{s:8:"language";s:5:"pt_BR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/pt_BR.zip";s:3:"iso";a:2:{i:1;s:2:"pt";i:2;s:3:"por";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"ro_RO";a:8:{s:8:"language";s:5:"ro_RO";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-08 14:53:48";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/ro_RO.zip";s:3:"iso";a:2:{i:1;s:2:"ro";i:2;s:3:"ron";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuă";}}s:5:"ru_RU";a:8:{s:8:"language";s:5:"ru_RU";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 15:41:00";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/ru_RU.zip";s:3:"iso";a:2:{i:1;s:2:"ru";i:2;s:3:"rus";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продолжить";}}s:5:"sk_SK";a:8:{s:8:"language";s:5:"sk_SK";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-26 09:29:23";s:12:"english_name";s:6:"Slovak";s:11:"native_name";s:11:"Slovenčina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.2/sk_SK.zip";s:3:"iso";a:2:{i:1;s:2:"sk";i:2;s:3:"slk";}s:7:"strings";a:1:{s:8:"continue";s:12:"Pokračovať";}}s:5:"sl_SI";a:8:{s:8:"language";s:5:"sl_SI";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-26 16:25:46";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.6/sl_SI.zip";s:3:"iso";a:2:{i:1;s:2:"sl";i:2;s:3:"slv";}s:7:"strings";a:1:{s:8:"continue";s:10:"Nadaljujte";}}s:2:"sq";a:8:{s:8:"language";s:2:"sq";s:7:"version";s:5:"4.2.2";s:7:"updated";s:19:"2015-05-29 08:27:12";s:12:"english_name";s:8:"Albanian";s:11:"native_name";s:5:"Shqip";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.2/sq.zip";s:3:"iso";a:2:{i:1;s:2:"sq";i:2;s:3:"sqi";}s:7:"strings";a:1:{s:8:"continue";s:6:"Vazhdo";}}s:5:"sr_RS";a:8:{s:8:"language";s:5:"sr_RS";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:7:"Serbian";s:11:"native_name";s:23:"Српски језик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/sr_RS.zip";s:3:"iso";a:2:{i:1;s:2:"sr";i:2;s:3:"srp";}s:7:"strings";a:1:{s:8:"continue";s:14:"Настави";}}s:5:"sv_SE";a:8:{s:8:"language";s:5:"sv_SE";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-12 00:55:52";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/sv_SE.zip";s:3:"iso";a:2:{i:1;s:2:"sv";i:2;s:3:"swe";}s:7:"strings";a:1:{s:8:"continue";s:9:"Fortsätt";}}s:2:"th";a:8:{s:8:"language";s:2:"th";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:4:"Thai";s:11:"native_name";s:9:"ไทย";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/th.zip";s:3:"iso";a:2:{i:1;s:2:"th";i:2;s:3:"tha";}s:7:"strings";a:1:{s:8:"continue";s:15:"ต่อไป";}}s:2:"tl";a:8:{s:8:"language";s:2:"tl";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-06 10:10:09";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/tl.zip";s:3:"iso";a:2:{i:1;s:2:"tl";i:2;s:3:"tgl";}s:7:"strings";a:1:{s:8:"continue";s:10:"Magpatuloy";}}s:5:"tr_TR";a:8:{s:8:"language";s:5:"tr_TR";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-24 13:30:08";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/tr_TR.zip";s:3:"iso";a:2:{i:1;s:2:"tr";i:2;s:3:"tur";}s:7:"strings";a:1:{s:8:"continue";s:5:"Devam";}}s:5:"ug_CN";a:8:{s:8:"language";s:5:"ug_CN";s:7:"version";s:5:"4.1.6";s:7:"updated";s:19:"2015-03-26 16:45:38";s:12:"english_name";s:6:"Uighur";s:11:"native_name";s:9:"Uyƣurqə";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.6/ug_CN.zip";s:3:"iso";a:2:{i:1;s:2:"ug";i:2;s:3:"uig";}s:7:"strings";a:1:{s:8:"continue";s:26:"داۋاملاشتۇرۇش";}}s:2:"uk";a:8:{s:8:"language";s:2:"uk";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-05 10:51:50";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.2.3/uk.zip";s:3:"iso";a:2:{i:1;s:2:"uk";i:2;s:3:"ukr";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продовжити";}}s:5:"zh_TW";a:8:{s:8:"language";s:5:"zh_TW";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-23 13:52:20";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/zh_TW.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}s:5:"zh_CN";a:8:{s:8:"language";s:5:"zh_CN";s:7:"version";s:5:"4.2.3";s:7:"updated";s:19:"2015-07-04 19:52:42";s:12:"english_name";s:15:"Chinese (China)";s:11:"native_name";s:12:"简体中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.2.3/zh_CN.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"继续";}}}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (245, 'WPLANG', '', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (251, 'rewrite_rules', 'a:67:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (274, '_site_transient_timeout_theme_roots', '1437949820', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (275, '_site_transient_theme_roots', 'a:4:{s:16:"liljaingva-theme";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wpLi_options` VALUES (276, '_transient_doing_cron', '1437952468.8288469314575195312500', 'yes') ;
#
# End of data contents of table wpLi_options
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_postmeta`
#

DROP TABLE IF EXISTS `wpLi_postmeta`;


#
# Table structure of table `wpLi_postmeta`
#

CREATE TABLE `wpLi_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_postmeta (25 records)
#
 
INSERT INTO `wpLi_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wpLi_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (3, 4, '_edit_lock', '1437836892:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (5, 6, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (6, 6, '_edit_lock', '1437836208:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (8, 8, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (9, 8, '_edit_lock', '1437836174:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (11, 10, '_wp_attached_file', '2015/07/SFS-Passamynd.jpg') ; 
INSERT INTO `wpLi_postmeta` VALUES (12, 10, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1518;s:6:"height";i:1518;s:4:"file";s:25:"2015/07/SFS-Passamynd.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"SFS-Passamynd-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"SFS-Passamynd-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"SFS-Passamynd-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:16;s:6:"credit";s:11:"Unspecified";s:6:"camera";s:21:"Canon EOS-1Ds Mark II";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1169819456;s:9:"copyright";s:11:"Unspecified";s:12:"focal_length";s:2:"70";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (15, 13, '_wp_attached_file', '2015/07/lilja-ingva.png') ; 
INSERT INTO `wpLi_postmeta` VALUES (16, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:208;s:6:"height";i:209;s:4:"file";s:23:"2015/07/lilja-ingva.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"lilja-ingva-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (18, 15, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (19, 15, '_edit_lock', '1437836664:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (21, 18, '_wp_attached_file', '2015/07/auga.jpg') ; 
INSERT INTO `wpLi_postmeta` VALUES (22, 18, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:272;s:6:"height";i:272;s:4:"file";s:16:"2015/07/auga.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"auga-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:16;s:6:"credit";s:11:"Unspecified";s:6:"camera";s:21:"Canon EOS-1Ds Mark II";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1169819456;s:9:"copyright";s:11:"Unspecified";s:12:"focal_length";s:2:"70";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (24, 15, '_wp_old_slug', 'joi-spo-spiturass') ; 
INSERT INTO `wpLi_postmeta` VALUES (27, 20, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (28, 20, '_edit_lock', '1437839430:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (29, 21, '_wp_attached_file', '2015/07/nebbi.jpg') ; 
INSERT INTO `wpLi_postmeta` VALUES (30, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:282;s:6:"height";i:282;s:4:"file";s:17:"2015/07/nebbi.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"nebbi-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:11:"Unspecified";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wpLi_postmeta` VALUES (32, 23, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (33, 23, '_edit_lock', '1437841909:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (35, 25, '_edit_last', '1') ; 
INSERT INTO `wpLi_postmeta` VALUES (36, 25, '_edit_lock', '1437918627:1') ; 
INSERT INTO `wpLi_postmeta` VALUES (37, 25, '_wp_page_template', 'umsagnir.php') ;
#
# End of data contents of table wpLi_postmeta
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_posts`
#

DROP TABLE IF EXISTS `wpLi_posts`;


#
# Table structure of table `wpLi_posts`
#

CREATE TABLE `wpLi_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_posts (25 records)
#
 
INSERT INTO `wpLi_posts` VALUES (1, 1, '2015-07-10 17:16:32', '2015-07-10 17:16:32', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2015-07-10 17:16:32', '2015-07-10 17:16:32', '', 0, 'http://localhost/liljaingva/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wpLi_posts` VALUES (2, 1, '2015-07-10 17:16:32', '2015-07-10 17:16:32', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost/liljaingva/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2015-07-10 17:16:32', '2015-07-10 17:16:32', '', 0, 'http://localhost/liljaingva/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (4, 1, '2015-07-25 08:57:57', '2015-07-25 08:57:57', '<h4>með vel skipulögðum markmiðum</h4>
Í þjálfun hjá mér færðu framúrskarandi þjónus45 tu og árangur. Ég legg metna 75 ð minn í að fylgja þér eftir svo þú náir hámarks árangri miðað við raunhæf markmið sem við setjum saman handa þér.

<strong>Innifalið í einkaþjálfun hjá mér er eftirfarandi:</strong>
<ul>
	<li>Líkamstöðu og ástandsgreining</li>
	<li>Mælingar á 4 vikna fresti</li>
	<li>Markmiðasetning</li>
	<li>Dagleg matardagbók og ráðgjöf, orkuþörf og áætlun</li>
	<li>55 mín þjálfunartími í sal - Einstaklingsmiðuð æfingaáætlun</li>
	<li>Eftirfylgni</li>
</ul>
<h3>Þú nærð árangri hjá mér!</h3>', 'Pottþéttur árangur', '', 'publish', 'open', 'open', '', 'pottthettur-arangur', '', '', '2015-07-25 15:08:12', '2015-07-25 15:08:12', '', 0, 'http://localhost/liljaingva/?p=4', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (5, 1, '2015-07-25 08:57:57', '2015-07-25 08:57:57', '<h4>með vel skipulögðum markmiðum</h4>
Í þjálfun hjá mér færðu framúrskarandi þjónus45 tu og árangur. Ég legg metna 75 ð minn í að fylgja þér eftir svo þú náir hámarks árangri miðað við raunhæf markmið sem við setjum saman handa þér.

<strong>Innifalið í einkaþjálfun hjá mér er eftirfarandi:</strong>
<ul>
	<li>Líkamstöðu og ástandsgreining</li>
	<li>Mælingar á 4 vikna fresti</li>
	<li>Markmiðasetning</li>
	<li>Dagleg matardagbók og ráðgjöf, orkuþörf og áætlun</li>
	<li>55 mín þjálfunartími í sal - Einstaklingsmiðuð æfingaáætlun</li>
	<li>Eftirfylgni</li>
</ul>
<h3>Þú nærð árangri hjá mér!</h3>', 'Pottþéttur árangur', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2015-07-25 08:57:57', '2015-07-25 08:57:57', '', 4, 'http://localhost/liljaingva/2015/07/25/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (6, 1, '2015-07-25 11:50:35', '2015-07-25 11:50:35', '<img class="alignnone size-medium wp-image-10" src="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd-300x300.jpg" alt="SFS-Passamynd" width="300" height="300" />Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Steingrímur Fannar', '', 'publish', 'open', 'open', '', 'steingrimur-fannar', '', '', '2015-07-25 12:02:36', '2015-07-25 12:02:36', '', 0, 'http://localhost/liljaingva/?p=6', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (7, 1, '2015-07-25 11:50:35', '2015-07-25 11:50:35', 'Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'Steingrímur Fannar', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2015-07-25 11:50:35', '2015-07-25 11:50:35', '', 6, 'http://localhost/liljaingva/2015/07/25/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (8, 1, '2015-07-25 11:51:48', '2015-07-25 11:51:48', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png"><img class="alignnone size-full wp-image-13" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png" alt="lilja-ingva" width="208" height="209" /></a>In a professional context it often happens that private or corporate clients corder a publication to be made and presented with the actual content still not being ready. Think of a news blog that\'s filled with content hourly on the day of going live. However, reviewers tend to be distracted by comprehensible content, say, a random text copied from a newspaper or the internet. The are likely to focus on the text, disregarding the layout and its elements. Besides, random text risks to be unintendedly humorous or offensive, an unacceptable risk in corporate environments. <strong>Lorem ipsum</strong> and its many variants have been employed since the early 1960ies, and quite likely since the sixteenth century.', 'Lilja Ingva', '', 'publish', 'open', 'open', '', 'lilja-ingva', '', '', '2015-07-25 14:55:55', '2015-07-25 14:55:55', '', 0, 'http://localhost/liljaingva/?p=8', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (9, 1, '2015-07-25 11:51:48', '2015-07-25 11:51:48', 'In a professional context it often happens that private or corporate clients corder a publication to be made and presented with the actual content still not being ready. Think of a news blog that\'s filled with content hourly on the day of going live. However, reviewers tend to be distracted by comprehensible content, say, a random text copied from a newspaper or the internet. The are likely to focus on the text, disregarding the layout and its elements. Besides, random text risks to be unintendedly humorous or offensive, an unacceptable risk in corporate environments. <strong>Lorem ipsum</strong> and its many variants have been employed since the early 1960ies, and quite likely since the sixteenth century.', 'Lilja Ingva', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2015-07-25 11:51:48', '2015-07-25 11:51:48', '', 8, 'http://localhost/liljaingva/2015/07/25/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (10, 1, '2015-07-25 12:01:54', '2015-07-25 12:01:54', '', 'SFS-Passamynd', '', 'inherit', 'open', 'open', '', 'sfs-passamynd', '', '', '2015-07-25 12:01:54', '2015-07-25 12:01:54', '', 6, 'http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wpLi_posts` VALUES (11, 1, '2015-07-25 12:01:59', '2015-07-25 12:01:59', 'Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd.jpg"><img class="alignnone size-medium wp-image-10" src="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd-300x300.jpg" alt="SFS-Passamynd" width="300" height="300" /></a>', 'Steingrímur Fannar', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2015-07-25 12:01:59', '2015-07-25 12:01:59', '', 6, 'http://localhost/liljaingva/2015/07/25/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (12, 1, '2015-07-25 12:02:36', '2015-07-25 12:02:36', '<img class="alignnone size-medium wp-image-10" src="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd-300x300.jpg" alt="SFS-Passamynd" width="300" height="300" />Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Steingrímur Fannar', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2015-07-25 12:02:36', '2015-07-25 12:02:36', '', 6, 'http://localhost/liljaingva/2015/07/25/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (13, 1, '2015-07-25 14:55:49', '2015-07-25 14:55:49', '', 'lilja-ingva', '', 'inherit', 'open', 'open', '', 'lilja-ingva-2', '', '', '2015-07-25 14:55:49', '2015-07-25 14:55:49', '', 8, 'http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wpLi_posts` VALUES (14, 1, '2015-07-25 14:55:55', '2015-07-25 14:55:55', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png"><img class="alignnone size-full wp-image-13" src="http://localhost/liljaingva/wp-content/uploads/2015/07/lilja-ingva.png" alt="lilja-ingva" width="208" height="209" /></a>In a professional context it often happens that private or corporate clients corder a publication to be made and presented with the actual content still not being ready. Think of a news blog that\'s filled with content hourly on the day of going live. However, reviewers tend to be distracted by comprehensible content, say, a random text copied from a newspaper or the internet. The are likely to focus on the text, disregarding the layout and its elements. Besides, random text risks to be unintendedly humorous or offensive, an unacceptable risk in corporate environments. <strong>Lorem ipsum</strong> and its many variants have been employed since the early 1960ies, and quite likely since the sixteenth century.', 'Lilja Ingva', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2015-07-25 14:55:55', '2015-07-25 14:55:55', '', 8, 'http://localhost/liljaingva/2015/07/25/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (15, 1, '2015-07-25 14:59:28', '2015-07-25 14:59:28', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg"><img class="alignnone size-full wp-image-18" src="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg" alt="auga" width="272" height="272" /></a>Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Jói Spói spíturass', '', 'publish', 'open', 'open', '', 'joi-spoi-spiturass', '', '', '2015-07-25 15:05:00', '2015-07-25 15:05:00', '', 0, 'http://localhost/liljaingva/?p=15', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (16, 1, '2015-07-25 14:59:28', '2015-07-25 14:59:28', '<img class="alignnone size-medium wp-image-10" src="http://localhost/liljaingva/wp-content/uploads/2015/07/SFS-Passamynd-300x300.jpg" alt="SFS-Passamynd" width="300" height="300" />Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Jói Spó spíturass', '', 'inherit', 'open', 'open', '', '15-revision-v1', '', '', '2015-07-25 14:59:28', '2015-07-25 14:59:28', '', 15, 'http://localhost/liljaingva/2015/07/25/15-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (17, 1, '2015-07-25 15:04:59', '2015-07-25 15:04:59', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg"><img class="alignnone size-full wp-image-18" src="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg" alt="auga" width="272" height="272" /></a>Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Jói Spói spíturass', '', 'inherit', 'open', 'open', '', '15-autosave-v1', '', '', '2015-07-25 15:04:59', '2015-07-25 15:04:59', '', 15, 'http://localhost/liljaingva/2015/07/25/15-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (18, 1, '2015-07-25 15:04:54', '2015-07-25 15:04:54', '', 'auga', '', 'inherit', 'open', 'open', '', 'auga', '', '', '2015-07-25 15:04:54', '2015-07-25 15:04:54', '', 15, 'http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wpLi_posts` VALUES (19, 1, '2015-07-25 15:05:00', '2015-07-25 15:05:00', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg"><img class="alignnone size-full wp-image-18" src="http://localhost/liljaingva/wp-content/uploads/2015/07/auga.jpg" alt="auga" width="272" height="272" /></a>Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do eiusmod te 75 mpor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

&nbsp;', 'Jói Spói spíturass', '', 'inherit', 'open', 'open', '', '15-revision-v1', '', '', '2015-07-25 15:05:00', '2015-07-25 15:05:00', '', 15, 'http://localhost/liljaingva/2015/07/25/15-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (20, 1, '2015-07-25 15:13:11', '2015-07-25 15:13:11', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg"><img class="alignnone size-full wp-image-21" src="http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg" alt="nebbi" width="282" height="282" /></a>dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do', 'Nebbi Nebbason', '', 'publish', 'open', 'open', '', 'nebbi-nebbason', '', '', '2015-07-25 15:13:11', '2015-07-25 15:13:11', '', 0, 'http://localhost/liljaingva/?p=20', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (21, 1, '2015-07-25 15:13:01', '2015-07-25 15:13:01', '', 'nebbi', '', 'inherit', 'open', 'open', '', 'nebbi', '', '', '2015-07-25 15:13:01', '2015-07-25 15:13:01', '', 20, 'http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wpLi_posts` VALUES (22, 1, '2015-07-25 15:13:11', '2015-07-25 15:13:11', '<a href="http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg"><img class="alignnone size-full wp-image-21" src="http://localhost/liljaingva/wp-content/uploads/2015/07/nebbi.jpg" alt="nebbi" width="282" height="282" /></a>dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur 40adipiscing elit, sed do', 'Nebbi Nebbason', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2015-07-25 15:13:11', '2015-07-25 15:13:11', '', 20, 'http://localhost/liljaingva/2015/07/25/20-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (23, 1, '2015-07-25 15:53:26', '2015-07-25 15:53:26', 'Árangursmyndir frá því rétt áður en ég tók mig taki í lok mars 2009 og brey 70 tti mínum lífstíl til frambúðar. 2013 um páska - 4 árum síðar var ég mætt á sviðið og keppti í fitness - sem var enn eitt markmið sem ég setti mér og náði. Hefði aldrei dreymt um það þegar ég stóð þarna í svarta kjólnum, of þung, illt í liðum og þreytt á eigin ástandi. Það er allt hægt með viljanum, þolinmæði og án öfga.

Ég náði þessum árangri hægt og bítandi. Fór aldrei framúr sjálfum mér. Hér voru engar skyndilausnir, eingöngu gott matarræði ávallt og hreyfing sem beindist að mínum markmiðum og því sem mér fannst skemmtilegt. Það var aldrei svo að mér fannst þetta erfitt né leiðinlegt. Er svo glöð að hafa uppgötvað og fundið mig í þessum frábæra lífstil!!', 'Ferðalagið mitt', '', 'publish', 'open', 'open', '', 'ferdalagid-mitt', '', '', '2015-07-25 15:53:26', '2015-07-25 15:53:26', '', 0, 'http://localhost/liljaingva/?p=23', 0, 'post', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (24, 1, '2015-07-25 15:53:26', '2015-07-25 15:53:26', 'Árangursmyndir frá því rétt áður en ég tók mig taki í lok mars 2009 og brey 70 tti mínum lífstíl til frambúðar. 2013 um páska - 4 árum síðar var ég mætt á sviðið og keppti í fitness - sem var enn eitt markmið sem ég setti mér og náði. Hefði aldrei dreymt um það þegar ég stóð þarna í svarta kjólnum, of þung, illt í liðum og þreytt á eigin ástandi. Það er allt hægt með viljanum, þolinmæði og án öfga.

Ég náði þessum árangri hægt og bítandi. Fór aldrei framúr sjálfum mér. Hér voru engar skyndilausnir, eingöngu gott matarræði ávallt og hreyfing sem beindist að mínum markmiðum og því sem mér fannst skemmtilegt. Það var aldrei svo að mér fannst þetta erfitt né leiðinlegt. Er svo glöð að hafa uppgötvað og fundið mig í þessum frábæra lífstil!!', 'Ferðalagið mitt', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-07-25 15:53:26', '2015-07-25 15:53:26', '', 23, 'http://localhost/liljaingva/2015/07/25/23-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (25, 1, '2015-07-25 21:25:18', '2015-07-25 21:25:18', '', 'Umsagnir', '', 'publish', 'open', 'open', '', 'umsagnir', '', '', '2015-07-25 21:25:18', '2015-07-25 21:25:18', '', 0, 'http://localhost/liljaingva/?page_id=25', 0, 'page', '', 0) ; 
INSERT INTO `wpLi_posts` VALUES (26, 1, '2015-07-25 21:25:18', '2015-07-25 21:25:18', '', 'Umsagnir', '', 'inherit', 'open', 'open', '', '25-revision-v1', '', '', '2015-07-25 21:25:18', '2015-07-25 21:25:18', '', 25, 'http://localhost/liljaingva/25-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wpLi_posts
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_term_relationships`
#

DROP TABLE IF EXISTS `wpLi_term_relationships`;


#
# Table structure of table `wpLi_term_relationships`
#

CREATE TABLE `wpLi_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_term_relationships (7 records)
#
 
INSERT INTO `wpLi_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (4, 1, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (8, 2, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (15, 2, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (20, 2, 0) ; 
INSERT INTO `wpLi_term_relationships` VALUES (23, 1, 0) ;
#
# End of data contents of table wpLi_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_term_taxonomy`
#

DROP TABLE IF EXISTS `wpLi_term_taxonomy`;


#
# Table structure of table `wpLi_term_taxonomy`
#

CREATE TABLE `wpLi_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_term_taxonomy (2 records)
#
 
INSERT INTO `wpLi_term_taxonomy` VALUES (1, 1, 'category', '', 0, 3) ; 
INSERT INTO `wpLi_term_taxonomy` VALUES (2, 2, 'category', 'Setja póst í þennan hóp ef pósturinn er umsögn frá viðskiptavin', 0, 4) ;
#
# End of data contents of table wpLi_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_terms`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_terms`
#

DROP TABLE IF EXISTS `wpLi_terms`;


#
# Table structure of table `wpLi_terms`
#

CREATE TABLE `wpLi_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_terms (2 records)
#
 
INSERT INTO `wpLi_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wpLi_terms` VALUES (2, 'Umsagnir', 'umsagnir', 0) ;
#
# End of data contents of table wpLi_terms
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_usermeta`
#

DROP TABLE IF EXISTS `wpLi_usermeta`;


#
# Table structure of table `wpLi_usermeta`
#

CREATE TABLE `wpLi_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_usermeta (17 records)
#
 
INSERT INTO `wpLi_usermeta` VALUES (1, 1, 'nickname', 'liljan') ; 
INSERT INTO `wpLi_usermeta` VALUES (2, 1, 'first_name', '') ; 
INSERT INTO `wpLi_usermeta` VALUES (3, 1, 'last_name', '') ; 
INSERT INTO `wpLi_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wpLi_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wpLi_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wpLi_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wpLi_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wpLi_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wpLi_usermeta` VALUES (10, 1, 'wpLi_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wpLi_usermeta` VALUES (11, 1, 'wpLi_user_level', '10') ; 
INSERT INTO `wpLi_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw') ; 
INSERT INTO `wpLi_usermeta` VALUES (13, 1, 'default_password_nag', '') ; 
INSERT INTO `wpLi_usermeta` VALUES (14, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wpLi_usermeta` VALUES (16, 1, 'wpLi_dashboard_quick_press_last_post_id', '3') ; 
INSERT INTO `wpLi_usermeta` VALUES (17, 1, 'wpLi_user-settings', 'hidetb=1&editor=tinymce&libraryContent=browse') ; 
INSERT INTO `wpLi_usermeta` VALUES (18, 1, 'wpLi_user-settings-time', '1437836696') ;
#
# End of data contents of table wpLi_usermeta
# --------------------------------------------------------

# WordPress : http://localhost/liljaingva MySQL database backup
#
# Generated: Sunday 26. July 2015 23:14 UTC
# Hostname: localhost
# Database: `16_lilja_ingva`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpLi_users`
# --------------------------------------------------------


#
# Delete any existing table `wpLi_users`
#

DROP TABLE IF EXISTS `wpLi_users`;


#
# Table structure of table `wpLi_users`
#

CREATE TABLE `wpLi_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wpLi_users (1 records)
#
 
INSERT INTO `wpLi_users` VALUES (1, 'liljan', '$P$BlKQyW7tnJjZ6YAp4XPXyYHLlKc9Z91', 'liljan', 'steingrimur@740.is', '', '2015-07-10 17:16:31', '', 0, 'liljan') ;
#
# End of data contents of table wpLi_users
# --------------------------------------------------------

